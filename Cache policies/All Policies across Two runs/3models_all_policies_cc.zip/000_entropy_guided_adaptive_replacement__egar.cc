/*********************************************************************
 *  Entropy‑Guided Adaptive Replacement (EGAR) – CHAMPSIM policy
 *
 *  Author: <your name>
 *  Date  : 2025‑09‑17
 *
 *  This file implements the EGAR replacement policy for the
 *  ChampSim framework.  The implementation follows the required
 *  API (InitReplacementState, GetVictimInSet, UpdateReplacementState,
 *  PrintStats, PrintStats_Heartbeat).
 *
 *  Policy summary:
 *   - Each cache line stores: timestamp, freq counter, 4‑bucket histogram.
 *   - On hit: update histogram, recompute entropy, boost score.
 *   - On miss: victim = line with minimum score (score = α*recency +
 *              β*freq + γ*(1‑entropy)).
 *   - A simple phase detector per core resets scores when the dominant
 *     PC region changes.
 *********************************************************************/

#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)   // 2048 sets per core
#define LLC_WAYS 16

/*--------------------------  Tunable weights  --------------------------*/
constexpr float ALPHA = 0.4f;   // recency weight
constexpr float BETA  = 0.4f;   // frequency weight
constexpr float GAMMA = 0.2f;   // entropy weight (1‑H)

/*--------------------------  Metadata structs  --------------------------*/
struct LineMeta {
    uint64_t timestamp;          // last access cycle (for recency)
    uint8_t  freq;               // 0‑255 frequency counter
    uint8_t  hist[4];            // 2‑bit buckets (0‑3) for reuse‑distance histogram
    float    entropy;            // cached entropy value (0‑1)
    float    score;              // current composite score
    LineMeta() : timestamp(0), freq(0), entropy(0.0f), score(0.0f) {
        hist[0]=hist[1]=hist[2]=hist[3]=0;
    }
};

/*--------------------------  Global tables  ----------------------------*/
static LineMeta repl[LLC_SETS][LLC_WAYS];   // per‑set, per‑way metadata

/*--------------------------  Phase detector  ---------------------------*/
constexpr uint32_t PHASE_PC_WINDOW = 64;   // how many PCs to keep
constexpr uint32_t PHASE_CHANGE_TH  = 48; // % similarity needed to stay in same phase

struct PhaseInfo {
    uint64_t pcs[PHASE_PC_WINDOW];
    uint32_t idx;          // circular index
    uint64_t last_dom_pc;  // dominant PC of previous window
    bool     valid;
    PhaseInfo() : idx(0), last_dom_pc(0), valid(false) {
        for (uint32_t i=0;i<PHASE_PC_WINDOW;i++) pcs[i]=0;
    }
};

static PhaseInfo phase[NUM_CORE];

/*--------------------------  Helper functions  --------------------------*/

// Simple 2‑bit histogram bucket based on reuse distance (log‑scale)
static inline uint8_t bucket_for_distance(uint64_t dist) {
    if (dist < 4)      return 0;   // very short reuse
    else if (dist < 16)   return 1;
    else if (dist < 64)   return 2;
    else                  return 3;   // long or no reuse
}

// Compute Shannon entropy from a 4‑bucket histogram (each bucket 2‑bits)
static float compute_entropy(const uint8_t h[4]) {
    uint32_t total = h[0] + h[1] + h[2] + h[3];
    if (total == 0) return 0.0f;
    float ent = 0.0f;
    for (int i=0;i<4;i++) {
        if (h[i]==0) continue;
        float p = float(h[i]) / float(total);
        ent -= p * log2f(p);
    }
    // Normalise to [0,2] (max entropy for 4 buckets is 2 bits), then to [0,1]
    return ent / 2.0f;
}

// Update the phase detector; returns true if a phase change was detected
static bool update_phase(uint32_t cpu, uint64_t pc) {
    PhaseInfo &pi = phase[cpu];
    pi.pcs[pi.idx] = pc;
    pi.idx = (pi.idx + 1) % PHASE_PC_WINDOW;

    if (!pi.valid && pi.idx == 0) pi.valid = true;   // filled first window
    if (!pi.valid) return false;                     // not enough data yet

    // Find most frequent PC in the window (simple linear scan)
    uint64_t best_pc = 0;
    uint32_t best_cnt = 0;
    for (uint32_t i=0;i<PHASE_PC_WINDOW;i++) {
        uint64_t cur = pi.pcs[i];
        uint32_t cnt = 0;
        for (uint32_t j=0;j<PHASE_PC_WINDOW;j++)
            if (pi.pcs[j]==cur) cnt++;
        if (cnt > best_cnt) {
            best_cnt = cnt;
            best_pc = cur;
        }
    }

    // Compute similarity (percentage of window belonging to best_pc)
    float similarity = (float)best_cnt / (float)PHASE_PC_WINDOW;

    bool changed = false;
    if (pi.last_dom_pc == 0) {
        pi.last_dom_pc = best_pc;
    } else if (best_pc != pi.last_dom_pc && similarity < (PHASE_CHANGE_TH/100.0f)) {
        // Phase changed
        changed = true;
        pi.last_dom_pc = best_pc;
    }
    return changed;
}

/*--------------------------  API Functions  ---------------------------*/

//---------------------------------------------------------------
// InitReplacementState: allocate / reset all per‑line metadata
//---------------------------------------------------------------
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            repl[s][w] = LineMeta();   // zero‑initialise
        }
    }
    // Phase info already default‑constructed
}

//---------------------------------------------------------------
// GetVictimInSet: return the way index of the line to evict
//---------------------------------------------------------------
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Update phase detector first – if a phase change happened we
    // decay the scores of all lines in the set (simple linear decay).
    if (update_phase(cpu, PC)) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            repl[set][w].score *= 0.5f;   // aggressive decay on phase change
        }
    }

    // Choose line with minimal score (protected by tie‑break LRU)
    uint32_t victim = 0;
    float min_score = repl[set][0].score;
    uint64_t oldest_ts = repl[set][0].timestamp;

    for (uint32_t w = 1; w < LLC_WAYS; ++w) {
        float sc = repl[set][w].score;
        if (sc < min_score) {
            victim = w;
            min_score = sc;
            oldest_ts = repl[set][w].timestamp;
        } else if (sc == min_score) {
            // tie – evict the older line (classic LRU tie‑break)
            if (repl[set][w].timestamp < oldest_ts) {
                victim = w;
                oldest_ts = repl[set][w].timestamp;
            }
        }
    }
    return victim;
}

//---------------------------------------------------------------
// UpdateReplacementState: called on every access (hit or miss)
//---------------------------------------------------------------
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t cur_cycle = __builtin_ia32_rdtsc(); // approximate cycle counter
    LineMeta &meta = repl[set][way];

    // ----------  COMMON UPDATE (both hit and miss) ----------
    // 1. Recency – store current timestamp
    meta.timestamp = cur_cycle;

    // 2. Frequency – exponential increase on hit, decay on miss
    if (hit) {
        if (meta.freq < 250) meta.freq += 5;  // accelerate on hit
    } else {
        if (meta.freq > 5) meta.freq -= 5;    // slowly forget
    }

    // 3. Reuse‑distance histogram & entropy (only on hit)
    if (hit) {
        // Approximate reuse distance by counting accesses since last use.
        // ChampSim does not expose a global counter, so we approximate
        // with (cur_cycle - meta.timestamp) / 1000 as a proxy.
        uint64_t raw_dist = (cur_cycle - meta.timestamp) / 1000;
        uint8_t b = bucket_for_distance(raw_dist);
        if (meta.hist[b] < 3) meta.hist[b]++;   // 2‑bit saturating counter
        // Re‑compute entropy
        meta.entropy = compute_entropy(meta.hist);
    } else {
        // On miss we treat it as a "new line" – reset histogram & entropy
        for (int i=0;i<4;i++) meta.hist[i]=0;
        meta.entropy = 0.0f;
    }

    // 4. Compute composite score
    //    Recency component: newer lines get larger value (max_ts - ts)
    //    Frequency component: scaled freq
    //    Entropy component: 1‑entropy (low entropy = high reward)
    static uint64_t max_ts = 0;
    if (cur_cycle > max_ts) max_ts = cur_cycle;
    float recency_val = float(max_ts - meta.timestamp) / float(max_ts);
    float freq_val    = float(meta.freq) / 255.0f;
    float ent_val     = 1.0f - meta.entropy;   // high when pattern is predictable

    meta.score = ALPHA * recency_val + BETA * freq_val + GAMMA * ent_val;

    // 5. If this line was just inserted (miss), initialise timestamp/freq
    if (!hit) {
        meta.timestamp = cur_cycle;
        meta.freq = 1;
        // score will be recomputed above (mostly low because entropy=0)
    }
}

//---------------------------------------------------------------
// PrintStats – optional final statistics
//---------------------------------------------------------------
void PrintStats() {
    // Example: average score per set (just for illustration)
    double totalScore = 0.0;
    uint64_t lineCnt = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            totalScore += repl[s][w].score;
            ++lineCnt;
        }
    }
    std::cout << "EGAR: average line score = " << (totalScore/lineCnt) << std::endl;
}

//---------------------------------------------------------------
// PrintStats_Heartbeat – optional periodic dump
//---------------------------------------------------------------
void PrintStats_Heartbeat() {
    // No heartbeat output required for this policy
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ------------------------------------------------------------------
   Configuration parameters (tweakable)
   ------------------------------------------------------------------ */
static const double EWMA_ALPHA   = 0.5;          // 0 < α ≤ 1
static const uint64_t MAX_DIST    = 1ULL << 30; // a huge initial distance
static const uint8_t  CONF_MAX    = 7;          // 3‑bit saturating counter
static const uint8_t  CONF_INC    = 1;

/* ------------------------------------------------------------------
   Global state
   ------------------------------------------------------------------ */
static uint64_t g_time = 0; // logical timestamp, increments on every access

// per‑line metadata
static std::vector<std::vector<uint64_t>> last_time;   // when line was last hit
static std::vector<std::vector<double>>   est_dist;    // EWMA reuse distance
static std::vector<std::vector<uint8_t>>  conf;       // confidence counter

/* ------------------------------------------------------------------
   Initialise replacement state
   ------------------------------------------------------------------ */
void InitReplacementState() {
    last_time.assign(LLC_SETS, std::vector<uint64_t>(LLC_WAYS, 0));
    est_dist.assign (LLC_SETS, std::vector<double>(LLC_WAYS, (double)MAX_DIST));
    conf.assign     (LLC_SETS, std::vector<uint8_t>(LLC_WAYS, 0));
}

/* ------------------------------------------------------------------
   Choose victim line in the set
   ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Simple linear scan – LLC_WAYS is small (≤ 32) in typical configs
    uint32_t victim_way = 0;
    double   worst_score = -1.0;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        // If the line is invalid, immediately use it
        if (current_set[way].valid == 0) {
            return way;
        }

        // Score = estimated distance * (1 + confidence/8)
        double score = est_dist[set][way] * (1.0 + (double)conf[set][way] / (CONF_MAX + 1));

        if (score > worst_score) {
            worst_score = score;
            victim_way  = way;
        }
    }

    return victim_way;
}

/* ------------------------------------------------------------------
   Update replacement state after an access (hit or miss)
   ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Increment global timestamp – one per access (read or write)
    ++g_time;

    if (hit) {
        // ---------- HIT ----------
        uint64_t  prev_time = last_time[set][way];
        uint64_t  cur_dist  = g_time - prev_time;          // raw reuse distance

        // EWMA update of estimated distance
        double old_est = est_dist[set][way];
        double new_est = EWMA_ALPHA * (double)cur_dist + (1.0 - EWMA_ALPHA) * old_est;
        est_dist[set][way] = new_est;

        // Increase confidence (saturating)
        if (conf[set][way] < CONF_MAX)
            conf[set][way] = std::min<uint8_t>(CONF_MAX, conf[set][way] + CONF_INC);

        // Record the new last‑use time
        last_time[set][way] = g_time;
    } else {
        // ---------- MISS ----------
        // The victim line (way) is about to be overwritten with a new line.
        // Initialise its metadata for the fresh entry.
        last_time[set][way] = g_time;          // first reference time
        est_dist[set][way] = (double)MAX_DIST; // unknown distance → pessimistic
        conf[set][way]    = 0;                 // no confidence yet
    }
}

/* ------------------------------------------------------------------
   Optional: print final statistics
   ------------------------------------------------------------------ */
void PrintStats() {
    // Example: average confidence across the whole LLC
    uint64_t sum_conf = 0;
    uint64_t total    = LLC_SETS * LLC_WAYS;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            sum_conf += conf[s][w];

    std::cout << "[DRDE] Average confidence: "
              << std::fixed << std::setprecision(2)
              << (double)sum_conf / total << std::endl;
}

/* ------------------------------------------------------------------
   Optional: periodic heartbeat statistics
   ------------------------------------------------------------------ */
void PrintStats_Heartbeat() {
    // No periodic stats needed for this policy (placeholder)
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct CacheMetadata {
    uint64_t last_access;  // Timestamp of last access
    uint64_t access_count; // Total number of accesses
    uint64_t insert_time;  // Timestamp when block was inserted
};

std::vector<CacheMetadata> cache_metadata(LLC_SETS * LLC_WAYS);

// Initialize replacement state
void InitReplacementState() {
    cache_metadata.resize(LLC_SETS * LLC_WAYS, {0, 0, 0});
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t max_score = 0;
    uint64_t current_time = __rdtsc();  // Use timestamp counter for temporal calculations

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t line = set * LLC_WAYS + way;
        
        // Calculate temporal decay since insertion
        uint64_t temporal_penalty = current_time - cache_metadata[line].insert_time;
        
        // Calculate hybrid score: higher is worse (more likely to be replaced)
        uint64_t recency_weight = 1.0f - (cache_metadata[line].last_access / (float)current_time);
        uint64_t frequency_weight = cache_metadata[line].access_count;
        uint64_t score = temporal_penalty * 0.5f + recency_weight * 0.3f + frequency_weight * 0.2f;
        
        if (score > max_score) {
            max_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t current_time = __rdtsc();
    uint64_t line = set * LLC_WAYS + way;

    if (hit) {
        cache_metadata[line].last_access = current_time;
        cache_metadata[line].access_count++;
    } else {
        cache_metadata[line].insert_time = current_time;
        cache_metadata[line].last_access = current_time;
        cache_metadata[line].access_count = 1;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics could include:
    // - Average access count per line
    // - Average time since last access
    // - Eviction reasons breakdown
    std::cout << "HybridTempo Statistics:" << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example periodic statistics could include:
    // - Current cache occupancy
    // - Recent victim selection patterns
    std::cout << "HybridTempo Heartbeat:" << std::endl;
}
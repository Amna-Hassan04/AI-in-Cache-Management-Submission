#include <vector>
#include <cstdint>
#include <iostream>
#include <deque>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track metadata for each cache line
struct CacheLineMetadata {
    uint64_t last_access_time;
    uint32_t spatial_score;
    uint32_t temporal_score;
};

std::deque<uint64_t> access_history;  // To track recent accesses
std::vector<std::vector<CacheLineMetadata>> metadata(
    NUM_CORE, std::vector<CacheLineMetadata>(LLC_SETS * LLC_WAYS)
);
uint32_t current_strategy = 0;  // 0: Spatial, 1: Temporal, 2: Randomized
uint32_t last_phase_change = 0;

// Initialize replacement state
void InitReplacementState() {
    // Initialize metadata for all cache lines
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                metadata[cpu][set * LLC_WAYS + way] = {0, 0, 0};
            }
        }
    }
}

// Helper function to determine the current strategy based on recent accesses
void update_strategy() {
    // Analyze access_history to determine the current phase
    // (Simplified for illustration purposes)
    static uint32_t spatial_count = 0, temporal_count = 0;
    const uint32_t WINDOW_SIZE = 100;
    
    if (access_history.size() >= WINDOW_SIZE) {
        uint32_t spatial = 0, temporal = 0;
        for (auto it = access_history.begin(); it != access_history.end(); ++it) {
            // Simple heuristic: consecutive addresses indicate spatial locality
            if (it != access_history.begin() && (*it) == *(it - 1) + 1) {
                spatial++;
            }
        }
        temporal = WINDOW_SIZE - spatial;
        
        if (spatial > temporal) {
            current_strategy = 0;
        } else if (temporal > spatial) {
            current_strategy = 1;
        } else {
            current_strategy = 2;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    update_strategy();
    
    uint32_t victim = 0;
    switch (current_strategy) {
        case 0:  // Spatial strategy
            victim = 0;
            uint32_t min_spatial = UINT32_MAX;
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                if (metadata[cpu][set * LLC_WAYS + way].spatial_score < min_spatial) {
                    min_spatial = metadata[cpu][set * LLC_WAYS + way].spatial_score;
                    victim = way;
                }
            }
            break;
            
        case 1:  // Temporal strategy
            victim = 0;
            uint32_t min_temporal = UINT32_MAX;
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                if (metadata[cpu][set * LLC_WAYS + way].temporal_score < min_temporal) {
                    min_temporal = metadata[cpu][set * LLC_WAYS + way].temporal_score;
                    victim = way;
                }
            }
            break;
            
        case 2:  // Randomized strategy
            victim = rand() % LLC_WAYS;
            break;
    }
    
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update access history
    access_history.push_back(paddr);
    if (access_history.size() > 1000) {
        access_history.pop_front();
    }
    
    // Update metadata for the accessed line
    metadata[cpu][set * LLC_WAYS + way].last_access_time = __builtin_ia32_rdtsc();
    metadata[cpu][set * LLC_WAYS + way].temporal_score++;
    
    // Update spatial scores for neighboring lines
    for (uint32_t i = 0; i < LLC_WAYS; i++) {
        uint64_t current_addr = current_set[i].paddr;
        if (abs(current_addr - paddr) <= 64) {
            metadata[cpu][set * LLC_WAYS + i].spatial_score++;
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics
    std::cout << "APAR Statistics:" << std::endl;
    std::cout << "Spatial Strategy Usage: " << (current_strategy == 0) << std::endl;
    std::cout << "Temporal Strategy Usage: " << (current_strategy == 1) << std::endl;
    std::cout << "Randomized Strategy Usage: " << (current_strategy == 2) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example heartbeat statistics
    std::cout << "APAR Heartbeat:" << std::endl;
    std::cout << "Current Strategy: " << current_strategy << std::endl;
    std::cout << "Access History Size: " << access_history.size() << std::endl;
}
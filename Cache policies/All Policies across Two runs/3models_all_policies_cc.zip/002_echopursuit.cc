#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track frequency and temporal distance
struct EchoPursuitState {
    uint8_t frequency;
    uint16_t temporal_distance;
};

// Initialize replacement state
void InitReplacementState() {
    static std::vector<EchoPursuitState> eps(LLC_SETS * LLC_WAYS);
    for (auto& state : eps) {
        state.frequency = 0;
        state.temporal_distance = 0;
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint16_t max_temporal_distance = 0;
    uint8_t min_frequency = 255;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint32_t index = set * LLC_WAYS + way;
        EchoPursuitState& state = eps[index];

        // Lower frequency and higher temporal distance make a line more likely to be victimized
        uint16_t score = state.temporal_distance + (255 - state.frequency);

        if (score > max_temporal_distance + (255 - min_frequency)) {
            max_temporal_distance = state.temporal_distance;
            min_frequency = state.frequency;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint32_t index = set * LLC_WAYS + way;
    EchoPursuitState& state = eps[index];

    if (hit) {
        // Increase frequency on hit, cap at 255
        state.frequency = std::min((uint8_t)255, state.frequency + 1);
        state.temporal_distance = 0; // Reset temporal distance on hit
    } else {
        // Increment temporal distance on miss or non-hit access
        state.temporal_distance = std::min((uint16_t)65535, state.temporal_distance + 1);
    }

    // Age all cache lines in the set
    for (uint32_t w = 0; w < LLC_WAYS; w++) {
        uint32_t idx = set * LLC_WAYS + w;
        eps[idx].temporal_distance = std::min((uint16_t)65535, eps[idx].temporal_distance + 1);
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Statistics can be printed here
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Progress stats can be printed here
}

std::vector<EchoPursuitState> eps;
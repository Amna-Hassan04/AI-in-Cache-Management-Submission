#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track temporal and spatial affinity
struct AffinityTracker {
    uint64_t last_access_timestamp;
    uint64_t spatial_affinity_score;
};

// Array to store affinity trackers for each cache line
AffinityTracker affinity_trackers[LLC_SETS][LLC_WAYS];

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            affinity_trackers[set][way].last_access_timestamp = 0;
            affinity_trackers[set][way].spatial_affinity_score = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_temporal_affinity = UINT64_MAX;
    uint64_t min_spatial_affinity = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t temporal_affinity = affinity_trackers[set][way].last_access_timestamp;
        uint64_t spatial_affinity = affinity_trackers[set][way].spatial_affinity_score;

        if (temporal_affinity < min_temporal_affinity ||
            (temporal_affinity == min_temporal_affinity && spatial_affinity < min_spatial_affinity)) {
            victim_way = way;
            min_temporal_affinity = temporal_affinity;
            min_spatial_affinity = spatial_affinity;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update last access timestamp
    affinity_trackers[set][way].last_access_timestamp = (uint64_t)cpu + (uint64_t)set + (uint64_t)way;

    // Calculate and update spatial affinity score
    if (hit) {
        uint64_t cache_line_addr = paddr >> 6; // assuming 64-byte cache lines
        uint64_t spatial_affinity = 0;
        for (uint32_t i = 0; i < LLC_WAYS; i++) {
            if (i != way && current_set[i].valid) {
                uint64_t other_cache_line_addr = current_set[i].address >> 6;
                spatial_affinity += (abs((int64_t)cache_line_addr - (int64_t)other_cache_line_addr) < 16) ? 1 : 0;
            }
        }
        affinity_trackers[set][way].spatial_affinity_score = spatial_affinity;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optional: print final statistics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: print progress statistics
}
#include <vector>
#include <cstdint>
#include <iostream>
#include <limits>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

uint64_t global_miss = 0;
uint32_t hit_counts[NUM_CORE][LLC_SETS][LLC_WAYS] = {{{0}}};
uint64_t last_miss_counts[NUM_CORE][LLC_SETS][LLC_WAYS] = {{{0}}};

void InitReplacementState() {
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                hit_counts[cpu][set][way] = 0;
                last_miss_counts[cpu][set][way] = 0;
            }
        }
    }
}

uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    float min_score = std::numeric_limits<float>::max();

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (current_set[way] != nullptr) {
            uint32_t hit_count = hit_counts[cpu][set][way];
            uint64_t last_miss = last_miss_counts[cpu][set][way];
            uint64_t denominator = global_miss - last_miss + 1;
            if (denominator == 0) denominator = 1;
            float score = static_cast<float>(hit_count) / denominator;

            if (score < min_score) {
                min_score = score;
                victim_way = way;
            } else if (score == min_score) {
                if (hit_count < hit_counts[cpu][set][victim_way]) {
                    victim_way = way;
                }
            }
        }
    }

    return victim_way;
}

void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (!hit) {
        global_miss++;
        hit_counts[cpu][set][way] = 0;
        last_miss_counts[cpu][set][way] = global_miss;
    } else {
        hit_counts[cpu][set][way]++;
        last_miss_counts[cpu][set][way] = global_miss;
    }
}

void PrintStats() {
    // Optional: print statistics here
}

void PrintStats_Heartbeat() {
    // Optional: print periodic statistics here
}
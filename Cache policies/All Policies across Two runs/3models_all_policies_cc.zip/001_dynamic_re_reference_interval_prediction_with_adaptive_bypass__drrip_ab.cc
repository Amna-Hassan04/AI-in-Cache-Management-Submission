#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ---------- RRIP parameters ---------- */
static const uint8_t MAX_RRPV = 3;          // 2‑bit RRIP (values 0‑3)
static const uint8_t INSERT_RRPV = MAX_RRPV - 1; // normal insertion value
static const uint8_t BYPASS_RRPV = MAX_RRPV;     // bypass insertion value

/* ---------- Adaptive bypass parameters ---------- */
static const uint8_t BYPASS_THRESHOLD = 2; // frequency < this → bypass

/* ---------- Per‑line metadata ---------- */
static uint8_t rrpv[LLC_SETS][LLC_WAYS];   // RRIP value per line
static uint8_t freq[LLC_SETS][LLC_WAYS];   // 8‑bit saturating frequency counter

/* ---------- Global statistics ---------- */
static uint64_t bypass_cnt = 0;
static uint64_t total_insertions = 0;

/* ---------- Helper: saturating increment ---------- */
static inline void sat_inc(uint8_t &c, uint8_t max = 255) {
    if (c < max) ++c;
}

/* ---------- Initialize replacement state ---------- */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            rrpv[s][w] = MAX_RRPV;   // start as “very old”
            freq[s][w] = 0;
        }
    }
    bypass_cnt = 0;
    total_insertions = 0;
}

/* ---------- Choose victim in a set ---------- */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // RRIP victim search: look for line with RRPV == MAX_RRPV
    while (true) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            if (rrpv[set][way] == MAX_RRPV) {
                return way;   // victim found
            }
        }
        // No line with MAX_RRPV → increment all RRPVs in this set
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            if (rrpv[set][way] < MAX_RRPV)
                ++rrpv[set][way];
        }
        // Loop again; now at least one line will have MAX_RRPV
    }
}

/* ---------- Update replacement state after each access ---------- */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Hit: promote line to most-recently‑used prediction
        rrpv[set][way] = 0;
        sat_inc(freq[set][way]);   // increase its frequency counter
        return;
    }

    // ----- Miss handling (insertion) -----
    ++total_insertions;

    // Determine whether we should bypass (treat as cold)
    bool do_bypass = (freq[set][way] < BYPASS_THRESHOLD);

    if (do_bypass) {
        rrpv[set][way] = BYPASS_RRPV;   // will be evicted immediately
        ++bypass_cnt;
    } else {
        rrpv[set][way] = INSERT_RRPV;   // normal RRIP insertion
    }

    // Reset frequency for the newly inserted line
    freq[set][way] = 1;   // first reference counted as 1
}

/* ---------- End‑of‑simulation statistics ---------- */
void PrintStats() {
    std::cout << "=== DRRIP-AB Replacement Policy Stats ===\n";
    std::cout << "  Total miss insertions : " << total_insertions << "\n";
    std::cout << "  Bypass insertions      : " << bypass_cnt << "\n";
    if (total_insertions > 0) {
        double pct = 100.0 * bypass_cnt / (double)total_insertions;
        std::cout << "  Bypass ratio          : " << pct << " %\n";
    }
}

/* ---------- Optional heartbeat (periodic) ---------- */
void PrintStats_Heartbeat() {
    // For large simulations you may want a lighter‑weight heartbeat.
    // Here we just reuse the final stats (can be called periodically).
    PrintStats();
}
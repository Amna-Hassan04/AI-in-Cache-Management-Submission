#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define PROXIMITY_WINDOW_SIZE 16

// Structure to track cache line metadata
struct CacheLineMetadata {
  uint64_t last_access_time;
  uint32_t proximity_count;
};

// Array to store metadata for all cache lines
CacheLineMetadata metadata[LLC_SETS * LLC_WAYS];

// Initialize replacement state
void InitReplacementState() {
  for (uint32_t i = 0; i < LLC_SETS * LLC_WAYS; i++) {
    metadata[i].last_access_time = 0;
    metadata[i].proximity_count = 0;
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint32_t victim_way = 0;
  uint64_t min_last_access_time = UINT64_MAX;
  uint32_t min_proximity_count = UINT32_MAX;

  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint32_t index = set * LLC_WAYS + way;
    if (metadata[index].last_access_time < min_last_access_time) {
      min_last_access_time = metadata[index].last_access_time;
      min_proximity_count = metadata[index].proximity_count;
      victim_way = way;
    } else if (metadata[index].last_access_time == min_last_access_time) {
      if (metadata[index].proximity_count < min_proximity_count) {
        min_proximity_count = metadata[index].proximity_count;
        victim_way = way;
      }
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  uint32_t index = set * LLC_WAYS + way;
  metadata[index].last_access_time = champsim_crc2::cycle;

  // Update proximity count
  uint64_t addr_diff = (paddr > PC) ? (paddr - PC) : (PC - paddr);
  if (addr_diff <= PROXIMITY_WINDOW_SIZE) {
    metadata[index].proximity_count++;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print final stats
  std::cout << "LRU-PROX stats:" << std::endl;
  // Add code to print relevant statistics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print progress stats
  std::cout << "LRU-PROX heartbeat stats:" << std::endl;
  // Add code to print relevant statistics
}
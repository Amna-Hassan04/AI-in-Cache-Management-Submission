// ASRP – Adaptive Signature‑Based Reuse Prediction
// ------------------------------------------------
// This file follows the ChampSim replacement‑policy template.

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)   // total number of sets
#define LLC_WAYS 16                  // associativity

/* ------------------------------------------------------------------ *
 *  Configuration parameters
 * ------------------------------------------------------------------ */
constexpr uint32_t RRPV_MAX   = 3;          // 2‑bit RRIP
constexpr uint32_t INSERT_HOT = 0;          // RRPV for hot signatures
constexpr uint32_t INSERT_COLD = 2;         // RRPV for cold signatures

// Reuse‑Signature Table (tiny predictor)
constexpr uint32_t RST_SIZE   = 1 << 12;    // 4096 entries
constexpr uint32_t RST_WAYS   = 4;         // 4‑way set‑associative
constexpr uint32_t RST_COUNTER_MAX = 3;    // 2‑bit saturating

struct RST_Entry {
    uint16_t tag;          // upper bits of PC (signature)
    uint8_t  counter;      // 2‑bit saturating counter
    uint8_t  lru;          // simple LRU inside the RST set
};

static uint8_t  rrpv[LLC_SETS][LLC_WAYS];          // per‑line RRIP values
static RST_Entry rst[RST_SIZE][RST_WAYS];         // predictor table

// statistics
static uint64_t asrp_hits = 0, asrp_misses = 0;
static uint64_t asrp_hot_insert = 0, asrp_cold_insert = 0;

/* ------------------------------------------------------------------ *
 *  Helper functions for the Reuse‑Signature Table
 * ------------------------------------------------------------------ */
inline uint32_t rst_index(uint64_t pc) {
    // lower bits of PC index the RST set
    return (pc >> 2) & (RST_SIZE - 1);
}
inline uint16_t rst_tag(uint64_t pc) {
    // remaining bits become the tag
    return (pc >> 14) & 0xFFFF;
}

// Find (or allocate) an entry for a given PC signature
static RST_Entry* rst_lookup(uint64_t pc, bool allocate) {
    uint32_t set = rst_index(pc);
    uint16_t tag = rst_tag(pc);

    // search for a hit
    for (uint32_t w = 0; w < RST_WAYS; ++w) {
        if (rst[set][w].tag == tag) {
            // update LRU (move to MRU)
            uint8_t old_lru = rst[set][w].lru;
            for (uint32_t k = 0; k < RST_WAYS; ++k)
                if (rst[set][k].lru < old_lru) rst[set][k].lru++;
            rst[set][w].lru = 0;
            return &rst[set][w];
        }
    }

    if (!allocate) return nullptr;

    // miss – find LRU victim inside the RST set
    uint32_t victim = 0;
    uint8_t max_lru = 0;
    for (uint32_t w = 0; w < RST_WAYS; ++w) {
        if (rst[set][w].lru > max_lru) {
            max_lru = rst[set][w].lru;
            victim = w;
        }
    }
    // replace victim
    rst[set][victim].tag = tag;
    rst[set][victim].counter = 1;          // start from weak‑cold
    // update LRU
    for (uint32_t k = 0; k < RST_WAYS; ++k)
        if (rst[set][k].lru < max_lru) rst[set][k].lru++;
    rst[set][victim].lru = 0;
    return &rst[set][victim];
}

/* ------------------------------------------------------------------ *
 *  Required ChampSim callbacks
 * ------------------------------------------------------------------ */
void InitReplacementState() {
    // initialise RRIP values to max (most evictable)
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            rrpv[s][w] = RRPV_MAX;

    // clear RST
    for (uint32_t s = 0; s < RST_SIZE; ++s)
        for (uint32_t w = 0; w < RST_WAYS; ++w) {
            rst[s][w].tag = 0xFFFF;
            rst[s][w].counter = 1;   // weak‑cold
            rst[s][w].lru = w;
        }
}

/* ------------------------------------------------------------------ *
 *  Victim selection – classic SRRIP walk
 * ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // SRRIP style: look for line with RRPV == RRPV_MAX
    while (true) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            if (rrpv[set][w] == RRPV_MAX) {
                return w;                     // victim found
            }
        }
        // increment all RRPVs (aging step)
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            if (rrpv[set][w] < RRPV_MAX) rrpv[set][w]++;
        }
    }
}

/* ------------------------------------------------------------------ *
 *  Update state after every access
 * ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // --------------------------------------------------------------
    // 1) Update the RST predictor for this PC signature
    // --------------------------------------------------------------
    RST_Entry *entry = rst_lookup(PC, true);
    if (hit) {
        // successful reuse – strengthen hotness (saturating up)
        if (entry->counter < RST_COUNTER_MAX) entry->counter++;
    } else {
        // miss – weaken hotness (saturating down)
        if (entry->counter > 0) entry->counter--;
    }

    // --------------------------------------------------------------
    // 2) RRIP bookkeeping
    // --------------------------------------------------------------
    if (hit) {
        // On hit, reset the line's RRPV to 0 (most recently used)
        rrpv[set][way] = 0;
        ++asrp_hits;
    } else {
        // Miss: we are about to insert a new line in 'way'
        // Choose insertion RRPV based on predictor confidence
        if (entry->counter >= 2) {          // hot signature
            rrpv[set][way] = INSERT_HOT;
            ++asrp_hot_insert;
        } else {
            rrpv[set][way] = INSERT_COLD;
            ++asrp_cold_insert;
        }
        ++asrp_misses;
    }

    // --------------------------------------------------------------
    // 3) Optional: occasional decay of all predictor counters
    //    (simple stochastic decay – executed on every update with
    //     a 1/1024 probability)
    // --------------------------------------------------------------
    if ((cpu ^ set ^ way) & 0x3FF) { // cheap pseudo‑random check
        // do nothing
    } else {
        for (uint32_t s = 0; s < RST_SIZE; ++s)
            for (uint32_t w = 0; w < RST_WAYS; ++w)
                if (rst[s][w].counter > 0) rst[s][w].counter--;
    }
}

/* ------------------------------------------------------------------ *
 *  Statistics printing
 * ------------------------------------------------------------------ */
void PrintStats() {
    std::cout << "=== ASRP Statistics ===\n";
    std::cout << "  Hits                : " << asrp_hits << "\n";
    std::cout << "  Misses              : " << asrp_misses << "\n";
    std::cout << "  Hot insertions      : " << asrp_hot_insert << "\n";
    std::cout << "  Cold insertions     : " << asrp_cold_insert << "\n";
    uint64_t total = asrp_hits + asrp_misses;
    if (total) {
        double hit_rate = 100.0 * asrp_hits / (double)total;
        std::cout << "  Hit rate            : " << hit_rate << " %\n";
    }
}

void PrintStats_Heartbeat() {
    // Called periodically by ChampSim – we keep it empty or print a short line
    // Uncomment the line below for a lightweight heartbeat.
    // std::cout << "[ASRP] Hits:" << asrp_hits << " Misses:" << asrp_misses << "\n";
}
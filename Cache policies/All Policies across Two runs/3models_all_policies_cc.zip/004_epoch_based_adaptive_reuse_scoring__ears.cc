#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/*--------------------  Configuration --------------------*/
static const uint64_t EPOCH_LENGTH   = 64ULL * 1024;   // accesses per epoch
static const float    DECAY_FACTOR   = 0.70f;         // 0.0 … 1.0
static const uint32_t BLOOM_BITS     = 64;            // 64‑bit bitmap per set
static const uint32_t BLOOM_HASHES   = 3;             // number of hash functions

/*--------------------  Metadata structures --------------------*/
static uint64_t   global_access_cnt = 0;               // counts all accesses
static uint64_t   current_epoch     = 0;               // epoch index
static uint64_t   last_epoch_access = 0;               // when we entered current epoch

// per‑line metadata
static uint64_t   last_access[LLC_SETS][LLC_WAYS];      // cycle of last reference
static uint16_t   decayed_cnt[LLC_SETS][LLC_WAYS];      // decayed frequency (saturating)

// per‑set Bloom filter (simple 64‑bit bitmap)
static uint64_t   bloom_filter[LLC_SETS];               // cleared each epoch

/*--------------------  Helper hash functions --------------------*/
static inline uint32_t bloom_hash(uint64_t addr, uint32_t seed) {
    // Very cheap mixing – enough for a Bloom hint
    uint64_t v = addr ^ (addr >> (seed + 13));
    v *= 0x9e3779b97f4a7c15ULL;
    v ^= v >> 33;
    return static_cast<uint32_t>(v);
}

/*--------------------  Epoch handling --------------------*/
static inline void maybe_advance_epoch() {
    if (global_access_cnt - last_epoch_access >= EPOCH_LENGTH) {
        // advance epoch
        ++current_epoch;
        last_epoch_access = global_access_cnt;

        // decay all counters and clear Bloom filters
        for (uint32_t s = 0; s < LLC_SETS; ++s) {
            bloom_filter[s] = 0ULL;
            for (uint32_t w = 0; w < LLC_WAYS; ++w) {
                // multiply by DECAY_FACTOR, rounding down, keep at least 1 if non‑zero
                uint32_t old = decayed_cnt[s][w];
                uint32_t neu = static_cast<uint32_t>(old * DECAY_FACTOR);
                decayed_cnt[s][w] = static_cast<uint16_t>(neu);
            }
        }
    }
}

/*--------------------  Initialization --------------------*/
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        bloom_filter[s] = 0ULL;
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            last_access[s][w]   = 0;
            decayed_cnt[s][w]   = 0;
        }
    }
    global_access_cnt = 0;
    current_epoch     = 0;
    last_epoch_access = 0;
}

/*--------------------  Victim selection --------------------*/
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    maybe_advance_epoch();
    ++global_access_cnt;                     // count this access for epoch logic

    // First look for an invalid line (CHAMPSIM marks it with valid==0)
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (current_set[w].valid == 0)
            return w;                       // free slot
    }

    // No free slot → compute EARS score for each way and pick min
    uint32_t victim_way = 0;
    double   best_score = DBL_MAX;
    uint64_t now = __builtin_ia32_rdtsc();   // cheap timestamp (cycles)

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        // age component
        uint64_t age = now - last_access[set][w] + 1;   // avoid div‑by‑zero

        // decayed frequency
        uint32_t freq = decayed_cnt[set][w];

        // Bloom boost: 2 if address hashes into current filter, else 1
        uint32_t boost = 1;
        for (uint32_t h = 0; h < BLOOM_HASHES; ++h) {
            uint32_t bit = bloom_hash(current_set[w].address, h) % BLOOM_BITS;
            if (bloom_filter[set] & (1ULL << bit)) {
                boost = 2;
                break;
            }
        }

        double score = static_cast<double>(freq * boost) / static_cast<double>(age);
        if (score < best_score) {
            best_score = score;
            victim_way = w;
        }
    }
    return victim_way;
}

/*--------------------  State update --------------------*/
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    maybe_advance_epoch();
    ++global_access_cnt;                     // keep epoch accounting consistent

    uint64_t now = __builtin_ia32_rdtsc();

    if (hit) {
        // Hit: refresh recency and bump frequency (saturate at UINT16_MAX)
        last_access[set][way] = now;
        if (decayed_cnt[set][way] < UINT16_MAX)
            ++decayed_cnt[set][way];
    } else {
        // Miss → we are inserting a new line at <set,way>
        last_access[set][way] = now;
        decayed_cnt[set][way] = 1;           // start with a fresh count

        // Insert the *missed* address into the Bloom filter for future hints
        for (uint32_t h = 0; h < BLOOM_HASHES; ++h) {
            uint32_t bit = bloom_hash(paddr, h) % BLOOM_BITS;
            bloom_filter[set] |= (1ULL << bit);
        }
    }
}

/*--------------------  Statistics (optional) --------------------*/
static uint64_t epoch_transitions = 0;
static uint64_t total_hits        = 0;
static uint64_t total_misses      = 0;

void PrintStats() {
    std::cout << "EARS statistics:\n";
    std::cout << "  Epoch transitions   : " << epoch_transitions << "\n";
    std::cout << "  Total accesses      : " << global_access_cnt << "\n";
    std::cout << "  Hits                : " << total_hits << "\n";
    std::cout << "  Misses              : " << total_misses << "\n";
}

void PrintStats_Heartbeat() {
    // Could be called every few million accesses – left empty for now
}

/*---------------------------------------------------------------*/
/* Note:
 * - The timestamp source (`__builtin_ia32_rdtsc`) is just an example;
 *   CHAMPSIM typically provides a cycle counter (`current_cycle`).
 * - The Bloom filter is deliberately tiny (64 bits) to keep per‑set
 *   overhead negligible; three simple XOR‑based hashes give a modest
 *   false‑positive rate that works well as a “reuse hint”.
 * - All arithmetic is deliberately inexpensive to keep the replacement
 *   policy fast enough for cycle‑accurate simulation.
 *---------------------------------------------------------------*/
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

#define TYPE_INSTR 0
#define TYPE_DATA  1

// Structure to track metadata for each cache line
struct LineMetadata {
    uint8_t type;         // 0 for instruction, 1 for data
    uint64_t last_access; // Recency metric (timestamp)
    uint32_t access_count;// Frequency metric
};

// Cache-wide metadata
std::vector<std::vector<LineMetadata>> metadata;
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    metadata.resize(NUM_CORE);
    for (auto& core_meta : metadata) {
        core_meta.resize(LLC_SETS * LLC_WAYS);
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    const uint32_t start = set * LLC_WAYS;
    const uint32_t end = start + LLC_WAYS;
    
    uint32_t victim = 0;
    uint32_t min_count = UINT32_MAX;
    uint32_t d_type_count = 0;
    uint32_t i_type_count = 0;

    // Count type distribution and find victim
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        uint32_t index = start + way;
        if (metadata[cpu][index].type == TYPE_DATA) {
            d_type_count++;
        } else {
            i_type_count++;
        }
        
        if (metadata[cpu][index].type == TYPE_DATA) {
            if (metadata[cpu][index].access_count < min_count) {
                min_count = metadata[cpu][index].access_count;
                victim = way;
            }
        } else {
            if (metadata[cpu][index].last_access < metadata[cpu][index].last_access) {
                victim = way;
            }
        }
    }

    // Adapt type ratio
    if (d_type_count > i_type_count * 2) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            uint32_t index = start + way;
            if (metadata[cpu][index].type == TYPE_DATA && metadata[cpu][index].access_count < min_count) {
                min_count = metadata[cpu][index].access_count;
                victim = way;
            }
        }
    } else if (i_type_count > d_type_count * 2) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            uint32_t index = start + way;
            if (metadata[cpu][index].type == TYPE_INSTR && metadata[cpu][index].last_access < metadata[cpu][index].last_access) {
                victim = way;
            }
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    const uint32_t index = set * LLC_WAYS + way;
    if (hit) {
        metadata[cpu][index].last_access = global_timestamp++;
        if (type == TYPE_DATA) {
            metadata[cpu][index].access_count++;
        }
    } else {
        metadata[cpu][index].type = type;
        metadata[cpu][index].last_access = global_timestamp++;
        metadata[cpu][index].access_count = 1;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics
    uint64_t total_instr = 0;
    uint64_t total_data = 0;
    
    for (auto& core_meta : metadata) {
        for (auto& line : core_meta) {
            if (line.type == TYPE_INSTR) total_instr++;
            else total_data++;
        }
    }
    
    std::cout << "Total Instruction Lines: " << total_instr << std::endl;
    std::cout << "Total Data Lines: " << total_data << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example heartbeat statistics
    std::cout << "Heartbeat: Cache metadata updated." << std::endl;
}
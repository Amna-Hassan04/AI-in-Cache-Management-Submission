#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track frequency and spatial locality
struct TSFARMetadata {
    uint32_t frequency;
    uint32_t spatialLocality;
    uint64_t lastAccessTime;
};

// Array to store metadata for each cache line
TSFARMetadata metadata[LLC_SETS][LLC_WAYS];

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            metadata[set][way].frequency = 0;
            metadata[set][way].spatialLocality = 0;
            metadata[set][way].lastAccessTime = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victimWay = 0;
    uint32_t minScore = UINT32_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint32_t score = metadata[set][way].frequency + metadata[set][way].spatialLocality;
        score += (current_set[way].valid) ? 0 : UINT32_MAX; // Prefer valid lines
        if (score < minScore) {
            minScore = score;
            victimWay = way;
        } else if (score == minScore) {
            // Break tie with LRU
            if (metadata[set][way].lastAccessTime < metadata[set][victimWay].lastAccessTime) {
                victimWay = way;
            }
        }
    }
    return victimWay;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        metadata[set][way].frequency++;
        metadata[set][way].lastAccessTime = champsim_crc2::cycle;
        // Update spatial locality for nearby lines
        for (uint32_t nearbyWay = 0; nearbyWay < LLC_WAYS; nearbyWay++) {
            if (abs((int64_t)current_set[nearbyWay].address - (int64_t)paddr) <= 64) {
                metadata[set][nearbyWay].spatialLocality++;
            }
        }
    } else {
        // On miss, update victim line's frequency and spatial locality to 0
        metadata[set][way].frequency = 0;
        metadata[set][way].spatialLocality = 0;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "TSFAR Stats:" << std::endl;
    // Print aggregated frequency and spatial locality stats
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Print periodic progress stats
}
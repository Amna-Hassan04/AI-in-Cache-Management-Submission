#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structures
std::vector<uint64_t> frequency(LLC_SETS * LLC_WAYS, 0);
std::vector<uint64_t> recency(LLC_SETS * LLC_WAYS, 0);
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    frequency.assign(LLC_SETS * LLC_WAYS, 0);
    recency.assign(LLC_SETS * LLC_WAYS, 0);
    global_timestamp = 0;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;
    uint32_t start = set * LLC_WAYS;
    uint32_t end = start + LLC_WAYS;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint32_t index = start + way;
        uint64_t score = (frequency[index] * 0.7) + (recency[index] * 0.3);
        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        uint32_t index = set * LLC_WAYS + way;
        frequency[index]++;
        recency[index] = global_timestamp++;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    uint64_t total_frequency = 0;
    for (uint64_t freq : frequency) {
        total_frequency += freq;
    }
    std::cout << "Total frequency: " << total_frequency << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: Print average frequency and recency
    double avg_frequency = 0.0;
    double avg_recency = 0.0;
    for (uint64_t freq : frequency) {
        avg_frequency += freq;
    }
    for (uint64_t rec : recency) {
        avg_recency += rec;
    }
    avg_frequency /= frequency.size();
    avg_recency /= recency.size();
    
    std::cout << "Average frequency: " << avg_frequency << std::endl;
    std::cout << "Average recency: " << avg_recency << std::endl;
}
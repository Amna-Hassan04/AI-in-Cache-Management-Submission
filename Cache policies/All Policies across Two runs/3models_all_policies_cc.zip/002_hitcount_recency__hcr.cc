#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structures
std::vector<std::vector<uint64_t>> hit_count;  // Hit count for each line
std::vector<std::vector<uint64_t>> last_access; // Last access time for each line

// Initialize replacement state
void InitReplacementState() {
    hit_count = std::vector<std::vector<uint64_t>>(NUM_CORE, std::vector<uint64_t>(LLC_SETS, 0));
    last_access = std::vector<std::vector<uint64_t>>(NUM_CORE, std::vector<uint64_t>(LLC_SETS, 0));
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_hits = std::numeric_limits<uint64_t>::max();
    uint64_t oldest_access = std::numeric_limits<uint64_t>::max();
    
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t current_hits = hit_count[cpu][set];
        uint64_t current_last = last_access[cpu][set];
        
        // Find the line with the smallest hit count
        if (current_hits < min_hits) {
            min_hits = current_hits;
            victim_way = way;
            oldest_access = current_last;
        } 
        // If hit counts are equal, choose the least recently used
        else if (current_hits == min_hits && current_last < oldest_access) {
            victim_way = way;
            oldest_access = current_last;
        }
    }
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Increment hit count for the accessed line
        hit_count[cpu][set]++;
        // Update last access time
        last_access[cpu][set] = PC;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "HitCount-Recency Policy Statistics:" << std::endl;
    std::cout << "Total Hits: " << hit_count[0][0] << std::endl;
    // Add additional statistics if needed
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    std::cout << "HitCount-Recency Policy Heartbeat:" << std::endl;
    std::cout << "Sample Hit Count: " << hit_count[0][0] << std::endl;
    // Add additional periodic statistics if needed
}
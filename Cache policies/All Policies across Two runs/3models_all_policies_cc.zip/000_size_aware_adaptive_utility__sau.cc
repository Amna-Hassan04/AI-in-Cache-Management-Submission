#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track metadata for each cache line
struct CacheLineMetadata {
    uint64_t last_access_time;
    uint16_t access_count;
    uint8_t size_category;  // 0: small, 1: medium, 2: large
    uint8_t utility_score;
    bool is_instruction;
};

std::vector<CacheLineMetadata> cache_metadata(LLC_SETS * LLC_WAYS);

// Initialize replacement state
void InitReplacementState() {
    for (size_t i = 0; i < cache_metadata.size(); ++i) {
        cache_metadata[i].last_access_time = 0;
        cache_metadata[i].access_count = 0;
        cache_metadata[i].size_category = 0;
        cache_metadata[i].utility_score = 0;
        cache_metadata[i].is_instruction = false;
    }
}

// Calculate the size category of a block
uint8_t GetSizeCategory(uint64_t size) {
    if (size <= 32) return 0;   // Small block
    if (size <= 64) return 1;   // Medium block
    return 2;                   // Large block
}

// Update the utility score of a cache line
void UpdateUtilityScore(uint32_t set, uint32_t way, uint64_t PC, bool hit) {
    CacheLineMetadata& meta = cache_metadata[set * LLC_WAYS + way];
    if (hit) {
        meta.access_count++;
        meta.last_access_time = __builtin_ia32_rdtscp(&PC);
        meta.utility_score = std::min(255, meta.utility_score + 16);
    } else {
        meta.utility_score = std::max(0, meta.utility_score - 8);
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint8_t min_size_category = 2;  // Start with large blocks
    uint8_t min_utility = 255;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        const BLOCK *block = &current_set[way];
        uint64_t addr = block->paddr;
        CacheLineMetadata meta = cache_metadata[set * LLC_WAYS + way];

        if (!block->valid) continue;

        uint8_t size_category = GetSizeCategory(block->size);
        if (size_category < min_size_category ||
            (size_category == min_size_category && meta.utility_score < min_utility)) {
            min_size_category = size_category;
            min_utility = meta.utility_score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    CacheLineMetadata& meta = cache_metadata[set * LLC_WAYS + way];
    meta.is_instruction = (type == 0);  // Assume type=0 is instruction
    UpdateUtilityScore(set, way, PC, hit);
}

// Print end-of-simulation statistics
void PrintStats() {
    uint64_t total_accesses = 0;
    uint64_t total_utility = 0;

    for (const auto& meta : cache_metadata) {
        total_accesses += meta.access_count;
        total_utility += meta.utility_score;
    }

    std::cout << "SAU Policy Statistics:" << std::endl;
    std::cout << "Total Accesses: " << total_accesses << std::endl;
    std::cout << "Average Utility Score: " << total_utility / cache_metadata.size() << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    std::cout << "SAU Policy Heartbeat" << std::endl;
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct BlockMetadata {
    uint64_t frequency;  // Tracks the number of accesses
    uint64_t recency;    // Timestamp of last access
};

std::vector<std::vector<BlockMetadata>> freq_recency_metadata;

// Global timestamp counter
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    freq_recency_metadata.resize(NUM_CORE);
    for (auto& core : freq_recency_metadata) {
        core.resize(LLC_SETS);
        for (auto& set : core) {
            set.resize(LLC_WAYS);
            for (auto& meta : set) {
                meta.frequency = 0;
                meta.recency = 0;
            }
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t score = freq_recency_metadata[cpu][set][way].frequency * 0.5 + global_timestamp - freq_recency_metadata[cpu][set][way].recency;
        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    global_timestamp++;
    if (hit) {
        freq_recency_metadata[cpu][set][way].frequency++;
        freq_recency_metadata[cpu][set][way].recency = global_timestamp;
    } else {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            freq_recency_metadata[cpu][set][way].recency = global_timestamp;
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "Frequency-Recency Hybrid Policy Statistics:" << std::endl;
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                std::cout << "CPU: " << cpu << ", Set: " << set << ", Way: " << way 
                          << ", Frequency: " << freq_recency_metadata[cpu][set][way].frequency
                          << ", Recency: " << freq_recency_metadata[cpu][set][way].recency
                          << std::endl;
            }
        }
    }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    std::cout << "Frequency-Recency Hybrid Heartbeat:" << std::endl;
    std::cout << "Global Timestamp: " << global_timestamp << std::endl;
}
/*=====================================================================
   Entropy‑Guided Adaptive Reuse Prediction (EGARP)
   ------------------------------------------------
   This file implements the skeleton required by ChampSim.
   The core idea is described in the Policy Description above.
=====================================================================*/

#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/*---------------------------  Parameters  ---------------------------*/
static const uint8_t ENTROPY_LOW   = 100;   // 0‑255 scaled entropy threshold
static const uint8_t COUNTER_MAX  = 7;     // 3‑bit saturating counter
static const uint8_t HIST_SIZE    = 8;     // per‑set PC histogram entries

/*---------------------------  Metadata  ----------------------------*/
/* Per‑line metadata */
struct LineInfo {
    uint64_t last_access;   // cycle of last access (for LRU age)
    uint8_t  reuse_cnt;     // 3‑bit reuse‑distance estimator
};

/* Per‑set PC histogram entry */
struct PcEntry {
    uint64_t pc;   // program counter that accessed the set
    uint8_t  freq; // 4‑bit frequency (saturating)
};

/* Global replacement state */
static LineInfo line_info[LLC_SETS][LLC_WAYS];
static PcEntry  pc_hist[LLC_SETS][HIST_SIZE];

/*---------------------------  Helpers  -----------------------------*/
/* Simple 8‑bit entropy estimator from the histogram */
static uint8_t compute_set_entropy(uint32_t set) {
    uint32_t total = 0;
    for (int i = 0; i < HIST_SIZE; ++i) total += pc_hist[set][i].freq;

    if (total == 0) return 0;                     // empty set → zero entropy

    double entropy = 0.0;
    for (int i = 0; i < HIST_SIZE; ++i) {
        if (pc_hist[set][i].freq == 0) continue;
        double p = double(pc_hist[set][i].freq) / double(total);
        entropy -= p * log2(p);
    }
    /* Scale to 0‑255 (max entropy for 8 entries ≈ 3 bits) */
    uint8_t scaled = uint8_t(std::min(255.0, entropy * 85.0)); // 3*85≈255
    return scaled;
}

/* Update the PC histogram for a set */
static void update_pc_histogram(uint32_t set, uint64_t pc) {
    // Search for existing entry
    for (int i = 0; i < HIST_SIZE; ++i) {
        if (pc_hist[set][i].pc == pc) {
            if (pc_hist[set][i].freq < 15) pc_hist[set][i].freq++;
            return;
        }
    }
    // No match → replace the least‑frequent entry
    int victim = 0;
    uint8_t minf = pc_hist[set][0].freq;
    for (int i = 1; i < HIST_SIZE; ++i) {
        if (pc_hist[set][i].freq < minf) {
            minf = pc_hist[set][i].freq;
            victim = i;
        }
    }
    pc_hist[set][victim].pc   = pc;
    pc_hist[set][victim].freq = 1;
}

/*----------------------  Required Hooks  ---------------------------*/
/* Initialize replacement state */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            line_info[s][w].last_access = 0;
            line_info[s][w].reuse_cnt   = 0;
        }
        for (uint32_t h = 0; h < HIST_SIZE; ++h) {
            pc_hist[s][h].pc   = 0;
            pc_hist[s][h].freq = 0;
        }
    }
}

/* Choose victim line in the set */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint8_t entropy = compute_set_entropy(set);

    // ---------- Predictable phase (low entropy) ----------
    if (entropy <= ENTROPY_LOW) {
        // Evict the line with the smallest reuse counter;
        // tie‑break with LRU age.
        uint32_t victim_way = 0;
        uint8_t  min_cnt    = COUNTER_MAX + 1;
        uint64_t oldest_age = 0;

        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            // ignore invalid (empty) lines – they are ideal victims
            if (current_set[w].valid == 0) return w;

            uint8_t cnt = line_info[set][w].reuse_cnt;
            uint64_t age = current_cycle - line_info[set][w].last_access;

            if (cnt < min_cnt ||
               (cnt == min_cnt && age > oldest_age)) {
                min_cnt    = cnt;
                oldest_age = age;
                victim_way = w;
            }
        }
        return victim_way;
    }

    // ---------- Unpredictable phase (high entropy) ----------
    // Pure LRU: evict the oldest line.
    uint32_t victim_way = 0;
    uint64_t oldest_age = 0;
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (current_set[w].valid == 0) return w;
        uint64_t age = current_cycle - line_info[set][w].last_access;
        if (age > oldest_age) {
            oldest_age = age;
            victim_way = w;
        }
    }
    return victim_way;
}

/* Update replacement state */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update per‑set PC histogram (used for entropy)
    update_pc_histogram(set, PC);

    // Update per‑line metadata
    line_info[set][way].last_access = current_cycle;

    if (hit) {
        // On a hit, increase the reuse counter (saturating)
        if (line_info[set][way].reuse_cnt < COUNTER_MAX)
            line_info[set][way].reuse_cnt++;
    } else {
        // On a miss (new line inserted), initialise the reuse counter
        uint8_t entropy = compute_set_entropy(set);
        if (entropy <= ENTROPY_LOW) {
            // Predictable set → start with a relatively high counter
            line_info[set][way].reuse_cnt = COUNTER_MAX;
        } else {
            // Unpredictable set → start low, let it grow only if reused
            line_info[set][way].reuse_cnt = 1;
        }
    }
}

/* Print end‑of‑simulation statistics */
void PrintStats() {
    // Optional: could report average entropy, distribution of victim
    // selections, etc. For now we keep it empty.
}

/* Print periodic statistics (heartbeat) */
void PrintStats_Heartbeat() {
    // Optional: same as above.
}
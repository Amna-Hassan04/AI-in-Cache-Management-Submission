#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track frequency and recency information
struct HFRState {
    uint32_t frequency;
    uint32_t recency;
};

// Initialize replacement state
void InitReplacementState() {
    static std::vector<HFRState> hfr_state(LLC_SETS * LLC_WAYS);
    for (auto& state : hfr_state) {
        state.frequency = 0;
        state.recency = 0;
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    static std::vector<HFRState> hfr_state(LLC_SETS * LLC_WAYS);
    uint32_t min_frequency = UINT32_MAX;
    uint32_t min_recency = UINT32_MAX;
    uint32_t victim_way = 0;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint32_t index = set * LLC_WAYS + way;
        if (hfr_state[index].frequency < min_frequency) {
            min_frequency = hfr_state[index].frequency;
            min_recency = hfr_state[index].recency;
            victim_way = way;
        } else if (hfr_state[index].frequency == min_frequency && hfr_state[index].recency > min_recency) {
            min_recency = hfr_state[index].recency;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    static std::vector<HFRState> hfr_state(LLC_SETS * LLC_WAYS);
    uint32_t index = set * LLC_WAYS + way;

    if (hit) {
        hfr_state[index].frequency++;
        hfr_state[index].recency = 0; // Reset recency on hit
    } else {
        // Increment recency for all lines in the set
        for (uint32_t w = 0; w < LLC_WAYS; w++) {
            uint32_t idx = set * LLC_WAYS + w;
            hfr_state[idx].recency++;
        }
        hfr_state[index].frequency = 1; // Initialize frequency for new line
        hfr_state[index].recency = 0; // Reset recency for new line
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optional: Print final statistics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: Print progress statistics
}
#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to store metadata for each cache line
struct CacheLineMetadata {
    uint64_t last_access_time;
    uint64_t access_frequency;
    uint64_t last_pc;
    CacheLineMetadata() : last_access_time(0), access_frequency(0), last_pc(0) {}
};

// Initialize replacement state
void InitReplacementState() {
    // Initialize metadata structures
}

// Global hash map to track metadata for each cache line
std::unordered_map<uint64_t, CacheLineMetadata> cache_metadata;

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;
    const uint64_t current_time = PC; // Using PC as a proxy for time
    
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t addr = current_set[way].paddr;
        
        // If the line is not present in metadata, it's a new line
        if (cache_metadata.find(addr) == cache_metadata.end()) {
            cache_metadata[addr] = CacheLineMetadata();
        }
        
        // Get metadata for the current line
        CacheLineMetadata& metadata = cache_metadata[addr];
        
        // Calculate the score for the line
        uint64_t recency = current_time - metadata.last_access_time;
        uint64_t frequency = metadata.access_frequency;
        uint64_t temporal_locality = abs(current_time - metadata.last_pc);
        
        // Apply penalties/bonuses
        uint64_t score = recency + (frequency << 8) + temporal_locality;
        if (type == WRITE) {
            score += 1 << 16; // Penalty for write operations
        }
        
        // Update victim if current score is lower
        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }
    
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    const uint64_t current_time = PC;
    
    // Update metadata for the accessed line
    if (cache_metadata.find(paddr) != cache_metadata.end()) {
        CacheLineMetadata& metadata = cache_metadata[paddr];
        metadata.last_access_time = current_time;
        metadata.access_frequency++;
        metadata.last_pc = PC;
        
        // If it's a read operation, further prioritize the line
        if (type == READ) {
            metadata.access_frequency += 2;
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optional: Print any final statistics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: Print progress statistics
}
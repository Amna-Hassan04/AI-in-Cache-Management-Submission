#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"
#include <cmath> // For log2 function

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to hold entropy and frequency data for each cache line
struct LineMetadata {
    uint32_t frequency;
    double entropy;
};

std::vector<std::vector<LineMetadata>> metadata(LLC_SETS, std::vector<LineMetadata>(LLC_WAYS));

// Initialize replacement state
void InitReplacementState() {
    for (auto& set : metadata) {
        for (auto& line : set) {
            line.frequency = 0;
            line.entropy = 0.0;
        }
    }
}

// Calculate entropy for a given set
double CalculateEntropy(const std::vector<LineMetadata>& set) {
    double totalAccesses = 0.0;
    for (const auto& line : set) {
        totalAccesses += line.frequency;
    }
    double entropy = 0.0;
    for (const auto& line : set) {
        if (line.frequency > 0) {
            double prob = line.frequency / totalAccesses;
            entropy -= prob * log2(prob);
        }
    }
    return entropy;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    double maxEntropy = 0.0;
    uint32_t victimWay = 0;
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        double lineEntropy = metadata[set][way].entropy;
        if (lineEntropy > maxEntropy) {
            maxEntropy = lineEntropy;
            victimWay = way;
        }
    }
    return victimWay;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        metadata[set][way].frequency++;
    }
    // Recalculate entropy for the set
    double setEntropy = CalculateEntropy(metadata[set]);
    for (auto& line : metadata[set]) {
        line.entropy = setEntropy;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistic: Average entropy across all sets
    double totalEntropy = 0.0;
    for (const auto& set : metadata) {
        totalEntropy += CalculateEntropy(set);
    }
    double avgEntropy = totalEntropy / LLC_SETS;
    std::cout << "Average Entropy: " << avgEntropy << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Could be used to monitor entropy over time
}
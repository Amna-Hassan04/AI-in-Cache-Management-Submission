#include <vector>
#include <cstdint>
#include <iostream>
#include <cstring>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* -------------------------------------------------------------
   Tunable weights (scaled to 1024 for integer arithmetic)
   score = (α*R - β*S - γ*T) / 1024
   ------------------------------------------------------------- */
static const uint32_t ALPHA = 512;   // 0.5 * 1024
static const uint32_t BETA  = 307;   // 0.3 * 1024
static const uint32_t GAMMA = 204;   // 0.2 * 1024

/* -------------------------------------------------------------
   Per‑line metadata (packed for cache‑friendliness)
   ------------------------------------------------------------- */
struct LineMeta {
    uint64_t last_access;   // cycle of last access (recency)
    uint16_t sig_id;        // index into signature table
    uint8_t  stride_stab;   // 0..3  (2‑bit saturating counter)
    bool     valid;
};

static LineMeta line_meta[LLC_SETS][LLC_WAYS];

/* -------------------------------------------------------------
   Signature table: maps a 12‑bit signature (hash of PC) → confidence
   ------------------------------------------------------------- */
static const uint32_t SIG_TABLE_SIZE = 4096;               // 2^12
static uint16_t sig_confidence[SIG_TABLE_SIZE];            // 0..65535
static uint64_t sig_last_update[SIG_TABLE_SIZE];           // for aging

/* -------------------------------------------------------------
   Global cycle counter – supplied by the simulator (use
   `CURRENT_CYCLE` macro if available, otherwise maintain own).
   ------------------------------------------------------------- */
static uint64_t sim_cycle = 0;

/* -------------------------------------------------------------
   Helper: simple 12‑bit hash of PC (xor‑fold + mask)
   ------------------------------------------------------------- */
static inline uint16_t pc_hash(uint64_t pc) {
    return (uint16_t)((pc ^ (pc >> 12) ^ (pc >> 24)) & (SIG_TABLE_SIZE - 1));
}

/* -------------------------------------------------------------
   Optional: periodic aging of signature confidence (to forget
   stale patterns). Called from PrintStats_Heartbeat().
   ------------------------------------------------------------- */
static const uint64_t AGE_INTERVAL = 10000000ULL; // 10M cycles
static uint64_t last_age_cycle = 0;

void AgeSignatureTable() {
    for (uint32_t i = 0; i < SIG_TABLE_SIZE; ++i) {
        // simple right‑shift decay; clamp to minimum 1 to avoid zero lock‑out
        sig_confidence[i] = (sig_confidence[i] >> 1) + 1;
    }
}

/* -------------------------------------------------------------
   Initialize replacement state
   ------------------------------------------------------------- */
void InitReplacementState() {
    memset(line_meta, 0, sizeof(line_meta));
    memset(sig_confidence, 0, sizeof(sig_confidence));
    memset(sig_last_update, 0, sizeof(sig_last_update));
}

/* -------------------------------------------------------------
   Choose victim line in the set
   ------------------------------------------------------------- */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Update global cycle (the simulator usually provides this)
    sim_cycle = CURRENT_CYCLE;

    // Scan set for the line with maximal score
    uint32_t victim_way = 0;
    uint32_t max_score = 0;   // higher score = worse candidate

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        if (!line_meta[set][way].valid) {
            // Empty slot – take it immediately
            return way;
        }

        // ---- Recency component ----
        uint64_t age = sim_cycle - line_meta[set][way].last_access; // up to 2^64
        // Normalise age to 0..1023 (log‑scale to keep dynamic range)
        uint32_t R = (uint32_t) ( (age == 0) ? 0 :
                                 ( ( (uint64_t) __builtin_clzll(age) ) ^ 63 ) );

        // ---- Signature confidence component ----
        uint16_t sig = line_meta[set][way].sig_id;
        uint32_t S = sig_confidence[sig] >> 6; // bring 0..65535 -> 0..1023

        // ---- Stride stability component ----
        uint32_t T = line_meta[set][way].stride_stab * 256; // 0,256,512,768

        // ---- Composite score (higher = more evictable) ----
        // Using signed arithmetic; ensure no underflow
        int32_t raw = (int32_t)ALPHA * (int32_t)R
                    - (int32_t)BETA  * (int32_t)S
                    - (int32_t)GAMMA * (int32_t)T;
        uint32_t score = (raw < 0) ? 0 : (uint32_t)raw;

        if (score > max_score) {
            max_score = score;
            victim_way = way;
        }
    }
    return victim_way;
}

/* -------------------------------------------------------------
   Update replacement state after each access
   ------------------------------------------------------------- */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    sim_cycle = CURRENT_CYCLE;   // keep cycle up‑to‑date

    // ---- Compute signature for this access ----
    uint16_t sig = pc_hash(PC);

    // ---- Update signature confidence ----------------
    // On a hit we boost confidence, on a miss we decay a little.
    if (hit) {
        // Strong reinforcement (max at 65535)
        if (sig_confidence[sig] < 65535 - 10) sig_confidence[sig] += 10;
    } else {
        // Mild decay to allow adaptation
        if (sig_confidence[sig] > 10) sig_confidence[sig] -= 1;
    }

    // ---- Update per‑line metadata -------------------
    line_meta[set][way].last_access = sim_cycle;
    line_meta[set][way].sig_id      = sig;
    line_meta[set][way].valid       = true;

    // ---- Stride‑stability predictor -----------------
    // Simple heuristic: look at the address of the previous access to the same line.
    // We store the previous address in the line's tag field (available via BLOCK*).
    static uint64_t last_addr[LLC_SETS][LLC_WAYS];
    static bool      have_last[LLC_SETS][LLC_WAYS];

    if (have_last[set][way]) {
        uint64_t prev = last_addr[set][way];
        uint64_t stride = (paddr > prev) ? (paddr - prev) : (prev - paddr);

        // If stride unchanged (within +-4 bytes) consider it stable
        static uint64_t last_stride[LLC_SETS][LLC_WAYS];
        if (have_last[set][way] && stride == last_stride[set][way]) {
            if (line_meta[set][way].stride_stab < 3) line_meta[set][way].stride_stab++;
        } else {
            if (line_meta[set][way].stride_stab > 0) line_meta[set][way].stride_stab--;
        }
        last_stride[set][way] = stride;
    }

    last_addr[set][way] = paddr;
    have_last[set][way] = true;
}

/* -------------------------------------------------------------
   Print end‑of‑simulation statistics
   ------------------------------------------------------------- */
void PrintStats() {
    uint64_t total_conf = 0;
    for (uint32_t i = 0; i < SIG_TABLE_SIZE; ++i) total_conf += sig_confidence[i];

    std::cout << "ASGRP Statistics:\n";
    std::cout << "  Signature table entries: " << SIG_TABLE_SIZE << "\n";
    std::cout << "  Avg confidence (0..65535): "
              << (double)total_conf / SIG_TABLE_SIZE << "\n";
}

/* -------------------------------------------------------------
   Periodic heartbeat – age the signature table so stale patterns fade
   ------------------------------------------------------------- */
void PrintStats_Heartbeat() {
    if (sim_cycle - last_age_cycle > AGE_INTERVAL) {
        AgeSignatureTable();
        last_age_cycle = sim_cycle;
    }
}
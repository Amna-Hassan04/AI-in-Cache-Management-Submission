/* -------------------------------------------------------------------------
 * Adaptive Multivariate Temporal‑Sampling (AMTS) replacement policy
 * -------------------------------------------------------------------------
 *  This file follows the CHAMPSIM CRC2 replacement‑policy interface.
 *  It tracks three per‑line metrics (recency, decaying frequency, phase‑conf)
 *  and selects a victim with the lowest combined desirability.
 * -------------------------------------------------------------------------
 */

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* -------------------------------------------------------------------------
 * Tunable parameters (can be exposed via runtime knobs later)
 * ------------------------------------------------------------------------- */
static const double W_R = 1.0;          // weight for recency
static const double W_F = 1.0;          // weight for frequency
static const double W_P = 1.0;          // weight for phase stability

static const double FREQ_DECAY = 0.9;   // α  – decay factor per epoch (0 < α <= 1)
static const double PHASE_AGE = 0.7;    // β  – phase confidence aging factor
static const uint64_t EPOCH_LENGTH = 1ULL << 20; // cycles per epoch (≈ 1M)

static const uint32_t MAX_FREQ = 255;   // 8‑bit decayed frequency counter
static const uint32_t MAX_PHASE = 255;  // 8‑bit phase confidence counter

/* -------------------------------------------------------------------------
 * Per‑line metadata
 * ------------------------------------------------------------------------- */
struct AMTS_LineInfo {
    uint64_t last_access;      // cycle of last reference (recency)
    uint16_t freq_counter;    // decayed frequency (0‑MAX_FREQ)
    uint16_t phase_conf;      // phase stability (0‑MAX_PHASE)
    uint64_t last_epoch;      // epoch at which the line was last updated
};

static AMTS_LineInfo amts_state[LLC_SETS][LLC_WAYS];

/* -------------------------------------------------------------------------
 * Global epoch tracking
 * ------------------------------------------------------------------------- */
static uint64_t global_cycle_counter = 0;   // updated by CHAMPSIM externally
static uint64_t current_epoch = 0;

/* -------------------------------------------------------------------------
 * Helper: recompute current epoch (called from GetVictimInSet / Update)
 * ------------------------------------------------------------------------- */
inline void update_epoch()
{
    uint64_t new_epoch = global_cycle_counter / EPOCH_LENGTH;
    if (new_epoch != current_epoch) {
        current_epoch = new_epoch;
        // Age all phase confidences lazily – we age per‑line when it is accessed
    }
}

/* -------------------------------------------------------------------------
 * Initialise replacement state (called once at simulation start)
 * ------------------------------------------------------------------------- */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            amts_state[s][w].last_access   = 0;
            amts_state[s][w].freq_counter  = 0;
            amts_state[s][w].phase_conf    = 0;
            amts_state[s][w].last_epoch    = 0;
        }
    }
}

/* -------------------------------------------------------------------------
 * Compute the victim score for a given line
 * ------------------------------------------------------------------------- */
inline double line_score(const AMTS_LineInfo &info, uint64_t now) {
    // Recency component (age in cycles)
    double recency = static_cast<double>(now - info.last_access);

    // Frequency component – we want *high* frequency to be *good*,
    // therefore we subtract from MAX_FREQ.
    double freq = static_cast<double>(MAX_FREQ - info.freq_counter);

    // Phase component – similarly, high confidence = good.
    double phase = static_cast<double>(MAX_PHASE - info.phase_conf);

    return W_R * recency + W_F * freq + W_P * phase;
}

/* -------------------------------------------------------------------------
 * Choose victim line in the set
 * ------------------------------------------------------------------------- */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Update global epoch based on the simulator's cycle counter.
    // CHAMPSIM updates `cpu`'s cycle count in the global variable
    // `cpu_cycle[cpu]`.  We use it as a proxy for `global_cycle_counter`.
    extern uint64_t cpu_cycle[NUM_CORE];
    global_cycle_counter = cpu_cycle[cpu];
    update_epoch();

    // Scan the set for the line with the highest victim score (least desirable)
    double worst_score = -1.0;
    uint32_t victim_way = 0; // default to way 0 if all scores equal

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        // If the line is invalid, we can immediately return it (free slot)
        if (current_set[w].valid == 0) {
            return w;
        }

        double sc = line_score(amts_state[set][w], global_cycle_counter);
        if (sc > worst_score) {
            worst_score = sc;
            victim_way = w;
        }
    }
    return victim_way;
}

/* -------------------------------------------------------------------------
 * Update replacement state after a reference (hit or miss)
 * ------------------------------------------------------------------------- */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Keep epoch up‑to‑date (same as in GetVictimInSet)
    extern uint64_t cpu_cycle[NUM_CORE];
    global_cycle_counter = cpu_cycle[cpu];
    update_epoch();

    AMTS_LineInfo &info = amts_state[set][way];

    // 1) Recency – store current cycle
    info.last_access = global_cycle_counter;

    // 2) Frequency – apply decay if we crossed an epoch boundary for this line
    if (info.last_epoch != current_epoch) {
        // Apply exponential decay for each missed epoch
        uint64_t epochs_missed = current_epoch - info.last_epoch;
        double decay = 1.0;
        for (uint64_t i = 0; i < epochs_missed; ++i)
            decay *= FREQ_DECAY;
        uint32_t new_freq = static_cast<uint32_t>(info.freq_counter * decay);
        info.freq_counter = static_cast<uint16_t>(new_freq);
        info.last_epoch = current_epoch;
    }

    // Increment frequency on a hit (or on insertion, treat as first hit)
    if (hit) {
        if (info.freq_counter < MAX_FREQ)
            ++info.freq_counter;
    } else {
        // Miss – the line is being inserted; start with frequency = 1
        info.freq_counter = 1;
    }

    // 3) Phase confidence – age the old confidence, then reinforce if hit
    // Age is performed lazily each time the line is accessed.
    // Age factor β is applied once per epoch transition (already handled above).
    // Reinforcement:
    if (hit) {
        // Simple reinforcement: move confidence towards MAX_PHASE
        // conf = conf * (1‑β) + β * MAX_PHASE
        double reinforced = static_cast<double>(info.phase_conf) * (1.0 - PHASE_AGE)
                          + PHASE_AGE * MAX_PHASE;
        info.phase_conf = static_cast<uint16_t>(reinforced + 0.5);
    } else {
        // On insertion, start with a neutral confidence (e.g., half of MAX)
        info.phase_conf = MAX_PHASE / 2;
    }
}

/* -------------------------------------------------------------------------
 * Print end‑of‑simulation statistics (optional)
 * ------------------------------------------------------------------------- */
void PrintStats() {
    // Example: average frequency and phase confidence across the LLC
    uint64_t total_freq = 0, total_phase = 0, line_cnt = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            const AMTS_LineInfo &info = amts_state[s][w];
            // Count only valid lines (CHAMPSIM does not expose validity here,
            // but we can approximate by checking freq != 0)
            if (info.freq_counter > 0) {
                total_freq  += info.freq_counter;
                total_phase += info.phase_conf;
                ++line_cnt;
            }
        }
    }
    if (line_cnt) {
        std::cout << "AMTS: Avg. Frequency = " << (double)total_freq / line_cnt
                  << ", Avg. PhaseConf = " << (double)total_phase / line_cnt
                  << std::endl;
    }
}

/* -------------------------------------------------------------------------
 * Periodic heartbeat (optional)
 * ------------------------------------------------------------------------- */
void PrintStats_Heartbeat() {
    // No periodic stats for now – could emit epoch‑level histograms.
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track temporal distance and access count
struct EchoPULSEMetadata {
  uint32_t temporal_distance;
  uint32_t access_count;
};

// Initialize replacement state
void InitReplacementState() {
  // Initialize metadata structures
  static std::vector<EchoPULSEMetadata> metadata(LLC_SETS * LLC_WAYS);
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint32_t victim_way = 0;
  uint32_t min_temporal_distance = UINT32_MAX;

  // Iterate over the ways in the set
  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint32_t index = set * LLC_WAYS + way;
    EchoPULSEMetadata &meta = metadata[index];

    // Calculate a score based on temporal distance and access count
    uint32_t score = meta.temporal_distance + (meta.access_count << 2);

    // Choose the line with the lowest score
    if (score < min_temporal_distance) {
      min_temporal_distance = score;
      victim_way = way;
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  uint32_t index = set * LLC_WAYS + way;
  EchoPULSEMetadata &meta = metadata[index];

  // Update temporal distance and access count
  if (hit) {
    meta.temporal_distance = (meta.temporal_distance + 1) >> 1;
    meta.access_count++;
  } else {
    meta.temporal_distance++;
    meta.access_count = 0;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print statistics on temporal distance and access count distributions
  uint32_t sum_temporal_distance = 0;
  uint32_t sum_access_count = 0;

  for (const auto &meta : metadata) {
    sum_temporal_distance += meta.temporal_distance;
    sum_access_count += meta.access_count;
  }

  std::cout << "Average Temporal Distance: " << (sum_temporal_distance / metadata.size()) << std::endl;
  std::cout << "Average Access Count: " << (sum_access_count / metadata.size()) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print periodic statistics on hit ratio and other relevant metrics
}
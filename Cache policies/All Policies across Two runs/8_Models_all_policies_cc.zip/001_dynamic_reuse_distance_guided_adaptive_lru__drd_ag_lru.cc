#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* --------------------  Tunable parameters -------------------- */
static constexpr double  EMA_ALPHA   = 0.25;   // weight of new observation
static constexpr uint8_t CONF_MAX    = 3;      // 2‑bit confidence (0..3)
static constexpr uint8_t CONF_THRESH = 2;      // min confidence to trust predictor
static constexpr uint64_t DECAY_INTERVAL = 1<<20; // cycles between confidence decay
static constexpr uint64_t EPSILON_RD = 4;      // tolerance for confidence bump
/* ------------------------------------------------------------ */

/* ---------- per‑line replacement metadata ---------- */
struct LineInfo {
    uint64_t last_ts;       // timestamp of last reference (for LRU)
    uint64_t pred_rd;       // EMA of reuse distance (in #distinct accesses)
    uint8_t  conf;          // 2‑bit confidence
    uint64_t last_addr;     // address of last reference (for reuse distance)
    uint64_t last_pc;       // PC of last reference (used only for sampler)
    bool     is_sampler;    // true for the designated sampler line in the set
};

static LineInfo repl[LLC_SETS][LLC_WAYS];
static uint64_t global_ts = 0;          // monotonic timestamp
static uint64_t last_decay_ts = 0;      // when confidence was last decayed
/* --------------------------------------------------- */

/* ---------- Helper: compute reuse distance for a line ----------
   For the sampler line we can afford a simple hash‑set that stores
   the addresses seen since the previous reference to the same line.
   Because the sampler is only one line per set, the extra cost is tiny.
----------------------------------------------------------------- */
#include <unordered_set>
static std::unordered_set<uint64_t> rd_sampler_set; // per‑access temporary set

static uint64_t compute_true_reuse_distance(uint64_t cur_addr, uint64_t prev_addr)
{
    // Very cheap approximation: count distinct addresses seen between two accesses.
    // In a real implementation you would keep a per‑set Bloom filter or
    // a small counting structure. Here we just return 1 if the line was
    // accessed consecutively, else a large value (treated as "infinite").
    return (cur_addr == prev_addr) ? 1 : 0xFFFFFFFFULL;
}

/* --------------------------------------------------- */

void InitReplacementState()
{
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            repl[s][w].last_ts   = 0;
            repl[s][w].pred_rd   = 0;
            repl[s][w].conf      = 0;
            repl[s][w].last_addr = 0;
            repl[s][w].last_pc   = 0;
            repl[s][w].is_sampler = (w == 0); // use way‑0 as the sampler line
        }
    }
    global_ts = 0;
    last_decay_ts = 0;
}

/* --------------------------------------------------- */

uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
)
{
    // 1) decay confidence periodically
    if (global_ts - last_decay_ts >= DECAY_INTERVAL) {
        for (uint32_t s = 0; s < LLC_SETS; ++s) {
            for (uint32_t w = 0; w < LLC_WAYS; ++w) {
                if (repl[s][w].conf > 0) repl[s][w].conf--;
            }
        }
        last_decay_ts = global_ts;
    }

    // 2) Scan set for the best candidate
    uint32_t victim = 0;
    uint64_t max_pred_rd = 0;
    bool found_confident = false;
    uint64_t lru_ts = 0;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        // LRU baseline (largest timestamp = least recently used)
        if (repl[set][w].last_ts > lru_ts) {
            lru_ts   = repl[set][w].last_ts;
            victim   = w;               // default victim (LRU)
        }

        // Look for a confident line with large predicted reuse distance
        if (repl[set][w].conf >= CONF_THRESH) {
            if (!found_confident || repl[set][w].pred_rd > max_pred_rd) {
                max_pred_rd = repl[set][w].pred_rd;
                victim      = w;
                found_confident = true;
            }
        }
    }
    return victim;
}

/* --------------------------------------------------- */

void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
)
{
    global_ts++;

    LineInfo &line = repl[set][way];
    line.last_ts = global_ts;                 // update LRU timestamp

    // ---------- Sampler handling ----------
    // Way‑0 in every set is the sampler. It records true reuse distance.
    if (line.is_sampler) {
        uint64_t true_rd = compute_true_reuse_distance(paddr, line.last_addr);
        // Update EMA and confidence for the *sampled* line (the sampler itself)
        // The predictor for the sampler is kept exactly like normal lines.
        if (line.pred_rd == 0)          // first observation
            line.pred_rd = true_rd;
        else
            line.pred_rd = static_cast<uint64_t>(EMA_ALPHA * true_rd +
                                                (1.0 - EMA_ALPHA) * line.pred_rd);

        // Confidence bump/penalty
        uint64_t diff = (line.pred_rd > true_rd) ? (line.pred_rd - true_rd)
                                                : (true_rd - line.pred_rd);
        if (diff <= EPSILON_RD) {
            if (line.conf < CONF_MAX) line.conf++;
        } else {
            if (line.conf > 0) line.conf--;
        }
    }

    // ---------- Normal line handling ----------
    if (!hit) {
        // First time we see this line after a miss: no reuse distance yet.
        line.last_addr = paddr;
        line.last_pc   = PC;
        // pred_rd stays whatever it was (may be stale); confidence is reset.
        line.conf = 0;
        return;
    }

    // For a hit we can compute an *observed* reuse distance using the
    // per‑line last address. A cheap approximation: if the address changed,
    // treat the distance as "infinite" (i.e., a large number). More accurate
    // hardware would keep a small per‑set tag stack; we keep it simple.
    uint64_t observed_rd = (paddr == line.last_addr) ? 1 : 0xFFFFFFFFULL;

    // Update EMA predictor
    if (line.pred_rd == 0) line.pred_rd = observed_rd;
    else line.pred_rd = static_cast<uint64_t>(EMA_ALPHA * observed_rd +
                                              (1.0 - EMA_ALPHA) * line.pred_rd);

    // Update confidence
    uint64_t diff = (line.pred_rd > observed_rd) ? (line.pred_rd - observed_rd)
                                                : (observed_rd - line.pred_rd);
    if (diff <= EPSILON_RD) {
        if (line.conf < CONF_MAX) line.conf++;
    } else {
        if (line.conf > 0) line.conf--;
    }

    // Finally store current address/PC for the next reuse‑distance measurement
    line.last_addr = paddr;
    line.last_pc   = PC;
}

/* --------------------------------------------------- */

void PrintStats()
{
    uint64_t total_conf = 0, total_lines = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            total_conf += repl[s][w].conf;
            total_lines++;
        }
    }
    std::cout << "DRD-AG-LRU statistics:\n";
    std::cout << "  Average confidence per line: "
              << static_cast<double>(total_conf) / total_lines << "\n";
}

/* --------------------------------------------------- */

void PrintStats_Heartbeat()
{
    // optional periodic print – left empty for now
}
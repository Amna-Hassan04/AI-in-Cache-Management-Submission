#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* -------------------  Tunable Parameters  ------------------- */
const uint8_t MAX_AGE   = 255;   // saturating age counter
const uint8_t MAX_SIG   = 255;   // max Bloom‑predictor value per line
const uint32_t PHASE_WINDOW = 128; // number of recent PCs to consider for entropy

/* -------------------  Metadata Structures  ------------------- */
// per‑set Bloom filter (simple 8‑bit bitmap, 4 hash functions)
static uint8_t set_bloom[LLC_SETS];

/* per‑line metadata */
static uint8_t line_age[LLC_SETS][LLC_WAYS];
static uint8_t line_pred[LLC_SETS][LLC_WAYS];   // Bloom‑predictor signature

/* per‑set phase tracking */
static uint64_t recent_pcs[LLC_SETS][PHASE_WINDOW];
static uint32_t pc_head[LLC_SETS];             // circular buffer index
static uint8_t phase_confidence[LLC_SETS];    // 0..255, higher → spatial phase

/* -------------------  Helper Functions  ------------------- */
static inline uint8_t hash1(uint64_t x) { return (x ^ (x >> 33)) & 0xFF; }
static inline uint8_t hash2(uint64_t x) { return ((x >> 8) ^ (x >> 24)) & 0xFF; }
static inline uint8_t hash3(uint64_t x) { return ((x >> 16) ^ (x >> 40)) & 0xFF; }
static inline uint8_t hash4(uint64_t x) { return ((x >> 24) ^ (x >> 48)) & 0xFF; }

/* Update Bloom filter for a given set with a PC */
static void bloom_insert(uint32_t set, uint64_t pc) {
    set_bloom[set] |= (1 << (hash1(pc) % 8));
    set_bloom[set] |= (1 << (hash2(pc) % 8));
    set_bloom[set] |= (1 << (hash3(pc) % 8));
    set_bloom[set] |= (1 << (hash4(pc) % 8));
}

/* Query Bloom filter for a given set with a PC */
static bool bloom_query(uint32_t set, uint64_t pc) {
    uint8_t mask = (1 << (hash1(pc) % 8)) |
                   (1 << (hash2(pc) % 8)) |
                   (1 << (hash3(pc) % 8)) |
                   (1 << (hash4(pc) % 8));
    return (set_bloom[set] & mask) == mask;
}

/* Compute simple entropy proxy (number of distinct PCs in window) */
static uint8_t compute_phase_confidence(uint32_t set) {
    uint64_t uniq = 0;
    // naive distinct count – good enough for a lightweight policy
    for (uint32_t i = 0; i < PHASE_WINDOW; ++i) {
        uniq |= recent_pcs[set][i];
    }
    // more distinct bits → higher entropy → lower confidence
    uint8_t bits = __builtin_popcountll(uniq);
    // map bits [0..64] → confidence [255..0]
    return (uint8_t)(255 - (bits * 4)); // coarse linear scaling
}

/* -------------------  Required Hooks  ------------------- */
void InitReplacementState() {
    // clear all metadata
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        set_bloom[s] = 0;
        pc_head[s] = 0;
        phase_confidence[s] = 128; // start neutral

        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            line_age[s][w]  = 0;
            line_pred[s][w] = 0;
        }
        // initialise recent PC window to zeros
        for (uint32_t i = 0; i < PHASE_WINDOW; ++i)
            recent_pcs[s][i] = 0;
    }
}

/* Choose victim line in the set */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Update phase confidence periodically (simple heuristic)
    if ((type & 0x3) == 0) { // every few accesses (type encodes access class)
        phase_confidence[set] = compute_phase_confidence(set);
    }

    // Weights derived from phase confidence
    //   high confidence → spatial → favor age (w_age high)
    //   low confidence → irregular → favor predictor (w_pred high)
    uint8_t w_age = phase_confidence[set];            // [0..255]
    uint8_t w_pred = 255 - phase_confidence[set];    // complementary

    uint32_t victim = 0;
    uint32_t worst_score = 0;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        // If the line is invalid, take it immediately
        if (current_set[way].valid == 0) {
            return way;
        }

        uint32_t age   = line_age[set][way];
        uint32_t pred  = line_pred[set][way];
        // Higher score = less desirable to keep
        uint32_t score = w_age * age + w_pred * (MAX_SIG - pred);

        if (way == 0 || score > worst_score) {
            worst_score = score;
            victim = way;
        }
    }
    return victim;
}

/* Update replacement state */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // ------------------------------------------------------------------
    // 1) Update per‑set Bloom filter and phase history
    // ------------------------------------------------------------------
    bloom_insert(set, PC);
    recent_pcs[set][pc_head[set]] = PC;
    pc_head[set] = (pc_head[set] + 1) % PHASE_WINDOW;

    // ------------------------------------------------------------------
    // 2) Age handling (decay for all non‑hit lines)
    // ------------------------------------------------------------------
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (w == way && hit) {
            line_age[set][w] = 0;               // reset on hit
        } else {
            // saturating increment (decay)
            if (line_age[set][w] < MAX_AGE)
                line_age[set][w]++;
        }
    }

    // ------------------------------------------------------------------
    // 3) Update Bloom‑predictor signature
    // ------------------------------------------------------------------
    if (hit) {
        // Successful hit → reinforce predictor
        if (line_pred[set][way] < MAX_SIG)
            line_pred[set][way] += 4;   // step size tuned experimentally
    } else {
        // Miss: look at Bloom filter to guess future reuse
        bool likely = bloom_query(set, PC);
        if (likely) {
            // give the newly inserted line a modest head start
            line_pred[set][way] = (line_pred[set][way] > 4) ? line_pred[set][way] - 4 : 0;
        } else {
            // penalise – make it look older
            line_pred[set][way] = (line_pred[set][way] > 8) ? line_pred[set][way] - 8 : 0;
        }
    }

    // ------------------------------------------------------------------
    // 4) If this was a replacement (miss and we inserted a new line),
    //    initialise its metadata.
    // ------------------------------------------------------------------
    if (!hit) {
        line_age[set][way] = 0;
        // start with a neutral predictor value
        line_pred[set][way] = MAX_SIG / 2;
    }
}

/* Print end‑of‑simulation statistics */
void PrintStats() {
    // Example: average age and predictor distribution (optional)
    uint64_t total_age = 0, total_pred = 0, cnt = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            total_age += line_age[s][w];
            total_pred += line_pred[s][w];
            ++cnt;
        }
    }
    std::cout << "TCAB-P average line age: " << (double)total_age / cnt << "\n";
    std::cout << "TCAB-P average line predictor value: " << (double)total_pred / cnt << "\n";
}

/* Print periodic statistics – left empty for now */
void PrintStats_Heartbeat() {}
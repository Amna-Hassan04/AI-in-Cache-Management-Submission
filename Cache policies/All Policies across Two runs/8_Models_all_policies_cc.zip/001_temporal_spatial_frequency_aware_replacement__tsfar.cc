#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to store metadata for each cache line
struct TSFARMetadata {
  uint32_t frequency_count;
  uint32_t last_access_cycle;
};

// Vector to store metadata for all cache lines
std::vector<TSFARMetadata> tsfar_metadata(LLC_SETS * LLC_WAYS);

// Initialize replacement state
void InitReplacementState() {
  for (auto& metadata : tsfar_metadata) {
    metadata.frequency_count = 0;
    metadata.last_access_cycle = 0;
  }
}

// Calculate temporal-spatial frequency score
uint32_t calculate_tsfar_score(uint32_t way, uint32_t set, uint64_t current_cycle) {
  uint32_t index = set * LLC_WAYS + way;
  uint32_t temporal_distance = current_cycle - tsfar_metadata[index].last_access_cycle;
  return tsfar_metadata[index].frequency_count / (temporal_distance + 1);
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint64_t current_cycle = champsim_crc2::get_current_cycle();
  uint32_t min_score_way = 0;
  uint32_t min_score = UINT32_MAX;

  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint32_t index = set * LLC_WAYS + way;
    uint32_t score = calculate_tsfar_score(way, set, current_cycle);
    if (score < min_score) {
      min_score = score;
      min_score_way = way;
    }
  }

  return min_score_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  uint64_t current_cycle = champsim_crc2::get_current_cycle();
  uint32_t index = set * LLC_WAYS + way;

  if (hit) {
    tsfar_metadata[index].frequency_count++;
    tsfar_metadata[index].last_access_cycle = current_cycle;
  } else {
    // Decay frequency count over time
    tsfar_metadata[index].frequency_count >>= 1;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print average frequency count and temporal distance
  uint32_t total_frequency_count = 0;
  uint32_t total_temporal_distance = 0;
  for (const auto& metadata : tsfar_metadata) {
    total_frequency_count += metadata.frequency_count;
    total_temporal_distance += champsim_crc2::get_current_cycle() - metadata.last_access_cycle;
  }
  std::cout << "Average frequency count: " << (total_frequency_count / (LLC_SETS * LLC_WAYS)) << std::endl;
  std::cout << "Average temporal distance: " << (total_temporal_distance / (LLC_SETS * LLC_WAYS)) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print current average frequency count and temporal distance
  uint32_t total_frequency_count = 0;
  uint32_t total_temporal_distance = 0;
  for (const auto& metadata : tsfar_metadata) {
    total_frequency_count += metadata.frequency_count;
    total_temporal_distance += champsim_crc2::get_current_cycle() - metadata.last_access_cycle;
  }
  std::cout << "Current average frequency count: " << (total_frequency_count / (LLC_SETS * LLC_WAYS)) << std::endl;
  std::cout << "Current average temporal distance: " << (total_temporal_distance / (LLC_SETS * LLC_WAYS)) << std::endl;
}
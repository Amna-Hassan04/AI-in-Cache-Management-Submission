#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define ENTROPY_WINDOW_SIZE 10

// Initialize replacement state
void InitReplacementState() {
    // Initialize entropy values for each cache line
    entropy_values = new double*[LLC_SETS];
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        entropy_values[set] = new double[LLC_WAYS];
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            entropy_values[set][way] = 0.0;
        }
    }

    // Initialize access histories for each cache line
    access_histories = new uint64_t*[LLC_SETS];
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        access_histories[set] = new uint64_t[LLC_WAYS];
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            access_histories[set][way] = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    double max_entropy = 0.0;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        // Calculate entropy value for the current line
        double entropy = CalculateEntropy(set, way);

        // Update the victim line if the current line has higher entropy
        if (entropy > max_entropy) {
            max_entropy = entropy;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update access history for the current line
    access_histories[set][way] = (access_histories[set][way] << 1) | hit;

    // Update entropy values for all lines in the set
    for (uint32_t i = 0; i < LLC_WAYS; i++) {
        entropy_values[set][i] = CalculateEntropy(set, i);
    }
}

// Calculate entropy value for a given cache line
double CalculateEntropy(uint32_t set, uint32_t way) {
    uint64_t access_history = access_histories[set][way];
    double entropy = 0.0;

    for (uint32_t i = 0; i < ENTROPY_WINDOW_SIZE; i++) {
        uint8_t bit = (access_history >> i) & 1;
        double probability = (double)bit / ENTROPY_WINDOW_SIZE;
        entropy -= probability * log2(probability);
    }

    return entropy;
}

// Print end-of-simulation statistics
void PrintStats() {
    // Print final entropy values for all cache lines
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            std::cout << "Set " << set << ", Way " << way << ": Entropy = " << entropy_values[set][way] << std::endl;
        }
    }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Print current entropy values for all cache lines
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            std::cout << "Set " << set << ", Way " << way << ": Entropy = " << entropy_values[set][way] << std::endl;
        }
    }
}

// Data structures to store entropy values and access histories
double** entropy_values;
uint64_t** access_histories;
#include <vector>
#include <cstdint>
#include <iostream>
#include <map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structure to track frequency and size for each cache line
typedef struct {
    uint32_t frequency;
    uint32_t size;
} asfr_metadata;

// Global metadata for all cache lines
std::map<uint64_t, asfr_metadata> asfr_meta;

// Initialize replacement state
void InitReplacementState() {
    // Initialize all metadata structures
    asfr_meta.clear();
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;
    double min_score = std::numeric_limits<double>::max();

    // Iterate over all ways in the set
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t addr = current_set[way].paddr;
        auto meta = asfr_meta[addr];
        
        // Calculate utility score (frequency / size)
        double score = static_cast<double>(meta.frequency) / meta.size;
        
        // Select the line with the lowest score as victim
        if (score < min_score) {
            min_score = score;
            victim = way;
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Update metadata for the accessed line
        asfr_meta[paddr].frequency++;
    } else {
        // Insert new line with initial frequency and size
        asfr_metadata new_meta = {1, type};
        asfr_meta[paddr] = new_meta;
    }
    
    // Remove metadata for victim address if evicted
    if (victim_addr != 0) {
        asfr_meta.erase(victim_addr);
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics: Total hits and frequency distribution
    std::cout << "ASFR Policy Statistics:" << std::endl;
    std::cout << "Total cache lines tracked: " << asfr_meta.size() << std::endl;
    std::cout << "Average frequency per line: " << 
        std::accumulate(asfr_meta.begin(), asfr_meta.end(), 0,
            [](int sum, const auto& pair) { return sum + pair.second.frequency; }) /
        asfr_meta.size() << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example heartbeat statistics: Simple frequency count
    std::cout << "ASFR Heartbeat: Cache lines in metadata - " << asfr_meta.size() << std::endl;
}
#include <vector>
#include <cstdint>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct VAH_meta {
    uint8_t fast_cnt;   // 3-bit hit counter
    uint8_t slow_cnt;   // 8-bit aging counter
};
static VAH_meta vahtable[LLC_SETS][LLC_WAYS];

void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            vahtable[s][w].fast_cnt = 0;
            vahtable[s][w].slow_cnt = 0;
        }
}

uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type) {
    uint32_t victim_way = 0;
    uint8_t min_fast = 0xFF;
    uint8_t min_slow = 0xFF;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        uint8_t f = vahtable[set][w].fast_cnt;
        uint8_t s = vahtable[set][w].slow_cnt;
        if (f < min_fast || (f == min_fast && s < min_slow)) {
            min_fast = f;
            min_slow = s;
            victim_way = w;
        }
    }
    return victim_way;
}

void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                            uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                            uint32_t type, uint8_t hit) {
    if (hit) {
        // Protect the line: bump fast counter
        if (vahtable[set][way].fast_cnt < 7)
            vahtable[set][way].fast_cnt++;
    } else {
        // Line survived a scan without being hit: age it
        if (vahtable[set][way].slow_cnt < 255)
            vahtable[set][way].slow_cnt++;
    }
}

void PrintStats() { /* optional */ }
void PrintStats_Heartbeat() { /* optional */ }
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Global metadata
static uint8_t  pred_tbl[256];          // fast-reuse confidence
static uint8_t  reuse_ctr = 0;        // global falling-edge counter
static uint8_t  fallvec[LLC_SETS][LLC_WAYS]; // falling-edge snapshot at last access
static uint8_t  conf[LLC_SETS][LLC_WAYS];    // fast-reuse confidence for each line

void InitReplacementState() {
    for(int i=0;i<256;i++) pred_tbl[i]=0;
    reuse_ctr=0;
    for(int s=0;s<LLC_SETS;s++)
        for(int w=0;w<LLC_WAYS;w++){
            fallvec[s][w]=0;
            conf[s][w]=0;
        }
}

static inline uint8_t hash_pc(uint64_t pc){
    return (pc & 0xFF) ^ (reuse_ctr & 0xF);
}

uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type){
    uint32_t victim_way = 0;
    uint8_t  min_conf = 255;
    for(uint32_t w=0;w<LLC_WAYS;w++){
        uint8_t c = conf[set][w];
        // probabilistic second chance
        if(c==0 && (rand()&0x1F)) c=1;
        if(c < min_conf){
            min_conf = c;
            victim_way = w;
        }
    }
    return victim_way;
}

void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                           uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                           uint32_t type, uint8_t hit){
    uint8_t fe = fallvec[set][way];
    uint8_t idx = hash_pc(PC);
    if(hit){
        // re-reference observed before next falling edge → “fast reuse”
        if(fe == reuse_ctr){
            pred_tbl[idx] = std::min(255U, pred_tbl[idx]+2);
            conf[set][way]  = std::min(255U, conf[set][way]+2);
        }
    }else{
        // new line inserted
        conf[set][way] = pred_tbl[idx];
    }
    fallvec[set][way] = reuse_ctr;
    // global falling-edge tick every 16 accesses
    static uint64_t access_cnt=0;
    if((++access_cnt & 0xF)==0) reuse_ctr++;
}

void PrintStats(){
    std::cout<<"FCR-PD: no final stats printed\n";
}
void PrintStats_Heartbeat(){}
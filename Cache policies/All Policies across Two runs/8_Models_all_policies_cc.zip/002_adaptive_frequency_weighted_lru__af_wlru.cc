#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ------------------------------------------------------------------
 *  Metadata per cache line
 * ------------------------------------------------------------------ */
static uint8_t  freq_counter[LLC_SETS][LLC_WAYS];   // 0‑255, per‑line frequency weight
static uint32_t lru_stack   [LLC_SETS][LLC_WAYS];   // 0 = MRU, (WAYS‑1) = LRU

/* ------------------------------------------------------------------
 *  Policy parameters (tuneable)
 * ------------------------------------------------------------------ */
static const uint32_t FREQ_SHIFT = 1;   // decay = right‑shift by 1 (divide by 2)
static const int      ALPHA      = 2;   // weight of frequency in victim score

/* ------------------------------------------------------------------
 *  Initialise replacement state
 * ------------------------------------------------------------------ */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            freq_counter[s][w] = 0;
            lru_stack   [s][w] = w;          // initial LRU order (any permutation ok)
        }
    }
}

/* ------------------------------------------------------------------
 *  Helper: update LRU stack after an access to <way> in <set>
 * ------------------------------------------------------------------ */
static void MoveToMRU(uint32_t set, uint32_t way) {
    uint32_t old_pos = lru_stack[set][way];
    // shift every line that was more recent (smaller position) down by one
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (lru_stack[set][w] < old_pos) {
            lru_stack[set][w] += 1;
        }
    }
    lru_stack[set][way] = 0;   // now MRU
}

/* ------------------------------------------------------------------
 *  Choose victim line in the set
 * ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // 1) Apply decay to all frequency counters in the set (leaky bucket)
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        freq_counter[set][w] >>= FREQ_SHIFT;   // fast decay
    }

    // 2) Compute score = LRU_position - ALPHA * freq_counter
    int32_t worst_score = -1;
    uint32_t victim_way = 0;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        int32_t score = static_cast<int32_t>(lru_stack[set][w])
                        - ALPHA * static_cast<int32_t>(freq_counter[set][w]);

        if (score > worst_score) {   // larger score => more eligible for eviction
            worst_score = score;
            victim_way  = w;
        }
    }

    return victim_way;
}

/* ------------------------------------------------------------------
 *  Update replacement state after a reference
 * ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // 1) On hit: increase frequency counter (saturating)
    if (hit) {
        if (freq_counter[set][way] < 255)
            freq_counter[set][way] += 1;
    } else {
        // 2) On miss (new line inserted): start its counter at 1
        freq_counter[set][way] = 1;
    }

    // 3) Update LRU order – the accessed line becomes MRU
    MoveToMRU(set, way);
}

/* ------------------------------------------------------------------
 *  Optional statistics (can be expanded later)
 * ------------------------------------------------------------------ */
void PrintStats() {
    // Example: average frequency counter value over the whole LLC
    uint64_t sum = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            sum += freq_counter[s][w];

    double avg = static_cast<double>(sum) / (LLC_SETS * LLC_WAYS);
    std::cout << "AF-wLRU: average freq_counter = " << avg << std::endl;
}

void PrintStats_Heartbeat() {
    // No periodic stats for now
}
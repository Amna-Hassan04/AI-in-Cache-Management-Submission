#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ---------- Policy‑specific metadata ---------- */
struct LineInfo {
    uint64_t last_ts;        // Last access timestamp (for LRU within a queue)
    uint64_t pc;             // PC of the last access that hit this line
    uint16_t reuse_pred;     // Simple reuse‑prediction counter (0‑255)
    bool     in_hot;         // true = line resides in Hot‑Queue, false = Cold‑Queue
};

struct SetInfo {
    // PC histogram for phase detection (8‑entry circular buffer)
    static const int HIST_SIZE = 8;
    uint64_t pc_hist[HIST_SIZE];
    uint8_t  pc_hist_cnt[HIST_SIZE];
    uint8_t  hist_head;               // points to next insert position
    uint8_t  phase_stable;            // stability counter (0‑255)
    uint8_t  dominant_pc_idx;         // index of the dominant PC in the histogram
};

static LineInfo line_info[LLC_SETS][LLC_WAYS];
static SetInfo  set_info[LLC_SETS];

/* ---------- Helper functions ---------- */
// Return the index of the dominant PC in the histogram; also updates dominant_pc_idx
static uint8_t get_dominant_pc_idx(const SetInfo &si) {
    uint8_t best = 0;
    for (int i = 1; i < SetInfo::HIST_SIZE; ++i) {
        if (si.pc_hist_cnt[i] > si.pc_hist_cnt[best])
            best = i;
    }
    return best;
}

// Update the per‑set PC histogram with a new PC (only on hits)
static void update_pc_histogram(uint32_t set, uint64_t pc) {
    SetInfo &si = set_info[set];
    // Simple linear search to find existing entry
    int slot = -1;
    for (int i = 0; i < SetInfo::HIST_SIZE; ++i) {
        if (si.pc_hist_cnt[i] && si.pc_hist[i] == pc) {
            slot = i;
            break;
        }
    }
    // If not present, use the circular buffer slot
    if (slot == -1) {
        slot = si.hist_head;
        si.pc_hist[slot] = pc;
        si.pc_hist_cnt[slot] = 0;
        si.hist_head = (si.hist_head + 1) % SetInfo::HIST_SIZE;
    }
    // Increment the counter (saturate at 255)
    if (si.pc_hist_cnt[slot] < 255) si.pc_hist_cnt[slot]++;

    // Re‑evaluate dominant PC
    uint8_t old_dom = si.dominant_pc_idx;
    si.dominant_pc_idx = get_dominant_pc_idx(si);
    // Update stability counter
    if (si.dominant_pc_idx == old_dom) {
        if (si.phase_stable < 250) si.phase_stable++;
    } else {
        if (si.phase_stable > 5) si.phase_stable--;
    }
}

/* ---------- Required CHAMPSIM hooks ---------- */
// Initialize replacement state
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            line_info[s][w].last_ts    = 0;
            line_info[s][w].pc         = 0;
            line_info[s][w].reuse_pred = 0;
            line_info[s][w].in_hot     = false; // start in Cold‑Queue
        }
        // Initialise histogram to zero
        SetInfo &si = set_info[s];
        for (int i = 0; i < SetInfo::HIST_SIZE; ++i) {
            si.pc_hist[i]      = 0;
            si.pc_hist_cnt[i]  = 0;
        }
        si.hist_head       = 0;
        si.phase_stable    = 0;
        si.dominant_pc_idx = 0;
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Prefer eviction from Cold‑Queue (in_hot == false)
    uint32_t victim = UINT32_MAX;
    uint64_t  best_pred = UINT64_MAX;
    uint64_t  oldest_ts = 0;

    // First pass: look for cold lines with smallest reuse_pred
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (!line_info[set][w].in_hot) {
            uint16_t pred = line_info[set][w].reuse_pred;
            if (pred < best_pred) {
                best_pred = pred;
                victim   = w;
                oldest_ts = line_info[set][w].last_ts;
            } else if (pred == best_pred && line_info[set][w].last_ts < oldest_ts) {
                victim   = w;
                oldest_ts = line_info[set][w].last_ts;
            }
        }
    }

    // If no cold line exists (all hot), fall back to hot LRU
    if (victim == UINT32_MAX) {
        best_pred = UINT64_MAX;
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            uint16_t pred = line_info[set][w].reuse_pred;
            if (pred < best_pred) {
                best_pred = pred;
                victim   = w;
                oldest_ts = line_info[set][w].last_ts;
            } else if (pred == best_pred && line_info[set][w].last_ts < oldest_ts) {
                victim   = w;
                oldest_ts = line_info[set][w].last_ts;
            }
        }
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t cur_ts = __builtin_ia32_rdtsc(); // simple timestamp

    if (hit) {
        // ----------- HIT PATH -----------
        // Update per‑line metadata
        line_info[set][way].last_ts    = cur_ts;
        line_info[set][way].pc         = PC;
        if (line_info[set][way].reuse_pred < 255) line_info[set][way].reuse_pred += 4; // boost reuse confidence

        // Phase detection: update histogram with the PC that caused the hit
        update_pc_histogram(set, PC);

        // Determine if the line belongs to the current hot phase
        SetInfo &si = set_info[set];
        bool pc_is_dominant = (PC == si.pc_hist[si.dominant_pc_idx]);

        // If the set is phase‑stable, promote to Hot‑Queue; otherwise keep cold
        if (si.phase_stable > 200 && pc_is_dominant) {
            line_info[set][way].in_hot = true;
        } else {
            line_info[set][way].in_hot = false;
        }
    } else {
        // ----------- MISS / INSERTION PATH -----------
        // The victim line (way) is being overwritten
        // Initialize its metadata as a fresh cold entry
        line_info[set][way].last_ts    = cur_ts;
        line_info[set][way].pc         = PC;
        line_info[set][way].reuse_pred = 1; // start with minimal confidence
        line_info[set][way].in_hot     = false; // new blocks start cold

        // Inserted block may immediately belong to hot phase if the set is stable
        SetInfo &si = set_info[set];
        if (si.phase_stable > 200 && PC == si.pc_hist[si.dominant_pc_idx]) {
            line_info[set][way].in_hot = true;
        }

        // No histogram update on miss (only on hits) – this keeps the phase model
        // driven by actual reuse signals.
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // (Optional) aggregate per‑set stability statistics, hot‑vs‑cold ratios, etc.
    uint64_t total_stable = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        total_stable += set_info[s].phase_stable;

    std::cout << "PHAR: average set stability = "
              << (double)total_stable / LLC_SETS << std::endl;
}

// Print periodic statistics (heartbeat)
void PrintStats_Heartbeat() {
    // Could emit hot/cold occupancy histograms every N million cycles
}
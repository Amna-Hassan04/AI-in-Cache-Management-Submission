#include <vector>
#include <cstdint>
#include <iostream>
#include <queue>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to store line information
struct LineInfo {
    uint64_t accessTime;  
    double weight;
};

// Initialize replacement state
void InitReplacementState() {
    // Create a vector to store LineInfo for each set and way
    std::vector<std::vector<LineInfo>> lineInfo(LLC_SETS, 
                                                   std::vector<LineInfo>(LLC_WAYS));
    
    // Initialize initial access times and weights
    for (int set = 0; set < LLC_SETS; ++set) {
        for (int way = 0; way < LLC_WAYS; ++way) {
            lineInfo[set][way].accessTime = 0;
            lineInfo[set][way].weight = 1.0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Find the line with the lowest weight
    uint32_t victim = 0;
    double minWeight = lineInfo[set][0].weight;

    for (int way = 1; way < LLC_WAYS; ++way) {
        if (lineInfo[set][way].weight < minWeight) {
            minWeight = lineInfo[set][way].weight;
            victim = way;
        }
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update access time and weight based on access frequency
    lineInfo[set][way].accessTime = PC;  
    // Apply the frequency weighting logic here...
}

// Print end-of-simulation statistics
void PrintStats() {
    // --- OPTIONAL: print final stats ---
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // --- OPTIONAL: print progress stats ---
}
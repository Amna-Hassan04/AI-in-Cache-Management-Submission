#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// struct to store branch prediction bias for each line
struct LineInfo {
    int64_t prediction_bias; // Bias value (positive for taken bias, negative for not taken bias)
};

//  Initialize replacement state
void InitReplacementState() {
    // Create a vector to store LineInfo for each cache line
    for (int i = 0; i < LLC_SETS * LLC_WAYS; i++) {
        // Initialize bias to 0
        LineInfo line_info;
        line_info.prediction_bias = 0;
        // --- Store line_info somewhere appropriate (e.g. in cache line structure) ---
    } 
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Find the line with the lowest prediction bias in the set 
    // ---  Implement logic to find the line with the lowest bias ---
    return 0; // Return index of victim line
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    //  Fetch the branch instruction associated with the accessed line
    //  --- Implement logic to find the branch instruction based on PC or paddr ---
    // Update the prediction bias of the accessed line based on the prediction accuracy
    // --- Implement logic to update the bias value based on the prediction hit or miss ---
}


//  Print end-of-simulation statistics
void PrintStats() {
    // --- OPTIONAL: print final stats ---
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // --- OPTIONAL: print progress stats ---
}
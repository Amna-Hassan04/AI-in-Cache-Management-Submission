#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track cache line metadata
struct CacheLineMetadata {
    uint32_t frequency;
    uint32_t recency;
};

// Array to store metadata for each cache line
CacheLineMetadata metadata[LLC_SETS][LLC_WAYS];

// Threshold to determine when to switch between frequency and recency modes
uint32_t frequencyThreshold = 10;
uint32_t recencyThreshold = 5;

// Mode indicator (0: frequency-based, 1: recency-based)
uint32_t mode = 0;

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t i = 0; i < LLC_SETS; i++) {
        for (uint32_t j = 0; j < LLC_WAYS; j++) {
            metadata[i][j].frequency = 0;
            metadata[i][j].recency = j; // Initialize recency based on initial position
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;

    if (mode == 0) { // Frequency-based mode
        uint32_t minFrequency = metadata[set][0].frequency;
        for (uint32_t i = 1; i < LLC_WAYS; i++) {
            if (metadata[set][i].frequency < minFrequency) {
                minFrequency = metadata[set][i].frequency;
                victim = i;
            }
        }
    } else { // Recency-based mode
        uint32_t maxRecency = metadata[set][0].recency;
        for (uint32_t i = 1; i < LLC_WAYS; i++) {
            if (metadata[set][i].recency > maxRecency) {
                maxRecency = metadata[set][i].recency;
                victim = i;
            }
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        metadata[set][way].frequency++;
        metadata[set][way].recency = 0; // Reset recency on hit

        // Check if we need to switch modes
        if (mode == 0 && metadata[set][way].frequency > frequencyThreshold) {
            mode = 1; // Switch to recency-based mode
        } else if (mode == 1 && metadata[set][way].recency > recencyThreshold) {
            mode = 0; // Switch to frequency-based mode
        }
    } else {
        // Update recency for all lines in the set
        for (uint32_t i = 0; i < LLC_WAYS; i++) {
            metadata[set][i].recency++;
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "DynaCache statistics:" << std::endl;
    std::cout << "Mode switches: " << (mode == 0 ? "Frequency-based" : "Recency-based") << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: print progress stats
}
/*********************************************************************
 * Confidence‑Weighted Reuse Prediction (CWRP) replacement policy
 *
 *  - Per‑line Reuse Confidence (RC) : 8‑bit saturating counter
 *  - Per‑PC Confidence Table (PCT)   : 2‑bit saturating counter
 *  - Victim = line with smallest (RC - PCT*32)
 *
 *  This file follows the CHAMPsim replacement‑policy skeleton.
 *********************************************************************/

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)   // total number of sets
#define LLC_WAYS 16                  // associativity

/* ------------------------------------------------------------------
 *  Global metadata
 * ------------------------------------------------------------------ */
static uint8_t  rc[LLC_SETS][LLC_WAYS];          // Reuse Confidence per line
static uint64_t last_access_ts[LLC_SETS][LLC_WAYS]; // optional timestamp (debug)
static uint8_t  pct[1 << 12];                   // 2‑bit per‑PC confidence table

static uint64_t global_timestamp = 0;           // monotonic counter of accesses

/* ------------------------------------------------------------------
 *  Helper utilities
 * ------------------------------------------------------------------ */
inline uint8_t pct_bonus(uint64_t pc) {
    // low 12 bits index, each entry 0..3 → bonus = entry * 32 (fits in 8‑bit)
    return pct[(pc >> 0) & 0xFFF] * 32;
}

/* ------------------------------------------------------------------
 *  Replacement‑policy entry points
 * ------------------------------------------------------------------ */
void InitReplacementState() {
    // Initialise per‑line RC to zero (cold) and PC table to neutral (1)
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            rc[s][w] = 0;
            last_access_ts[s][w] = 0;
        }
    }
    for (uint32_t i = 0; i < (1<<12); ++i) pct[i] = 1;   // start with mild confidence
}

/* ------------------------------------------------------------------
 *  Choose victim in a given set
 * ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Apply RC decay to the whole set (right shift by 1 = divide by 2)
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        rc[set][w] >>= 1;               // exponential aging
    }

    // Find line with minimal (RC - pct_bonus(PC_of_line))
    // Since we do not store the originating PC per line, we approximate
    // the bonus with the current PC’s confidence (still gives a bias).
    uint8_t cur_pc_bonus = pct_bonus(PC);
    uint32_t victim_way = 0;
    int32_t   min_score = 0x7fffffff;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        int32_t score = static_cast<int32_t>(rc[set][w]) - static_cast<int32_t>(cur_pc_bonus);
        if (score < min_score) {
            min_score = score;
            victim_way = w;
        }
    }
    return victim_way;
}

/* ------------------------------------------------------------------
 *  Update replacement state after an access (hit or miss)
 * ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    ++global_timestamp;   // advance global time on every access

    // ----- 1. Update per‑PC confidence table -----
    uint32_t pct_idx = (PC >> 0) & 0xFFF;
    if (hit) {
        // successful reuse → strengthen confidence (saturating at 3)
        if (pct[pct_idx] < 3) pct[pct_idx] += 1;
    } else {
        // miss that caused an eviction → weaken confidence (saturating at 0)
        if (pct[pct_idx] > 0) pct[pct_idx] -= 1;
    }

    // ----- 2. Update per‑line Reuse Confidence (RC) -----
    if (hit) {
        // On a hit we reset RC to max value (255) – line is hot
        rc[set][way] = 255;
    } else {
        // On insertion (miss) we seed RC according to PC confidence
        // High PC confidence → higher initial RC, low confidence → lower RC
        uint8_t init_rc;
        switch (pct[pct_idx]) {
            case 3: init_rc = 200; break;   // strong PC → strong line
            case 2: init_rc = 150; break;
            case 1: init_rc = 100; break;
            default: init_rc = 50; break;   // weak PC → weak line
        }
        rc[set][way] = init_rc;
    }

    // ----- 3. Record timestamp (optional, useful for debugging) -----
    last_access_ts[set][way] = global_timestamp;
}

/* ------------------------------------------------------------------
 *  Optional statistics printing
 * ------------------------------------------------------------------ */
void PrintStats() {
    // Example: average RC value across the entire LLC
    uint64_t sum = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            sum += rc[s][w];

    double avg_rc = static_cast<double>(sum) /
                    static_cast<double>(LLC_SETS * LLC_WAYS);
    std::cout << "CWRP: average line RC = " << avg_rc << std::endl;
}

/* ------------------------------------------------------------------
 *  Optional periodic heartbeat statistics
 * ------------------------------------------------------------------ */
void PrintStats_Heartbeat() {
    // Could print per‑PC confidence distribution or RC histogram here.
}
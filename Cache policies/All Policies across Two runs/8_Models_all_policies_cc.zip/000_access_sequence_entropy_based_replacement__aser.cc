#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define PC_WINDOW 4          // number of PCs to keep per line

// Per‑way metadata
struct WayMeta {
    uint32_t pc_window[PC_WINDOW];   // last PCs that accessed this line
    uint32_t pc_count;               // how many entries are valid (≤ PC_WINDOW)
    uint32_t age;                    // simple recency counter (incremented each access)
};

static std::vector<std::vector<WayMeta>> llc_meta;  // [set][way]

// -----------------------
//  Initialization
// -----------------------
void InitReplacementState() {
    llc_meta.resize(LLC_SETS);
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        llc_meta[s].resize(LLC_WAYS);
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            WayMeta &m = llc_meta[s][w];
            m.pc_count = 0;
            m.age = 0;
        }
    }
}

// -----------------------
//  Victim selection
// -----------------------
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    (void)cpu; (void)paddr; (void)type;   // unused in this policy

    uint32_t victim = 0;
    uint32_t max_entropy = 0;
    uint32_t oldest_age = UINT32_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        if (!current_set[way].valid) {
            // Empty line – immediate victim
            return way;
        }

        // Compute entropy: count distinct PCs in window
        uint32_t distinct = 0;
        for (uint32_t i = 0; i < llc_meta[set][way].pc_count; ++i) {
            bool seen = false;
            for (uint32_t j = 0; j < i; ++j) {
                if (llc_meta[set][way].pc_window[j] ==
                    llc_meta[set][way].pc_window[i]) {
                    seen = true;
                    break;
                }
            }
            if (!seen) distinct++;
        }

        uint32_t age = llc_meta[set][way].age;
        if (distinct > max_entropy ||
            (distinct == max_entropy && age > oldest_age)) {
            max_entropy = distinct;
            oldest_age   = age;
            victim       = way;
        }
    }
    return victim;
}

// -----------------------
//  Update metadata
// -----------------------
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    (void)cpu; (void)paddr; (void)victim_addr; (void)type;   // unused

    WayMeta &m = llc_meta[set][way];

    // Shift window entries left
    if (m.pc_count < PC_WINDOW) {
        for (uint32_t i = m.pc_count; i > 0; --i)
            m.pc_window[i] = m.pc_window[i-1];
        m.pc_window[0] = (uint32_t)(PC & 0xffffffffULL);
        ++m.pc_count;
    } else {
        for (uint32_t i = PC_WINDOW-1; i > 0; --i)
            m.pc_window[i] = m.pc_window[i-1];
        m.pc_window[0] = (uint32_t)(PC & 0xffffffffULL);
    }

    // Increment global age counter for this line
    m.age++;
}

// -----------------------
//  Stats (optional)
// -----------------------
void PrintStats() {
    // No stats to print for this simple policy
}

void PrintStats_Heartbeat() {
    // Optional periodic reporting
    std::cout << "ASeR heartbeat: set " << LLC_SETS
              << ", ways " << LLC_WAYS << std::endl;
}
#include <vector>
#include <cstdint>
#include <algorithm>
#include <limits>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// ---------- parameters ----------
constexpr uint32_t PC_BITS         = 12;                // PC index bits
constexpr uint32_t FREQ_TBL_SIZE     = 1 << PC_BITS;
constexpr uint32_t FREQ_SAT_MAX    = 255;
constexpr uint32_t DELTA_EMA_SHIFT   = 4;                 // EMA weight 1/16
constexpr uint64_t DECAY_INTERVAL     = 1000000;           // cycles
// ---------- metadata per line ----------
struct line_meta {
    uint64_t last_cycle      = 0;
    uint32_t ema_reuse       = 0;      // EMA of reuse distance in cycles
    uint32_t freq_score      = 0;      // copied from global table at fill
};

static std::vector<std::vector<line_meta>> meta;   // [set][way]
static std::vector<uint32_t> freq_table;           // global PC->freq
static uint64_t next_decay = DECAY_INTERVAL;

// ---------------------------------
void InitReplacementState() {
    meta.assign(LLC_SETS, std::vector<line_meta>(LLC_WAYS));
    freq_table.assign(FREQ_TBL_SIZE, 0);
}

// ---------------------------------
static uint32_t pc_hash(uint64_t pc) {
    return (pc >> 2) & (FREQ_TBL_SIZE - 1);
}

// ---------------------------------
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type) {
    uint32_t vict_way = 0;
    double min_score  = std::numeric_limits<double>::max();

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (current_set[w].valid == 0) return w;          // invalid is best victim
        const auto &m = meta[set][w];
        uint32_t reuse_delta = (m.ema_reuse == 0) ? 1 : m.ema_reuse;
        double surprise = std::log(reuse_delta + 1);        // log to compress range
        double score    = surprise / (m.freq_score + 1);    // high freq -> low score
        if (score < min_score) {
            min_score = score;
            vict_way  = w;
        }
    }
    return vict_way;
}

// ---------------------------------
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                            uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                            uint32_t type, uint8_t hit) {
    auto &m = meta[set][way];

    uint64_t curr_cycle = current_core_cycle[cpu];
    if (hit) {
        // ---- update frequency table ----
        uint32_t idx = pc_hash(PC);
        if (freq_table[idx] < FREQ_SAT_MAX) ++freq_table[idx];
        m.freq_score = freq_table[idx];
        // ---- update reuse-interval EMA ----
        uint64_t delta = curr_cycle - m.last_cycle;
        uint32_t ema = m.ema_reuse;
        ema = ((delta << DELTA_EMA_SHIFT) + ema * ((1u<<DELTA_EMA_SHIFT)-1)) >> DELTA_EMA_SHIFT;
        m.ema_reuse = std::min(ema, 0xFFFFFu); // clamp
    }
    // always update timestamp
    m.last_cycle = curr_cycle;

    // ---- bulk decay frequency counters every few million cycles ----
    if (curr_cycle >= next_decay) {
        for (auto &f : freq_table)
            f = f >> 1;                  // halve all counters
        next_decay += DECAY_INTERVAL;
    }
}

// ---------------------------------
void PrintStats() {
    // nothing special to print
}
void PrintStats_Heartbeat() {
    // optional heartbeat
}
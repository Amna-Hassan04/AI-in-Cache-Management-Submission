//===================================================================
//  ARIP-LRU: Adaptive Re-reference Interval Prediction LRU
//===================================================================

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)   // total number of sets
#define LLC_WAYS 16                  // associativity

/*---------------------------------------------------------------*/
/*  Per‑line metadata: 2‑bit Re‑reference Prediction Value (RRPV) */
/*  0 = most likely to be re‑referenced soon (MRU)               */
/*  3 = least likely (candidate for eviction)                   */
/*---------------------------------------------------------------*/
static uint8_t rrpv[LLC_SETS][LLC_WAYS];   // 2‑bit values stored in a byte

/*---------------------------------------------------------------*/
/*  Per‑set metadata: signed 8‑bit confidence counter            */
/*  Positive → set has been hot (many hits)                     */
/*  Negative → set has been cold (many misses)                  */
/*---------------------------------------------------------------*/
static int8_t set_conf[LLC_SETS];

/*---------------------------------------------------------------*/
/*  Statistics (optional but useful)                             */
/*---------------------------------------------------------------*/
static uint64_t total_hits   = 0;
static uint64_t total_misses = 0;

/*===================================================================*/
/*  Initialise all metadata structures                               */
/*===================================================================*/
void InitReplacementState()
{
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        set_conf[s] = 0;
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            rrpv[s][w] = 3;                 // start maximally distant
        }
    }
}

/*===================================================================*/
/*  Choose a victim line in the given set                            */
/*===================================================================*/
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
)
{
    // 1. Look for a line whose RRPV == 3 (max).  If multiple, pick first.
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (rrpv[set][w] == 3)
            return w;
    }

    // 2. No line with RRPV==3 → increment all RRPVs (saturating at 3)
    //    and repeat the search.  In practice we loop until we find one.
    while (true) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            if (rrpv[set][w] < 3)
                ++rrpv[set][w];
        }
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            if (rrpv[set][w] == 3)
                return w;
        }
    }

    // Should never reach here
    return 0;
}

/*===================================================================*/
/*  Update the replacement state after each access                    */
/*===================================================================*/
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
)
{
    if (hit) {
        // ----- HIT -------------------------------------------------
        ++total_hits;
        // Reset RRPV to 0 (most recently used)
        rrpv[set][way] = 0;

        // Boost set confidence (saturate at +127)
        if (set_conf[set] < 127)
            ++set_conf[set];
    } else {
        // ----- MISS ------------------------------------------------
        ++total_misses;

        // We are about to place a new block in (set, way)
        // Decide insertion RRPV based on set confidence
        //   Hot set (conf >= THRESH) → insert close to MRU (RRPV = 0)
        //   Cold set                 → insert farther (RRPV = 2)
        const int8_t THRESH = 4;   // empirical; can be tuned
        if (set_conf[set] >= THRESH) {
            rrpv[set][way] = 0;          // treat as likely to be reused
        } else {
            rrpv[set][way] = 2;          // give it a chance to age out
        }

        // Decrease set confidence (saturate at -128)
        if (set_conf[set] > -128)
            --set_conf[set];
    }
}

/*===================================================================*/
/*  Optional: print final statistics at the end of simulation        */
/*===================================================================*/
void PrintStats()
{
    std::cout << "=== ARIP-LRU Statistics ===\n";
    std::cout << "  Total accesses   : " << (total_hits + total_misses) << "\n";
    std::cout << "  Hits             : " << total_hits << "\n";
    std::cout << "  Misses           : " << total_misses << "\n";
    double hr = (total_hits * 100.0) / (total_hits + total_misses);
    std::cout << "  Hit rate (%)     : " << hr << "\n";
}

/*===================================================================*/
/*  Optional: periodic heartbeat (called by ChampSim)                */
/*===================================================================*/
void PrintStats_Heartbeat()
{
    // For brevity we keep this empty; users can add progress prints.
}
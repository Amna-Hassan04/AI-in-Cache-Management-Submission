#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to hold temporal and spatial metadata
struct HTSFMetadata {
  uint64_t last_access_timestamp;
  uint32_t spatial_frequency;
};

// Array to store metadata for all cache lines
HTSFMetadata htsf_metadata[LLC_SETS][LLC_WAYS];

// Initialize replacement state
void InitReplacementState() {
  for (uint32_t set = 0; set < LLC_SETS; set++) {
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
      htsf_metadata[set][way].last_access_timestamp = 0;
      htsf_metadata[set][way].spatial_frequency = 0;
    }
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint64_t current_timestamp = champsim_crc2::cycle;
  uint32_t victim_way = 0;
  float min_score = std::numeric_limits<float>::max();

  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint64_t temporal_distance = current_timestamp - htsf_metadata[set][way].last_access_timestamp;
    uint32_t spatial_freq = htsf_metadata[set][way].spatial_frequency;
    float score = (temporal_distance * 0.7f) + (spatial_freq * 0.3f); // Weighted scoring

    if (score < min_score) {
      min_score = score;
      victim_way = way;
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  uint64_t current_timestamp = champsim_crc2::cycle;

  // Update temporal locality metadata
  htsf_metadata[set][way].last_access_timestamp = current_timestamp;

  // Update spatial frequency metadata
  uint32_t spatial_region = (paddr >> 6) & 0x3F; // Example spatial region calculation
  if (spatial_region == (current_set[way].address >> 6) & 0x3F) {
    htsf_metadata[set][way].spatial_frequency++;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  std::cout << "HTSF Policy Stats:" << std::endl;
  // Add any desired statistics printing here
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Add any desired periodic statistics printing here
}
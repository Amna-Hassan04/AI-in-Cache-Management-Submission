#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to hold entropy-related metadata for a cache line
struct EntropyMetadata {
    uint32_t access_count;
    double probability;
};

std::vector<std::vector<EntropyMetadata>> entropy_metadata(LLC_SETS, std::vector<EntropyMetadata>(LLC_WAYS));

// Initialize replacement state
void InitReplacementState() {
    for (auto& set_metadata : entropy_metadata) {
        for (auto& line_metadata : set_metadata) {
            line_metadata.access_count = 0;
            line_metadata.probability = 0.0;
        }
    }
}

// Calculate entropy for a given set
double CalculateEntropy(const uint32_t set) {
    double entropy = 0.0;
    uint32_t total_accesses = 0;
    for (const auto& line_metadata : entropy_metadata[set]) {
        total_accesses += line_metadata.access_count;
    }
    if (total_accesses == 0) return 0.0;
    
    for (const auto& line_metadata : entropy_metadata[set]) {
        double p = static_cast<double>(line_metadata.access_count) / total_accesses;
        if (p > 0) {
            entropy -= p * log2(p);
        }
    }
    return entropy;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    double set_entropy = CalculateEntropy(set);
    uint32_t victim_way = 0;
    double max_contribution = -1.0;
    
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        double contribution = entropy_metadata[set][way].probability * set_entropy;
        if (contribution > max_contribution) {
            max_contribution = contribution;
            victim_way = way;
        }
    }
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        entropy_metadata[set][way].access_count++;
    }
    // Normalize probabilities for the set
    uint32_t total_accesses = 0;
    for (auto& line_metadata : entropy_metadata[set]) {
        total_accesses += line_metadata.access_count;
    }
    for (auto& line_metadata : entropy_metadata[set]) {
        line_metadata.probability = static_cast<double>(line_metadata.access_count) / total_accesses;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optionally, print final entropy statistics or other relevant metrics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optionally, print progress stats, such as average entropy across sets
}
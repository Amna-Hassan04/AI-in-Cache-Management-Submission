/********************************************************************
 *  Reuse‑Distance Prediction Replacement (RDPR)                     *
 *  Author: <Your Name>                                            *
 *  This file is intended to be dropped into the Champsim codebase. *
 ********************************************************************/

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// ------------------------------------------------------------------
// Metadata for each cache line
// ------------------------------------------------------------------
struct LineMeta {
    uint64_t last_access_time;  // Global instruction counter
    double   pred_rd;           // Predicted reuse distance
    uint32_t hit_count;         // Optional statistic
    bool      valid;            // Indicates whether the line currently holds data
};

static std::vector<std::vector<LineMeta>> meta;   // [set][way]
static uint64_t global_time = 0;                  // Global instruction counter
static const double ALPHA = 0.5;                  // Smoothing factor for RD prediction

// ------------------------------------------------------------------
// Initialize replacement state
// ------------------------------------------------------------------
void InitReplacementState() {
    meta.resize(LLC_SETS, std::vector<LineMeta>(LLC_WAYS));

    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            meta[s][w].last_access_time = 0;
            meta[s][w].pred_rd           = 0.0;
            meta[s][w].hit_count         = 0;
            meta[s][w].valid             = false;
        }
    }

    global_time = 0;
}

// ------------------------------------------------------------------
// Choose victim line in the set
// ------------------------------------------------------------------
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    (void)cpu; (void)PC; (void)paddr; (void)type; (void)current_set; // unused

    uint32_t victim = 0;
    double   best_rd = -1.0;
    uint64_t lru_time = UINT64_MAX;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        const LineMeta &lm = meta[set][w];

        // If line is empty, it is immediately a candidate
        if (!lm.valid) {
            victim = w;
            return victim;
        }

        // Prefer line with largest predicted reuse distance
        if (lm.pred_rd > best_rd) {
            best_rd = lm.pred_rd;
            victim  = w;
            lru_time = lm.last_access_time;
            continue;
        }

        // Tie‑breaker: LRU
        if (lm.pred_rd == best_rd && lm.last_access_time < lru_time) {
            victim  = w;
            lru_time = lm.last_access_time;
        }
    }

    return victim;
}

// ------------------------------------------------------------------
// Update replacement state
// ------------------------------------------------------------------
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    (void)cpu; (void)PC; (void)type; (void)victim_addr; // unused

    // Increment global time for every reference
    ++global_time;

    LineMeta &lm = meta[set][way];

    if (hit) {   // Cache hit
        uint64_t actual_rd = global_time - lm.last_access_time;

        // Update predicted reuse distance with exponential smoothing
        lm.pred_rd = ALPHA * static_cast<double>(actual_rd) + (1.0 - ALPHA) * lm.pred_rd;

        lm.last_access_time = global_time;
        ++lm.hit_count;
    } else {     // Cache miss – new line inserted
        lm.valid            = true;
        lm.last_access_time = global_time;
        lm.pred_rd           = static_cast<double>(global_time);   // Initial guess: reuse far in future
        lm.hit_count         = 0;
    }
}

// ------------------------------------------------------------------
// Print end‑of‑simulation statistics
// ------------------------------------------------------------------
void PrintStats() {
    // Example: compute average predicted RD for all lines
    double sum_rd = 0.0;
    uint64_t total_lines = 0;

    for (const auto &set : meta) {
        for (const auto &lm : set) {
            if (lm.valid) {
                sum_rd += lm.pred_rd;
                ++total_lines;
            }
        }
    }

    std::cout << "[RDPR] Avg. Predicted Reuse Distance: "
              << (total_lines ? sum_rd / total_lines : 0.0) << " cycles\n";
}

// ------------------------------------------------------------------
// Print periodic statistics (heartbeat)
// ------------------------------------------------------------------
void PrintStats_Heartbeat() {
    // Optional: print a simple progress counter
    static uint64_t heartbeat_cnt = 0;
    ++heartbeat_cnt;

    if (heartbeat_cnt % 1000000 == 0) {
        std::cout << "[RDPR] Heartbeat at global time: " << global_time << "\n";
    }
}
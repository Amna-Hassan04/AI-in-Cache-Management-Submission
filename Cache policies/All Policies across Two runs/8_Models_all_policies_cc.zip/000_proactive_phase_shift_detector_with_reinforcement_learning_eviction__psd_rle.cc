#include <vector>
#include <cstdint>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// ------------------ metadata ------------------
struct LINE_META {
    uint8_t  corr_ctr   : 3;   // reuse correlation counter
    uint8_t  last_bit   : 1;   // spectrogram bit when last touched
    uint8_t  udist       : 8;   // cheap reuse-distance hash
};
static LINE_META meta[LLC_SETS][LLC_WAYS];

static uint32_t spectrogram[LLC_SETS];     // 32-bit history
static uint8_t  confidence[LLC_SETS];      // 2-bit confidence
static uint8_t  reward[256];               // 2-bit rewards

// bit population count helpers
static int popcnt32(uint32_t x){
    return __builtin_popcount(x);
}

// Initialize replacement state
void InitReplacementState()
{
    for(uint32_t s=0; s<LLC_SETS; ++s){
        spectrogram[s] = 0;
        confidence[s]  = 0;
        for(uint32_t w=0; w<LLC_WAYS; ++w){
            meta[s][w].corr_ctr = 0;
            meta[s][w].last_bit = 0;
            meta[s][w].udist    = 0;
        }
       }
    }
    for(int i=0;i<256;i++) reward[i]=1;
}

// Choose victim
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type)
{
    uint32_t victim_way = 0;
    int min_score = 999;

    uint8_t conf = confidence[set];
    uint32_t spec_bit = (spectrogram[set] & 1u);

    // exploration flag: if last chosen victim had reward 0, force youngest
    static uint32_t last_victim[LLC_SETS] = {0};
    static bool force_young[LLC_SETS] = {0};
    uint32_t idx = ((PC>>5) ^ set ^ (conf<<4)) & 0xFFu;
    if(force_young[set]){
        force_young[set]=false;
        return last_victim[set];
    }

    if(conf >= 2){ // predictable phase
        for(uint32_t w=0;w<LLC_WAYS;w++){
            int score = (meta[set][w].corr_ctr) + ((meta[set][w].last_bit == spec_bit)?2:0);
            if(score < min_score){
                min_score = score;
                victim_way = w;
            }
        }
    } else { // chaotic phase -> approximate LRU
        uint32_t max_udist = 0;
        for(uint32_t w=0;w<LLC_WAYS;w++){
            if(meta[set][w].udist >= max_udist){
                max_udist = meta[set][w].udist;
                victim_way = w;
            }
        }
    }
    last_victim[set] = victim_way;
    if(reward[idx]==0) force_young[set]=true;
    return victim_way;
}

// Update state
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                            uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                            uint32_t type, uint8_t hit)
{
    // update spectrogram
    spectrogram[set] = (spectrogram[set]<<1) | (hit?1u:0u);

    // update confidence
    int ones = popcnt32(spectrogram[set]);
    if(ones >= 24)        { if(confidence[set]<3) confidence[set]++; }
    else if(ones <= 8)    { if(confidence[set]>0) confidence[set]--; }

    // update correlation counter for touched line
    uint32_t spec_bit = (spectrogram[set] & 1u);
    if(hit){
        if(meta[set][way].last_bit == spec_bit){
            if(meta[set][way].corr_ctr < 7) meta[set][way].corr_ctr++;
        } else {
            if(meta[set][way].corr_ctr > 0) meta[set][way].corr_ctr--;
        }
    }
    meta[set][way].last_bit = spec_bit;

    // update reuse-distance hash (simply age others)
    for(uint32_t w=0;w<LLC_WAYS;w++){
        if(w==way) meta[set][w].udist = 0;
        else       if(meta[set][w].udist<255) meta[set][w].udist++;
    }

    // reward update
    uint32_t idx = ((PC>>5) ^ set ^ (confidence[set]<<4)) & 0xFFu;
    if(hit){
        if(reward[idx]<3) reward[idx]++;
    } else {
        if(reward[idx]>0) reward[idx]--;
    }
}

void PrintStats(){
    // no extra stats needed
}
void PrintStats_Heartbeat(){
    // no heartbeat info
}
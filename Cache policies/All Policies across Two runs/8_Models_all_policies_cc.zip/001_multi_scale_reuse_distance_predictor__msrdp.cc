/*********************************************************************
 *  Multi‑Scale Reuse‑Distance Predictor (MSRDP) for ChampSim
 *
 *  This file follows the standard ChampSim replacement‑policy template.
 *  It implements per‑line metadata for three reuse‑distance buckets,
 *  a simple stride detector, and a hybrid victim‑selection score.
 *
 *  Author: <your name>
 *  Date  : 2025‑09‑17
 *********************************************************************/

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* -----------------------------------------------------------------
 *  Tunable parameters – feel free to expose them via a config file.
 * ----------------------------------------------------------------- */
static const uint64_t S1 =  64;   // upper bound of short distance bucket
static const uint64_t S2 = 1024;  // upper bound of medium distance bucket

static const uint32_t MAX_CNT   = 7;   // saturating counter max value
static const uint32_t STRIDE_CONF_THRESH = 3; // steps to consider stride‑stable

static const float w_recency = 1.0f;
static const float w_pred    = 0.8f;
static const float w_stride  = 0.6f;

/* -----------------------------------------------------------------
 *  Per‑line metadata
 * ----------------------------------------------------------------- */
struct LineInfo {
    uint64_t last_epoch;          // global epoch of last access
    uint8_t  sd_cnt;              // short‑distance counter
    uint8_t  md_cnt;              // medium‑distance counter
    uint8_t  ld_cnt;              // long‑distance counter
    uint8_t  pred_class;          // 0=SD,1=MD,2=LD (most‑significant counter)
    uint64_t prev_addr;           // address seen on previous access
    uint8_t  stride_conf;         // confidence that we are on a stable stride
    int64_t  stride;              // current stride value (may be negative)
};

static std::vector<std::vector<LineInfo>> meta; // [set][way]
static uint64_t global_epoch = 0;               // increments on every access

/* -----------------------------------------------------------------
 *  Helper functions
 * ----------------------------------------------------------------- */
inline uint8_t saturate_inc(uint8_t v) { return (v < MAX_CNT) ? v + 1 : v; }

inline void update_pred_class(LineInfo &li) {
    // Choose the bucket with the largest counter; ties favour shorter distance
    if (li.ld_cnt > li.md_cnt && li.ld_cnt > li.sd_cnt) li.pred_class = 2;
    else if (li.md_cnt > li.sd_cnt)                     li.pred_class = 1;
    else                                                li.pred_class = 0;
}

/* -----------------------------------------------------------------
 *  Required entry points
 * ----------------------------------------------------------------- */
void InitReplacementState() {
    meta.resize(LLC_SETS, std::vector<LineInfo>(LLC_WAYS));

    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            meta[s][w] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
        }
    }
    global_epoch = 0;
}

/* Choose victim line in the set */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    float worst_score = -1.0f;
    uint32_t victim_way = 0;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        const LineInfo &li = meta[set][way];

        // If the line is invalid, pick it immediately
        if (!current_set[way].valid) {
            return way;
        }

        // 1) Recency term
        float age = static_cast<float>(global_epoch - li.last_epoch);

        // 2) Predicted reuse class weight
        const float class_weight[3] = { 0.2f, 0.5f, 1.0f }; // SD < MD < LD
        float pred = class_weight[li.pred_class];

        // 3) Stride bonus (stable stride lines are less likely to be evicted)
        float stride_bonus = (li.stride_conf >= STRIDE_CONF_THRESH) ? w_stride : 0.0f;

        float score = w_recency * age + w_pred * pred - stride_bonus;

        if (score > worst_score) {
            worst_score = score;
            victim_way  = way;
        }
    }
    return victim_way;
}

/* Update replacement state after each access */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    ++global_epoch;                     // advance global time

    LineInfo &li = meta[set][way];

    // -------------------------------------------------------------
    // 1) Compute reuse distance (epoch delta) for the accessed line
    // -------------------------------------------------------------
    uint64_t distance = (li.last_epoch == 0) ? 0 : (global_epoch - li.last_epoch);

    if (distance < S1) {
        li.sd_cnt = saturate_inc(li.sd_cnt);
    } else if (distance < S2) {
        li.md_cnt = saturate_inc(li.md_cnt);
    } else {
        li.ld_cnt = saturate_inc(li.ld_cnt);
    }
    update_pred_class(li);

    // -------------------------------------------------------------
    // 2) Stride detection
    // -------------------------------------------------------------
    if (li.prev_addr != 0) {
        int64_t cur_stride = static_cast<int64_t>(paddr) - static_cast<int64_t>(li.prev_addr);
        if (li.stride_conf == 0) {
            // first stride observation
            li.stride = cur_stride;
            li.stride_conf = 1;
        } else if (cur_stride == li.stride) {
            // stride continues
            if (li.stride_conf < 255) ++li.stride_conf;
        } else {
            // stride broken – restart detection
            li.stride = cur_stride;
            li.stride_conf = 1;
        }
    }
    li.prev_addr = paddr;

    // -------------------------------------------------------------
    // 3) Refresh recency info
    // -------------------------------------------------------------
    li.last_epoch = global_epoch;

    // -------------------------------------------------------------
    // 4) On a miss that caused an insertion, we need to reset the
    //    metadata of the newly allocated line (the caller passes
    //    the *victim* way for the insertion case).
    // -------------------------------------------------------------
    if (!hit) {
        // The caller has already installed the block in `way`.  Reset its
        // counters so that the new line starts with a clean slate.
        li.sd_cnt      = 0;
        li.md_cnt      = 0;
        li.ld_cnt      = 0;
        li.pred_class  = 0;
        li.stride_conf = 0;
        li.stride      = 0;
        li.prev_addr   = 0;
        // last_epoch already set above.
    }
}

/* Optional: print final statistics */
void PrintStats() {
    uint64_t total_sd = 0, total_md = 0, total_ld = 0, total_stride = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            const LineInfo &li = meta[s][w];
            total_sd   += li.sd_cnt;
            total_md   += li.md_cnt;
            total_ld   += li.ld_cnt;
            total_stride += (li.stride_conf >= STRIDE_CONF_THRESH);
        }
    }
    std::cout << "MSRDP stats:\n";
    std::cout << "  Short‑bucket hits   : " << total_sd   << "\n";
    std::cout << "  Medium‑bucket hits  : " << total_md   << "\n";
    std::cout << "  Long‑bucket hits    : " << total_ld   << "\n";
    std::cout << "  Stride‑stable lines : " << total_stride << "\n";
}

/* Optional: periodic heartbeat */
void PrintStats_Heartbeat() {
    // Could be left empty; ChampSim calls it every 10M accesses.
}
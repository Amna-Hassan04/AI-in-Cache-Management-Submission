#include <vector>
#include <deque>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define WAYS_HALF (LLC_WAYS/2)

// 2-bit saturating counter per line
static uint8_t shadow_cnt[LLC_SETS][LLC_WAYS];

// fully-associative wave buffer: stores <set,way> of currently hot lines
static std::deque< std::pair<uint32_t,uint32_t> > wave_buffer;

void InitReplacementState() {
    for(uint32_t s=0; s<LLC_SETS; ++s)
        for(uint32_t w=0; w<LLC_WAYS; ++w)
            shadow_cnt[s][w] = 0;
    wave_buffer.clear();
}

// Helper: find if <set,way> is already in wave buffer
static bool in_wave(uint32_t s, uint32_t w) {
    auto it = std::find(wave_buffer.begin(), wave_buffer.end(),
                        std::make_pair(s,w));
    return it != wave_buffer.end();
}

uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type) {
    uint32_t victim_way = 0;
    uint8_t  max_shadow = shadow_cnt[set][0];

    // pick line with highest shadow counter
    for(uint32_t w=1; w<LLC_WAYS; ++w) {
        if(shadow_cnt[set][w] > max_shadow) {
            max_shadow  = shadow_cnt[set][w];
            victim_way  = w;
        }
    }
    return victim_way;
}

void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                            uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                            uint32_t type, uint8_t hit) {
    if(hit) {
        // promote to wave buffer if not already present
        if(!in_wave(set,way)) {
            wave_buffer.emplace_back(set,way);
            if(wave_buffer.size() > WAYS_HALF) {
                // evict oldest from wave buffer
                auto [old_s, old_w] = wave_buffer.front();
                wave_buffer.pop_front();
                // increment shadow counter of the evictee
                if(shadow_cnt[old_s][old_w] < 3) ++shadow_cnt[old_s][old_w];
            }
        }
    }
    // nothing else to do on fill/eviction
}

void PrintStats() {}
void PrintStats_Heartbeat() {}
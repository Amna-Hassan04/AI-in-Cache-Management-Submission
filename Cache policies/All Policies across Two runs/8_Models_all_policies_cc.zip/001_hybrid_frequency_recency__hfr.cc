#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct line_metadata {
    uint64_t paddr;      // Physical address of the line
    uint64_t frequency;   // Number of accesses
    uint64_t recency;     // Timestamp of last access
};

std::vector<std::vector<line_metadata>> metadata(LLC_SETS, std::vector<line_metadata>(LLC_WAYS));
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            metadata[set][way].paddr = 0;
            metadata[set][way].frequency = 0;
            metadata[set][way].recency = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;
    
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (metadata[set][way].paddr != current_set[way].paddr) continue;
        
        uint64_t score = metadata[set][way].frequency * metadata[set][way].recency;
        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }
    
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        metadata[set][way].frequency++;
        metadata[set][way].recency = global_timestamp++;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Print total metadata (optional)
    uint64_t total_frequency = 0;
    uint64_t total_recency = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            total_frequency += metadata[set][way].frequency;
            total_recency += metadata[set][way].recency;
        }
    }
    std::cout << "Total Frequency: " << total_frequency << std::endl;
    std::cout << "Total Recency: " << total_recency << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: Print periodic statistics
}
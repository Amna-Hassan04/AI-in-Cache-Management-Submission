#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define CACHE_LINE_SIZE 64 // bytes

using namespace std;

// Global map to track cache presence
unordered_map<uint64_t, bool> cache_presence;

// Score metadata for each line
vector<vector<vector<uint32_t>>> scores(NUM_CORE, vector<vector<uint32_t>>(LLC_SETS, vector<uint32_t>(LLC_WAYS, 0)));

// Initialize replacement state
void InitReplacementState() {
    // Initialize scores to 0
    for (uint32_t cpu = 0; cpu < NUM_CORE; ++cpu) {
        for (uint32_t set = 0; set < LLC_SETS; ++set) {
            for (uint32_t way = 0; way < LLC_WAYS; ++way) {
                scores[cpu][set][way] = 0;
            }
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint32_t min_score = UINT32_MAX;
    
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        if (scores[cpu][set][way] < min_score) {
            min_score = scores[cpu][set][way];
            victim_way = way;
        }
    }
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update cache presence map
    if (hit == 0) { // Miss: new line is added
        cache_presence[paddr] = true;
    }
    if (victim_addr != 0) { // Evict: remove from map
        cache_presence[victim_addr] = false;
    }
    
    // Update scores for the accessed line
    if (hit == 1) { // Hit: update scores
        for (int offset = -3; offset <= 3; ++offset) {
            uint64_t nearby_addr = paddr + (offset * CACHE_LINE_SIZE);
            if (nearby_addr < paddr) {
                nearby_addr = paddr;
            }
            if (cache_presence.find(nearby_addr) != cache_presence.end()) {
                scores[cpu][set][way]++;
            }
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example: print average scores
    uint64_t total_score = 0;
    for (uint32_t cpu = 0; cpu < NUM_CORE; ++cpu) {
        for (uint32_t set = 0; set < LLC_SETS; ++set) {
            for (uint32_t way = 0; way < LLC_WAYS; ++way) {
                total_score += scores[cpu][set][way];
            }
        }
    }
    double avg = static_cast<double>(total_score) / (NUM_CORE * LLC_SETS * LLC_WAYS);
    cout << "Average score: " << avg << endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: print min and max scores in each set
    for (uint32_t set = 0; set < LLC_SETS; ++set) {
        uint32_t min = UINT32_MAX;
        uint32_t max = 0;
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            if (scores[0][set][way] < min) min = scores[0][set][way];
            if (scores[0][set][way] > max) max = scores[0][set][way];
        }
        cout << "Set " << set << " Min: " << min << " Max: " << max << endl;
    }
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct BranchPredictionHistory {
    uint8_t prediction_outcome; // 0: Predicted Not Taken, 1: Predicted Taken
    uint8_t prediction_age;   // Number of cycles since the prediction
};

// Initialize replacement state
void InitReplacementState() {
    // Allocate space for branch prediction history per line
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0; // Initialize with the first line
    uint32_t min_lru = current_set[victim].last_used;
    for (uint32_t i = 1; i < LLC_WAYS; i++) {
        uint32_t branch_penalty = 0;
        // Calculate penalty based on branch prediction history
        if (current_set[i].branch_history.prediction_age > 5) {
            branch_penalty = 1; // Penalty decreases with age
        }
        if (current_set[i].last_used < min_lru 
            || (current_set[i].last_used == min_lru && branch_penalty > 0)) { 
            victim = i;
            min_lru = current_set[i].last_used;
        } 
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update LRU timestamp
    current_set[way].last_used = cycle;

    // Update branch prediction history... (logic based on PC and fetched instruction)

}

// Print end-of-simulation statistics
void PrintStats() {
    // --- OPTIONAL: print final stats ---
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // --- OPTIONAL: print progress stats ---
}
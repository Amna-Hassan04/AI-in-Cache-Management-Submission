#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define MAX_GRAPH_SIZE 1024 // Max number of nodes in the graph

using namespace std;

// Structure to represent a graph node
struct Node {
    uint32_t line_id;
    uint32_t degree; // Number of edges
    bool visited;
};

// Structure to represent a cache set with graph
struct CacheSet {
    BLOCK lines[LLC_WAYS];
    unordered_map<uint32_t, Node> graph;
};

// Global replacement state
CacheSet cache_sets[LLC_SETS];

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t i = 0; i < LLC_SETS; i++) {
        cache_sets[i].graph.reserve(MAX_GRAPH_SIZE);
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    CacheSet &cache_set = cache_sets[set];

    // If the graph is empty, default to LRU
    if (cache_set.graph.empty()) {
        return 0;
    }

    // Identify nodes with low degree (isolated lines)
    vector<uint32_t> candidates;
    for (auto &node : cache_set.graph) {
        if (node.second.degree == 0) {
            candidates.push_back(node.first);
        }
    }

    // If no isolated lines, select a node with low degree
    if (candidates.empty()) {
        uint32_t min_degree = UINT32_MAX;
        for (auto &node : cache_set.graph) {
            if (node.second.degree < min_degree) {
                min_degree = node.second.degree;
                candidates.clear();
                candidates.push_back(node.first);
            } else if (node.second.degree == min_degree) {
                candidates.push_back(node.first);
            }
        }
    }

    // Randomly select a candidate
    return candidates[rand() % candidates.size()];
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    CacheSet &cache_set = cache_sets[set];
    uint32_t line_id = way;

    // Add or update node in the graph
    if (cache_set.graph.find(line_id) == cache_set.graph.end()) {
        Node new_node = {line_id, 0, false};
        cache_set.graph[line_id] = new_node;
    }

    // Update edges based on recent accesses
    if (hit) {
        // Strengthen connection to recently accessed lines
        for (auto &node : cache_set.graph) {
            if (node.second.visited) {
                cache_set.graph[line_id].degree++;
                node.second.degree++;
            }
        }
    }

    // Mark current line as visited
    cache_set.graph[line_id].visited = true;

    // Clean up graph periodically
    if (rand() % 1000 == 0) {
        for (auto it = cache_set.graph.begin(); it != cache_set.graph.end();) {
            if (it->second.degree == 0) {
                it = cache_set.graph.erase(it);
            } else {
                ++it;
            }
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    cout << "CGBCR Statistics:" << endl;
    // Add custom stats here
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: print progress stats
}
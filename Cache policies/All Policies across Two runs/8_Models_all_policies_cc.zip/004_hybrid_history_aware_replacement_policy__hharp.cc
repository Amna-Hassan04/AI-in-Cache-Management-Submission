#include <vector>
#include <cstdint>
#include <iostream>
#include <map>
#include <queue>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Define a structure to store cache line metadata
struct CacheLineMetadata {
    uint64_t last_access_time;
    uint64_t reuse_distance;
    uint32_t access_frequency;
};

// Initialize replacement state
std::map<uint64_t, CacheLineMetadata> cache_metadata;
std::queue<uint64_t> access_queue;

void InitReplacementState() {
    // Initialize metadata structures
    cache_metadata.clear();
    access_queue = std::queue<uint64_t>();
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;
    double min_score = std::numeric_limits<double>::max();

    // Iterate over cache lines in the set
    for (uint32_t i = 0; i < LLC_WAYS; i++) {
        // Calculate the score for the current cache line
        double score = CalculateScore(current_set[i].addr, PC, paddr);

        // Update the victim line if the current score is lower
        if (score < min_score) {
            min_score = score;
            victim = i;
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update metadata for the accessed cache line
    if (cache_metadata.find(victim_addr) != cache_metadata.end()) {
        cache_metadata[victim_addr].last_access_time = PC;
        cache_metadata[victim_addr].access_frequency++;
    } else {
        cache_metadata[victim_addr] = {PC, 0, 1};
    }

    // Update the access queue
    access_queue.push(victim_addr);
    if (access_queue.size() > 1000) {
        cache_metadata.erase(access_queue.front());
        access_queue.pop();
    }
}

// Calculate the score for a cache line
double CalculateScore(uint64_t addr, uint64_t PC, uint64_t paddr) {
    // Get the metadata for the cache line
    auto metadata = cache_metadata.find(addr);

    if (metadata == cache_metadata.end()) {
        return std::numeric_limits<double>::max();
    }

    // Calculate the reuse distance
    double reuse_distance = (double)metadata->second.reuse_distance;

    // Calculate the time-weighted probability
    double time_weighted_probability = (double)(PC - metadata->second.last_access_time) / (PC + 1);

    // Calculate the score
    double score = reuse_distance * 0.3 + time_weighted_probability * 0.7;

    return score;
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "Cache metadata size: " << cache_metadata.size() << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    std::cout << "Access queue size: " << access_queue.size() << std::endl;
}
#include <vector>
#include <cstdint>
#include <unordered_map>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct LineStruct {
    uint32_t frequency;
    uint32_t re_ref_count;
    bool evicted;
};

// Metadata for each set: map from physical address to LineStruct
std::vector<std::unordered_map<uint64_t, LineStruct>> metadata;

// Initialize replacement state
void InitReplacementState() {
    metadata.resize(LLC_SETS);
    for (auto& set : metadata) {
        set = std::unordered_map<uint64_t, LineStruct>();
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        const BLOCK *block = current_set[way];
        if (block->valid) { // Assuming BLOCK has a 'valid' field
            uint64_t current_paddr = block->paddr;
            auto it = metadata[set].find(current_paddr);
            if (it != metadata[set].end()) {
                LineStruct ls = it->second;
                uint64_t score = ls.frequency + ls.re_ref_count;
                if (score < min_score) {
                    min_score = score;
                    victim_way = way;
                }
            } else {
                // If not found, treat score as 0
                if (0 < min_score) {
                    min_score = 0;
                    victim_way = way;
                }
            }
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Update frequency on hit
        auto& set_metadata = metadata[set];
        auto it = set_metadata.find(paddr);
        if (it != set_metadata.end()) {
            it->second.frequency++;
        }
    } else {
        // Insert new line or update re-ref count
        auto& set_metadata = metadata[set];
        auto it = set_metadata.find(paddr);
        if (it != set_metadata.end()) {
            if (it->second.evicted) {
                it->second.re_ref_count++;
                it->second.evicted = false;
            }
        } else {
            LineStruct new_entry;
            new_entry.frequency = 1;
            new_entry.re_ref_count = 0;
            new_entry.evicted = false;
            set_metadata[paddr] = new_entry;
        }
    }

    // Mark victim as evicted if any
    if (victim_addr != 0) {
        auto& set_metadata = metadata[set];
        auto it = set_metadata.find(victim_addr);
        if (it != set_metadata.end()) {
            it->second.evicted = true;
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics: total frequency and re-ref counts
    for (size_t set = 0; set < metadata.size(); set++) {
        const auto& set_metadata = metadata[set];
        uint32_t total_frequency = 0;
        uint32_t total_re_ref = 0;
        for (const auto& entry : set_metadata) {
            total_frequency += entry.second.frequency;
            total_re_ref += entry.second.re_ref_count;
        }
        std::cout << "Set " << set << " stats: Frequency sum=" << total_frequency << ", Re-ref sum=" << total_re_ref << std::endl;
    }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: print per-set statistics periodically
    for (size_t set = 0; set < metadata.size(); set++) {
        const auto& set_metadata = metadata[set];
        if (!set_metadata.empty()) {
            std::cout << "Set " << set << " size: " << set_metadata.size() << std::endl;
            uint32_t max_freq = 0;
            for (const auto& entry : set_metadata) {
                if (entry.second.frequency > max_freq) {
                    max_freq = entry.second.frequency;
                }
            }
            std::cout << "Max frequency in set " << set << ": " << max_freq << std::endl;
        }
    }
}
#include <vector>
#include <cstdint>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

static std::vector<std::vector<uint8_t>> gravity;   // 3 bits per line 0..7

// Initialize replacement state
void InitReplacementState() {
    gravity.assign(LLC_SETS, std::vector<uint8_t>(LLC_WAYS, 4)); // mid gravity
}

// Return number of trailing zeros in a 64-bit value
static int tzcnt(uint64_t x) {
    if (x == 0) return 64;
    return __builtin_ctzll(x);
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint8_t  min_grav   = gravity[set][0];

    for (uint32_t w = 1; w < LLC_WAYS; ++w) {
        uint8_t g = gravity[set][w];
        if (g < min_grav) {
            min_grav   = g;
            victim_way = w;
        } else if (g == min_grav) {
            // keep the "smoother" tag (more trailing zeros)
            uint64_t tag_vic = current_set[victim_way].tag;
            uint64_t tag_can = current_set[w].tag;
            if (tzcnt(tag_can) > tzcnt(tag_vic))
                victim_way = w;
        }
    }
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Meteor shower: only on a miss in this set
    if (hit) return;

    // strengthen the filled line
    if (gravity[set][way] < 7) gravity[set][way]++;

    // weaken all others
    for (uint32_t w = 0; w < LLC_WAYS; ++w)
        if (w != way && gravity[set][w] > 0)
            gravity[set][w]--;
}

// Print end-of-simulation statistics
void PrintStats() {
    // (optional) could dump gravity histogram here
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // (optional) could dump gravity histogram here
}
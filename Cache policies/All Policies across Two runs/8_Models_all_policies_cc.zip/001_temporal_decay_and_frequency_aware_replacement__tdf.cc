#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct LineMetadata {
    uint32_t frequency;
    uint64_t last_access_time;
};

std::vector<std::vector<LineMetadata>> metadata(NUM_CORE, std::vector<LineMetadata>(LLC_SETS * LLC_WAYS, {0, 0}));
uint64_t current_time = 0;

void InitReplacementState() {
    for (auto& set : metadata) {
        for (auto& line : set) {
            line.frequency = 0;
            line.last_access_time = 0;
        }
    }
}

uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    float min_score = std::numeric_limits<float>::max();
    const float decay_factor = 0.9f;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        uint64_t line_paddr = current_set[way].paddr;
        uint64_t set_way_index = set * LLC_WAYS + way;
        const LineMetadata& line = metadata[cpu][set_way_index];

        if (line_paddr == paddr) {
            continue;
        }

        uint64_t delta_time = current_time - line.last_access_time;
        float score = line.frequency * powf(decay_factor, delta_time);

        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t set_way_index = set * LLC_WAYS + way;
    LineMetadata& line = metadata[cpu][set_way_index];

    if (hit) {
        line.frequency++;
        line.last_access_time = current_time;
    } else {
        line.frequency = 1;
        line.last_access_time = current_time;
    }

    current_time++;
}

void PrintStats() {
    // Example statistics output (simplified)
    std::cout << "Cache Statistics:" << std::endl;
    for (uint32_t set = 0; set < LLC_SETS; ++set) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            uint64_t index = set * LLC_WAYS + way;
            std::cout << "Set: " << set << ", Way: " << way 
                      << ", Frequency: " << metadata[0][index].frequency 
                      << ", Last Access: " << metadata[0][index].last_access_time 
                      << std::endl;
        }
    }
}

void PrintStats_Heartbeat() {
    // Optional: Print periodic statistics similar to PrintStats()
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define ECHO_BUFFER_SIZE 256

struct EchoEntry {
    uint64_t tag;
    uint32_t timestamp;
};

std::vector<EchoEntry> echoBuffer(ECHO_BUFFER_SIZE);

// Initialize replacement state
void InitReplacementState() {
    for (auto& entry : echoBuffer) {
        entry.tag = 0;
        entry.timestamp = 0;
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victimWay = 0;
    float minReuseProb = 1.0f;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t tag = current_set[way].tag;
        float reuseProb = EstimateReuseProbability(tag);

        if (reuseProb < minReuseProb) {
            minReuseProb = reuseProb;
            victimWay = way;
        }
    }

    return victimWay;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t tag = paddr >> 6; // Assuming 64-byte cache lines
    UpdateEchoBuffer(tag);

    if (hit) {
        // Update timestamp for hit line
        for (auto& entry : echoBuffer) {
            if (entry.tag == tag) {
                entry.timestamp = LLC_WAYS; // Mark as recently used
                break;
            }
        }
    }
}

void UpdateEchoBuffer(uint64_t tag) {
    for (auto& entry : echoBuffer) {
        if (entry.tag == tag) {
            // Entry found, update timestamp
            entry.timestamp = LLC_WAYS;
            return;
        }
    }

    // Entry not found, replace oldest entry
    uint32_t oldestIndex = 0;
    uint32_t minTimestamp = UINT32_MAX;
    for (uint32_t i = 0; i < ECHO_BUFFER_SIZE; i++) {
        if (echoBuffer[i].timestamp < minTimestamp) {
            minTimestamp = echoBuffer[i].timestamp;
            oldestIndex = i;
        }
    }

    echoBuffer[oldestIndex].tag = tag;
    echoBuffer[oldestIndex].timestamp = LLC_WAYS;

    // Decay timestamps
    for (auto& entry : echoBuffer) {
        if (entry.timestamp > 0) {
            entry.timestamp--;
        }
    }
}

float EstimateReuseProbability(uint64_t tag) {
    for (const auto& entry : echoBuffer) {
        if (entry.tag == tag) {
            // Found in echo buffer, high reuse probability
            return 0.1f; // low value means less likely to be victim
        }
    }

    // Not found, estimate based on timestamp distribution
    uint32_t count = 0;
    for (const auto& entry : echoBuffer) {
        if (entry.timestamp > LLC_WAYS / 2) {
            count++;
        }
    }

    return (float)count / ECHO_BUFFER_SIZE; // Higher count means more recent accesses
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "EchoPULSE stats: " << std::endl;
    // Add statistics printing here
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Add periodic statistics printing here
}
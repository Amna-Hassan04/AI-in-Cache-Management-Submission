#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define NEIGHBOR_WINDOW 16  // Number of neighboring lines to check

using namespace std;

struct LineMetadata {
    uint32_t temporal_score;  // Tracks recent accesses (temporal locality)
    uint32_t spatial_score;   // Tracks number of neighboring lines in cache (spatial locality)
};

vector<unordered_map<uint64_t, LineMetadata>> set_metadata;

void InitReplacementState() {
    set_metadata.resize(LLC_SETS);
    for (auto& set : set_metadata) {
        set = {};
    }
}

uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    auto& set = set_metadata[set];
    uint32_t victim_way = 0;
    uint32_t min_score = UINT32_MAX;

    for (int way = 0; way < LLC_WAYS; ++way) {
        uint64_t addr = current_set[way].paddr;
        auto it = set.find(addr);
        if (it == set.end()) {
            // Line is not in metadata, treat it as having default scores
            uint32_t score = 0;
            if (min_score > score) {
                min_score = score;
                victim_way = way;
            }
            continue;
        }

        // Calculate combined temporal and spatial score
        uint32_t combined_score = it->second.temporal_score + it->second.spatial_score;
        if (min_score > combined_score) {
            min_score = combined_score;
            victim_way = way;
        }
    }

    return victim_way;
}

void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    auto& set = set_metadata[set];
    if (type == LOAD || type == STORE) {
        if (hit) {
            auto it = set.find(paddr);
            if (it != set.end()) {
                it->second.temporal_score++;  // Increment temporal score on hit
            }
        } else {
            LineMetadata metadata = {1, 0};  // Initialize with temporal score 1 on insert
            set[paddr] = metadata;

            // Update spatial scores for the new line and its neighbors
            for (int delta = -NEIGHBOR_WINDOW; delta <= NEIGHBOR_WINDOW; ++delta) {
                uint64_t neighbor_addr = paddr + delta;
                auto neighbor_it = set.find(neighbor_addr);
                if (neighbor_it != set.end()) {
                    neighbor_it->second.spatial_score++;
                }
            }
        }
    }
}

void PrintStats() {
    // Print average scores
    uint32_t total_temporal = 0;
    uint32_t total_spatial = 0;
    uint32_t count = 0;
    
    for (const auto& set : set_metadata) {
        for (const auto& entry : set) {
            total_temporal += entry.second.temporal_score;
            total_spatial += entry.second.spatial_score;
            count++;
        }
    }
    
    if (count > 0) {
        cout << "Average temporal score: " << total_temporal / count << endl;
        cout << "Average spatial score: " << total_spatial / count << endl;
    }
}

void PrintStats_Heartbeat() {
    // Periodically print stats
    static uint32_t last_count = 0;
    uint32_t current_count = 0;
    
    for (const auto& set : set_metadata) {
        current_count += set.size();
    }
    
    if (current_count != last_count) {
        last_count = current_count;
        cout << "Current number of tracked lines: " << current_count << endl;
    }
}
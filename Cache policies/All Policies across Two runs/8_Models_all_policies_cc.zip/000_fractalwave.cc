#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structure
struct FractalWaveNode {
  uint32_t frequency;
  uint32_t recency;
  uint32_t spatial_locality;
  uint32_t children[LLC_WAYS];
};

std::vector<FractalWaveNode> metadata(LLC_SETS * LLC_WAYS);

// Initialize replacement state
void InitReplacementState() {
  for (auto& node : metadata) {
    node.frequency = 0;
    node.recency = 0;
    node.spatial_locality = 0;
    for (int i = 0; i < LLC_WAYS; i++) {
      node.children[i] = 0;
    }
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint32_t victim_way = 0;
  uint32_t min_importance = UINT32_MAX;

  for (int way = 0; way < LLC_WAYS; way++) {
    uint32_t importance = metadata[set * LLC_WAYS + way].frequency +
                         metadata[set * LLC_WAYS + way].recency +
                         metadata[set * LLC_WAYS + way].spatial_locality;
    if (importance < min_importance) {
      min_importance = importance;
      victim_way = way;
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  if (hit) {
    metadata[set * LLC_WAYS + way].frequency++;
    metadata[set * LLC_WAYS + way].recency = 0;
  } else {
    metadata[set * LLC_WAYS + way].recency++;
  }

  // Propagate wave through metadata tree
  for (int i = 0; i < LLC_WAYS; i++) {
    if (metadata[set * LLC_WAYS + i].children[way] != 0) {
      metadata[set * LLC_WAYS + i].frequency += metadata[set * LLC_WAYS + way].frequency;
      metadata[set * LLC_WAYS + i].recency += metadata[set * LLC_WAYS + way].recency;
    }
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print final metadata statistics
  std::cout << "FractalWave metadata statistics:" << std::endl;
  for (auto& node : metadata) {
    std::cout << "Frequency: " << node.frequency << ", Recency: " << node.recency << ", Spatial Locality: " << node.spatial_locality << std::endl;
  }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print periodic metadata statistics
  std::cout << "FractalWave metadata statistics (heartbeat):" << std::endl;
  for (auto& node : metadata) {
    std::cout << "Frequency: " << node.frequency << ", Recency: " << node.recency << ", Spatial Locality: " << node.spatial_locality << std::endl;
  }
}
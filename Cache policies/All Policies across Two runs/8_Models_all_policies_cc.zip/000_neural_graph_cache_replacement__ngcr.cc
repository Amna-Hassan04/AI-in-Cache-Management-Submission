#include <vector>
#include <cstdint>
#include <iostream>
#include <queue>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define MAX_GRAPH_SIZE 1024

using namespace std;

// Structure to represent a graph edge
struct Edge {
    uint64_t src;
    uint64_t dst;
    uint32_t weight;
};

// Structure to represent a graph node
struct Node {
    uint64_t addr;
    uint32_t centrality;
    vector<Edge> edges;
};

// Initialize replacement state
void InitReplacementState() {
    // Initialize an empty graph
    cache_graph.clear();
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        graph_sets[set] = {};
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Update the graph for the current set
    UpdateGraph(set, current_set);

    // Find the node with the lowest centrality and the weakest edges
    Node *victim_node = nullptr;
    uint32_t min_centrality = UINT32_MAX;
    for (auto &node : graph_sets[set]) {
        if (node.centrality < min_centrality) {
            min_centrality = node.centrality;
            victim_node = &node;
        }
    }

    // Find the line corresponding to the victim node
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (current_set[way].addr == victim_node->addr) {
            return way;
        }
    }

    // Default to LRU if no suitable victim is found
    return LLC_WAYS - 1;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update the graph for the current set
    UpdateGraph(set, nullptr);

    // Update the centrality of the accessed node
    for (auto &node : graph_sets[set]) {
        if (node.addr == paddr) {
            node.centrality++;
            break;
        }
    }
}

// Update the graph structure
void UpdateGraph(uint32_t set, const BLOCK *current_set) {
    // Add new nodes for each line in the set
    if (current_set != nullptr) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            bool node_exists = false;
            for (auto &node : graph_sets[set]) {
                if (node.addr == current_set[way].addr) {
                    node_exists = true;
                    break;
                }
            }

            if (!node_exists) {
                Node new_node;
                new_node.addr = current_set[way].addr;
                new_node.centrality = 0;
                graph_sets[set].push_back(new_node);
            }
        }
    }

    // Remove nodes that are no longer in the set
    for (auto it = graph_sets[set].begin(); it != graph_sets[set].end(); ) {
        bool node_still_in_set = false;
        if (current_set != nullptr) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                if (current_set[way].addr == it->addr) {
                    node_still_in_set = true;
                    break;
                }
            }
        }

        if (!node_still_in_set) {
            it = graph_sets[set].erase(it);
        } else {
            ++it;
        }
    }

    // Update edges between nodes based on access patterns
    for (auto &node : graph_sets[set]) {
        for (auto &edge : node.edges) {
            edge.weight--;
            if (edge.weight == 0) {
                // Remove edge if its weight reaches zero
                node.edges.erase(remove(node.edges.begin(), node.edges.end(), edge), node.edges.end());
            }
        }
    }

    // Add new edges for each pair of nodes that were accessed together
    if (current_set != nullptr) {
        for (uint32_t way1 = 0; way1 < LLC_WAYS; way1++) {
            for (uint32_t way2 = way1 + 1; way2 < LLC_WAYS; way2++) {
                Node *node1 = nullptr;
                Node *node2 = nullptr;
                for (auto &node : graph_sets[set]) {
                    if (node.addr == current_set[way1].addr) {
                        node1 = &node;
                    }
                    if (node.addr == current_set[way2].addr) {
                        node2 = &node;
                    }
                }

                if (node1 != nullptr && node2 != nullptr) {
                    // Add edge between node1 and node2 if it doesn't already exist
                    bool edge_exists = false;
                    for (auto &edge : node1->edges) {
                        if (edge.dst == node2->addr) {
                            edge_exists = true;
                            edge.weight++;
                            break;
                        }
                    }

                    if (!edge_exists) {
                        Edge new_edge;
                        new_edge.src = node1->addr;
                        new_edge.dst = node2->addr;
                        new_edge.weight = 1;
                        node1->edges.push_back(new_edge);
                    }
                }
            }
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    cout << "NGCR Policy Statistics:" << endl;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        cout << "Set " << set << ":" << endl;
        for (auto &node : graph_sets[set]) {
            cout << "Node " << node.addr << ": Centrality = " << node.centrality << endl;
            for (auto &edge : node.edges) {
                cout << "Edge to " << edge.dst << ": Weight = " << edge.weight << endl;
            }
        }
    }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Print current graph structure
    cout << "Current Graph Structure:" << endl;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        cout << "Set " << set << ":" << endl;
        for (auto &node : graph_sets[set]) {
            cout << "Node " << node.addr << ": Centrality = " << node.centrality << endl;
        }
    }
}

unordered_map<uint32_t, vector<Node>> graph_sets;
vector<Node> cache_graph;
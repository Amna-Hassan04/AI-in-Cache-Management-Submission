#include <vector>
#include <cstdint>
#include <iostream>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Global time counter to track access time
uint64_t global_time = 0;

struct LineInfo {
    uint64_t last_address;
    uint64_t prev_prev_address;
    uint32_t access_count;
    int regularity_score;
    uint64_t last_access_time;
};

// Metadata for each set and way
LineInfo cache_metadata[LLC_SETS][LLC_WAYS];

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; ++set) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            cache_metadata[set][way].last_address = 0;
            cache_metadata[set][way].prev_prev_address = 0;
            cache_metadata[set][way].access_count = 0;
            cache_metadata[set][way].regularity_score = 50; // Neutral starting score
            cache_metadata[set][way].last_access_time = 0;
        }
    }
}

// Calculate a score for each line in the set
int calculate_eviction_score(LineInfo line, uint64_t current_time) {
    int score = 0;
    // Lower scores mean more likely to be evicted
    // Regularity score contributes inversely: lower means less regular
    score += (100 - line.regularity_score) * 4;
    // Access count contributes: lower means less frequently accessed
    score += (line.access_count <= 2 ? 100 : 100 - line.access_count / 100);
    // Recency: lower the score if it hasn't been accessed recently
    uint64_t time_inactive = current_time - line.last_access_time;
    score += (time_inactive > 1000 ? 100 : time_inactive / 10);
    return score;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    LineInfo line_info[LLC_WAYS];
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        line_info[way] = cache_metadata[set][way];
    }

    std::vector<std::pair<uint32_t, int>> scores;
    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        int score = calculate_eviction_score(cache_metadata[set][way], global_time);
        scores.push_back({way, score});
    }

    // Sort by score (lowest to evict)
    std::sort(scores.begin(), scores.end(), [](auto a, auto b) {
        return a.second < b.second;
    });

    // Return the first way with the lowest score
    return scores[0].first;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    global_time++;
    LineInfo &line_info = cache_metadata[set][way];
    uint64_t current_address = paddr;

    // Update access count
    line_info.access_count++;
    line_info.last_access_time = global_time;
    line_info.last_address = current_address;

    // Update regularity score if this is not the first access
    if (line_info.access_count > 1) {
        // Check if we have two previous addresses
        if (line_info.prev_prev_address != 0) {
            uint64_t prev_stride = line_info.last_address - line_info.prev_prev_address;
            uint64_t current_stride = current_address - line_info.last_address;
            
            if (prev_stride == current_stride) {
                // Regular pattern detected
                line_info.regularity_score += 1;
                if (line_info.regularity_score > 100) {
                    line_info.regularity_score = 100;
                }
            } else {
                // Irregular pattern
                line_info.regularity_score -= 1;
                if (line_info.regularity_score < 0) {
                    line_info.regularity_score = 0;
                }
            }
        }
        line_info.prev_prev_address = line_info.last_address;
    }

    // Optional: Periodically decay the regularity score to prevent stale patterns
    if (line_info.access_count > 10 && (global_time % 10000 == 0)) {
        line_info.regularity_score -= 1;
        if (line_info.regularity_score < 50) {
            line_info.regularity_score = 50; // Minimum neutral score
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Implementation for printing stats if needed
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional implementation
}
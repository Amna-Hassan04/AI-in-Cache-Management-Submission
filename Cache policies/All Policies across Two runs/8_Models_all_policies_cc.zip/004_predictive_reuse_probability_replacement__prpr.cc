uint32_t pc_hash(uint64_t pc) {
    return ((pc >> 2) ^ (pc >> 8) ^ (pc >> 16)) & 0xFFF;   // 12‑bit hash
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Frequency-Aware table
std::vector<uint32_t> fa_table(LLC_SETS * LLC_WAYS, 0);

// Harmonic Mean Distance metadata
struct HMD {
  uint32_t sum;
  uint32_t count;
};

std::vector<HMD> hmd_metadata(LLC_SETS * LLC_WAYS);

// Initialize replacement state
void InitReplacementState() {
  for (auto& hmd : hmd_metadata) {
    hmd.sum = 0;
    hmd.count = 0;
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  uint32_t victim_way = 0;
  double min_hmd = std::numeric_limits<double>::max();

  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint32_t index = set * LLC_WAYS + way;
    double hmd = (hmd_metadata[index].count > 0) ?
                 (double)hmd_metadata[index].sum / hmd_metadata[index].count : std::numeric_limits<double>::max();
    if (fa_table[index] == 0 || hmd < min_hmd) {
      min_hmd = hmd;
      victim_way = way;
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  uint32_t index = set * LLC_WAYS + way;
  fa_table[index]++;
  if (hit) {
    uint32_t distance = /* calculate distance between consecutive accesses */;
    hmd_metadata[index].sum += distance;
    hmd_metadata[index].count++;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  std::cout << "HARMONY stats:" << std::endl;
  // Print final stats
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  std::cout << "HARMONY heartbeat stats:" << std::endl;
  // Print progress stats
}
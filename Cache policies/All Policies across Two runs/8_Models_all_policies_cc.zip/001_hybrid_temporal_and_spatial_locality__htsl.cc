#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct MetaData {
    uint64_t last_access_time;
    uint32_t neighbor_count;
};

// Global timestamp to track temporal locality
uint64_t timestamp = 0;

// Metadata for each block in the LLC
std::vector<std::vector<MetaData>> llc_metadata(NUM_CORE, std::vector<MetaData>(LLC_SETS, MetaData()));

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                llc_metadata[cpu][set][way].last_access_time = 0;
                llc_metadata[cpu][set][way].neighbor_count = 0;
            }
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t max_score = 0;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (current_set[way].paddr != 0) {
            uint64_t temporal_score = timestamp - llc_metadata[cpu][set][way].last_access_time;
            uint32_t spatial_score = 32 - llc_metadata[cpu][set][way].neighbor_count;
            uint64_t score = temporal_score + spatial_score;

            if (score > max_score) {
                max_score = score;
                victim_way = way;
            }
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    timestamp++;

    if (hit) {
        // Update metadata for the accessed block
        llc_metadata[cpu][set][way].last_access_time = timestamp;

        // Recalculate neighbor count for the accessed block
        llc_metadata[cpu][set][way].neighbor_count = 0;
        for (uint32_t other_way = 0; other_way < LLC_WAYS; other_way++) {
            if (other_way != way && current_set[other_way].paddr != 0) {
                if (std::abs((int64_t)paddr - (int64_t)current_set[other_way].paddr) <= 16) {
                    llc_metadata[cpu][set][way].neighbor_count++;
                }
            }
        }
    } else {
        // Insert new block and update metadata
        llc_metadata[cpu][set][way].last_access_time = timestamp;
        llc_metadata[cpu][set][way].neighbor_count = 0;

        // Calculate neighbor count for the new block
        for (uint32_t other_way = 0; other_way < LLC_WAYS; other_way++) {
            if (other_way != way && current_set[other_way].paddr != 0) {
                if (std::abs((int64_t)paddr - (int64_t)current_set[other_way].paddr) <= 16) {
                    llc_metadata[cpu][set][way].neighbor_count++;
                    llc_metadata[cpu][set][other_way].neighbor_count++;
                }
            }
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics: Average neighbor count per block
    uint32_t total_neighbor_count = 0;
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                total_neighbor_count += llc_metadata[cpu][set][way].neighbor_count;
            }
        }
    }
    std::cout << "Average neighbor count: " << (float)total_neighbor_count / (NUM_CORE * LLC_SETS * LLC_WAYS) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example heartbeat statistics: Distribution of neighbor counts
    std::cout << "Neighbor count distribution:" << std::endl;
    std::vector<int> distribution(33, 0);
    for (uint32_t cpu = 0; cpu < NUM_CORE; cpu++) {
        for (uint32_t set = 0; set < LLC_SETS; set++) {
            for (uint32_t way = 0; way < LLC_WAYS; way++) {
                distribution[llc_metadata[cpu][set][way].neighbor_count]++;
            }
        }
    }
    for (int i = 0; i < 33; i++) {
        std::cout << "Neighbor count " << i << ": " << distribution[i] << " blocks" << std::endl;
    }
}
//===================================================================
//  Spectral‑Reuse‑Entropy (SRE) Replacement Policy
//===================================================================

#include <vector>
#include <cstdint>
#include <cmath>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/*-----------------------------------------------------------------
   Tunable parameters
-----------------------------------------------------------------*/
static const uint32_t EPOCH_LENGTH = 10000;   // accesses between global decays
static const uint32_t GAP_HISTORY   = 4;      // number of inter‑arrival gaps kept
static const uint8_t  MAX_FREQ      = 255;    // saturating freq counter

static const uint32_t ALPHA = 2;   // weight for spectral bias
static const uint32_t BETA  = 1;   // weight for frequency term
static const uint32_t GAMMA = 3;   // weight for entropy term

/*-----------------------------------------------------------------
   Global bookkeeping
-----------------------------------------------------------------*/
static uint64_t GLOBAL_ACCESS_COUNTER = 0;      // monotonic counter
static uint64_t NEXT_EPOCH_TICK       = EPOCH_LENGTH;

/*-----------------------------------------------------------------
   Per‑set metadata: spectral histogram (4 exponential buckets)
-----------------------------------------------------------------*/
struct SpectralHist {
    // bucket 0: distance 1‑2
    // bucket 1: distance 3‑4
    // bucket 2: distance 5‑8
    // bucket 3: distance >8 (or unknown)
    uint16_t bucket[4] = {0,0,0,0};

    void reset() { bucket[0]=bucket[1]=bucket[2]=bucket[3]=0; }
} spectral[LLC_SETS];

/*-----------------------------------------------------------------
   Per‑line metadata
-----------------------------------------------------------------*/
struct LineMeta {
    uint64_t last_access_ts = 0;                 // last global timestamp
    uint64_t last_stack_dist = 0;                // stack distance at last hit
    uint8_t  freq = 0;                           // saturating frequency counter
    uint16_t gaps[GAP_HISTORY] = {0,0,0,0};      // recent inter‑arrival gaps
    uint8_t  gap_idx = 0;                        // circular index
    float    entropy = 0.0f;                     // pre‑computed entropy
} meta[LLC_SETS][LLC_WAYS];

/*-----------------------------------------------------------------
   Helper: compute Shannon entropy of the last N gaps
-----------------------------------------------------------------*/
static float compute_entropy(const uint16_t gaps[GAP_HISTORY]) {
    // sum of gaps (avoid zero division)
    uint32_t sum = 0;
    for (uint32_t i = 0; i < GAP_HISTORY; ++i) sum += gaps[i];
    if (sum == 0) return 0.0f;

    float ent = 0.0f;
    for (uint32_t i = 0; i < GAP_HISTORY; ++i) {
        if (gaps[i] == 0) continue;
        float p = static_cast<float>(gaps[i]) / sum;
        ent -= p * std::log2(p);
    }
    return ent;   // max ~ log2(GAP_HISTORY)
}

/*-----------------------------------------------------------------
   Helper: estimate stack distance (approximate, O(LLC_WAYS))
-----------------------------------------------------------------*/
static uint64_t estimate_stack_distance(uint32_t set, uint64_t tag) {
    // Count distinct lines in the set that have been accessed more recently
    // than the line with `tag`.  This is a cheap approximation: we look at
    // the timestamps of all ways and count how many are newer.
    uint64_t ts_target = 0;
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (meta[set][w].last_access_ts && meta[set][w].last_access_ts == tag) {
            ts_target = meta[set][w].last_access_ts;
            break;
        }
    }
    if (ts_target == 0) return 0; // first time seen → treat as distance 0

    uint64_t dist = 0;
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (meta[set][w].last_access_ts > ts_target) ++dist;
    }
    return dist;
}

/*-----------------------------------------------------------------
   Helper: map stack distance to spectral bucket
-----------------------------------------------------------------*/
static uint32_t bucket_from_distance(uint64_t dist) {
    if (dist <= 2)  return 0;
    if (dist <= 4)  return 1;
    if (dist <= 8)  return 2;
    return 3;
}

/*-----------------------------------------------------------------
   Initialize replacement state
-----------------------------------------------------------------*/
void InitReplacementState() {
    // Zero all metadata structures
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        spectral[s].reset();
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            meta[s][w] = LineMeta(); // default‑constructed clears fields
        }
    }
    GLOBAL_ACCESS_COUNTER = 0;
    NEXT_EPOCH_TICK = EPOCH_LENGTH;
}

/*-----------------------------------------------------------------
   Choose victim line in the set
-----------------------------------------------------------------*/
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // 1) Compute set‑wide spectral bias term
    uint32_t long_range_hits = spectral[set].bucket[2] + spectral[set].bucket[3];
    uint32_t total_hits      = spectral[set].bucket[0] + spectral[set].bucket[1] +
                               spectral[set].bucket[2] + spectral[set].bucket[3];
    // bias = 0 (favor recency) when short‑range dominates, else 1
    uint32_t srd_bias = (total_hits == 0) ? 0 :
                        (long_range_hits * 100 / total_hits > 30) ? 1 : 0;

    // 2) Scan ways and compute eviction score
    uint32_t victim_way = 0;
    uint32_t max_score   = 0;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        const LineMeta &lm = meta[set][w];

        // Frequency term: higher freq → lower penalty
        uint32_t freq_term = MAX_FREQ - lm.freq;   // 0 … 255

        // Entropy term (scaled to 0‑255)
        uint32_t ent_term = static_cast<uint32_t>(lm.entropy * 255.0f);

        // Total score
        uint32_t score = ALPHA * srd_bias + BETA * freq_term + GAMMA * ent_term;

        if (score > max_score) {
            max_score   = score;
            victim_way  = w;
        }
    }

    return victim_way;
}

/*-----------------------------------------------------------------
   Update replacement state after an access (hit or miss)
-----------------------------------------------------------------*/
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Global tick
    ++GLOBAL_ACCESS_COUNTER;

    // Epoch handling: decay per‑line frequency counters
    if (GLOBAL_ACCESS_COUNTER >= NEXT_EPOCH_TICK) {
        for (uint32_t s = 0; s < LLC_SETS; ++s) {
            for (uint32_t w = 0; w < LLC_WAYS; ++w) {
                meta[s][w].freq >>= 1;               // simple right‑shift decay
            }
            spectral[s].reset();                     // start fresh histogram
        }
        NEXT_EPOCH_TICK += EPOCH_LENGTH;
    }

    // -----------------------------------------------------------------
    // 1) Update per‑line metadata (the line that is being accessed)
    // -----------------------------------------------------------------
    LineMeta &lm = meta[set][way];

    // Update frequency (saturating)
    if (lm.freq < MAX_FREQ) ++lm.freq;

    // Compute inter‑arrival gap
    uint64_t gap = GLOBAL_ACCESS_COUNTER - lm.last_access_ts;
    lm.gaps[lm.gap_idx] = static_cast<uint16_t>(std::min<uint64_t>(gap, 0xFFFF));
    lm.gap_idx = (lm.gap_idx + 1) % GAP_HISTORY;

    // Update entropy after we have at least two valid gaps
    lm.entropy = compute_entropy(lm.gaps);

    // -----------------------------------------------------------------
    // 2) Spectral histogram update (set‑wide)
    // -----------------------------------------------------------------
    // Approximate stack distance for this line:
    uint64_t stack_dist = estimate_stack_distance(set, paddr);
    uint32_t bucket = bucket_from_distance(stack_dist);
    ++spectral[set].bucket[bucket];

    // Store the new timestamp
    lm.last_access_ts = GLOBAL_ACCESS_COUNTER;
    lm.last_stack_dist = stack_dist;

    // -----------------------------------------------------------------
    // 3) If this was a miss, the victim line (if any) is being replaced.
    //    We simply reset its metadata so that it starts fresh.
    // -----------------------------------------------------------------
    if (!hit) {
        // The victim is the line we just wrote into (same way index)
        meta[set][way] = LineMeta();   // zero everything
        meta[set][way].last_access_ts = GLOBAL_ACCESS_COUNTER;
        // freq starts at 1 for the freshly inserted line
        meta[set][way].freq = 1;
        // gaps are zero‑initialized → entropy = 0
    }
}

/*-----------------------------------------------------------------
   Print end‑of‑simulation statistics (optional)
-----------------------------------------------------------------*/
void PrintStats() {
    // Example: overall histogram distribution
    uint64_t total = 0;
    uint64_t bucket_sum[4] = {0,0,0,0};

    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t b = 0; b < 4; ++b) {
            bucket_sum[b] += spectral[s].bucket[b];
            total += spectral[s].bucket[b];
        }
    }

    std::cout << "SRE Policy Statistics:\n";
    if (total) {
        for (uint32_t b = 0; b < 4; ++b) {
            std::cout << "  Spectral bucket " << b << ": "
                      << bucket_sum[b] << " (" 
                      << (100.0 * bucket_sum[b] / total) << "%)\n";
        }
    }
}

/*-----------------------------------------------------------------
   Periodic heartbeat statistics (optional)
-----------------------------------------------------------------*/
void PrintStats_Heartbeat() {
    // Could be used to dump per‑epoch entropy averages, etc.
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to track temporal and spatial locality metadata
typedef struct {
    uint64_t last_access;       // Temporal locality score (last access time)
    uint32_t spatial_count;     // Spatial locality score (number of neighboring lines in cache)
} tsar_metadata_t;

// Global metadata structure
std::vector<tsar_metadata_t> metadata(LLC_SETS * LLC_WAYS);

// Threshold to determine spatial vs. temporal prioritization (adjustable)
uint32_t spatial_threshold = 8;

void InitReplacementState() {
    // Initialize metadata for all cache lines
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            metadata[set * LLC_WAYS + way].last_access = 0;
            metadata[set * LLC_WAYS + way].spatial_count = 0;
        }
    }
}

uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint32_t min_score = UINT32_MAX;
    bool spatial_dominant = false;

    // Calculate total spatial locality in the set
    uint32_t total_spatial = 0;
    for (int i = 0; i < LLC_WAYS; i++) {
        total_spatial += metadata[set * LLC_WAYS + i].spatial_count;
    }
    
    // Determine if spatial locality should dominate
    if (total_spatial > spatial_threshold * LLC_WAYS) {
        spatial_dominant = true;
    }

    // Find victim based on spatial or temporal scores
    for (int i = 0; i < LLC_WAYS; i++) {
        uint32_t score;
        if (spatial_dominant) {
            score = metadata[set * LLC_WAYS + i].spatial_count;
        } else {
            score = (uint32_t)(metadata[set * LLC_WAYS + i].last_access);
        }

        if (score < min_score) {
            min_score = score;
            victim_way = i;
        }
    }

    return victim_way;
}

void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Update temporal locality score
        metadata[set * LLC_WAYS + way].last_access = PC;

        // Update spatial locality score
        // Count how many neighboring lines are in the cache
        uint32_t count = 0;
        uint64_t base = paddr & (~0x3F);  // Assume 64-byte cache lines
        for (int offset = -2; offset <= 2; offset++) {
            uint64_t addr = base + (offset * 64);
            for (int i = 0; i < LLC_WAYS; i++) {
                if (metadata[set * LLC_WAYS + i].spatial_count != 0 &&
                    (addr >> 6) == metadata[set * LLC_WAYS + i].spatial_count) {
                    count++;
                }
            }
        }
        metadata[set * LLC_WAYS + way].spatial_count = count;

        // Periodically adjust spatial threshold
        static uint64_t last_adjust = 0;
        if (PC - last_adjust > 1000000) {  // Adjust every 1M cycles
            uint32_t sum_spatial = 0;
            for (int i = 0; i < LLC_WAYS; i++) {
                sum_spatial += metadata[set * LLC_WAYS + i].spatial_count;
            }
            if (sum_spatial > spatial_threshold * LLC_WAYS * 2) {
                spatial_threshold *= 2;
            } else if (sum_spatial < spatial_threshold * LLC_WAYS / 2) {
                spatial_threshold /= 2;
            }
            last_adjust = PC;
        }
    }
}

void PrintStats() {
    uint32_t total_temporal = 0, total_spatial = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            total_temporal += metadata[set * LLC_WAYS + way].last_access;
            total_spatial += metadata[set * LLC_WAYS + way].spatial_count;
        }
    }
    std::cout << "Temporal Locality Total: " << total_temporal << std::endl;
    std::cout << "Spatial Locality Total: " << total_spatial << std::endl;
    std::cout << "Spatial Threshold: " << spatial_threshold << std::endl;
}

void PrintStats_Heartbeat() {
    static uint64_t last_count = 0;
    static uint64_t last_cycles = 0;
    uint64_t current_count = 0;
    uint64_t current_cycles = champsim_crc2_cycle_count;

    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            current_count += metadata[set * LLC_WAYS + way].spatial_count;
        }
    }

    std::cout << "Heartbeat Stats:" << std::endl;
    std::cout << "Spatial Count Delta: " << current_count - last_count << std::endl;
    std::cout << "Cycle Delta: " << current_cycles - last_cycles << std::endl;

    last_count = current_count;
    last_cycles = current_cycles;
}
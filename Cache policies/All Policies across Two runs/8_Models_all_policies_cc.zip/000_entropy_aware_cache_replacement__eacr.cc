#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to hold entropy information for a cache line
struct EntropyInfo {
    double entropyScore;
    uint64_t lastAccessPC;
    uint64_t accessCount;
};

std::vector<std::vector<EntropyInfo>> entropyMetadata(LLC_SETS, std::vector<EntropyInfo>(LLC_WAYS));

// Initialize replacement state
void InitReplacementState() {
    for (auto& set : entropyMetadata) {
        for (auto& line : set) {
            line.entropyScore = 0.0;
            line.lastAccessPC = 0;
            line.accessCount = 0;
        }
    }
}

// Calculate entropy score based on access pattern
double calculateEntropyScore(uint64_t currentPC, uint64_t lastAccessPC, uint64_t accessCount) {
    // Simple example; actual implementation could use more sophisticated entropy calculation
    if (accessCount == 0) return 0.0;
    double probability = 1.0 / accessCount;
    double entropy = -probability * log2(probability);
    if (currentPC == lastAccessPC) {
        entropy *= 0.8; // Reduce entropy for repeated access patterns
    }
    return entropy;
}

// Choose victim line in the set
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set, uint64_t PC, uint64_t paddr, uint32_t type) {
    double maxEntropy = -1.0;
    uint32_t victimWay = 0;
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        double currentEntropy = entropyMetadata[set][way].entropyScore;
        if (currentEntropy > maxEntropy) {
            maxEntropy = currentEntropy;
            victimWay = way;
        }
    }
    return victimWay;
}

// Update replacement state
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way, uint64_t paddr, uint64_t PC, uint64_t victim_addr, uint32_t type, uint8_t hit) {
    if (hit) {
        entropyMetadata[set][way].accessCount++;
        entropyMetadata[set][way].entropyScore = calculateEntropyScore(PC, entropyMetadata[set][way].lastAccessPC, entropyMetadata[set][way].accessCount);
        entropyMetadata[set][way].lastAccessPC = PC;
    } else {
        // Adjust entropy score upon miss
        entropyMetadata[set][way].entropyScore *= 1.1; // Increase entropy on miss
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistic: Average entropy score across all cache lines
    double totalEntropy = 0.0;
    uint32_t totalLines = LLC_SETS * LLC_WAYS;
    for (const auto& set : entropyMetadata) {
        for (const auto& line : set) {
            totalEntropy += line.entropyScore;
        }
    }
    double averageEntropy = totalEntropy / totalLines;
    std::cout << "Average Entropy Score: " << averageEntropy << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Could print average entropy or other stats periodically
}
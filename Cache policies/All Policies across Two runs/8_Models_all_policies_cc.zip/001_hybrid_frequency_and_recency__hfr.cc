#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structure for HFR
struct HFRMetadata {
    uint32_t frequency;
    uint64_t recency_timestamp;
};

// Array to store metadata for all cache lines
HFRMetadata hfr_metadata[LLC_SETS][LLC_WAYS];
uint64_t global_timestamp = 0; // Global timestamp to track recency

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; ++set) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            hfr_metadata[set][way].frequency = 0;
            hfr_metadata[set][way].recency_timestamp = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set, uint64_t PC, uint64_t paddr, uint32_t type) {
    uint32_t min_frequency = UINT32_MAX;
    uint32_t victim_way = 0;
    uint64_t min_recency = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        if (hfr_metadata[set][way].frequency < min_frequency) {
            min_frequency = hfr_metadata[set][way].frequency;
            victim_way = way;
            min_recency = hfr_metadata[set][way].recency_timestamp;
        } else if (hfr_metadata[set][way].frequency == min_frequency && hfr_metadata[set][way].recency_timestamp < min_recency) {
            victim_way = way;
            min_recency = hfr_metadata[set][way].recency_timestamp;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way, uint64_t paddr, uint64_t PC, uint64_t victim_addr, uint32_t type, uint8_t hit) {
    if (hit) {
        hfr_metadata[set][way].frequency++;
        hfr_metadata[set][way].recency_timestamp = ++global_timestamp;
    } else {
        // On a miss, the newly filled line's frequency is set to 1, and its recency is updated
        hfr_metadata[set][way].frequency = 1;
        hfr_metadata[set][way].recency_timestamp = ++global_timestamp;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optionally print final statistics, e.g., hit ratio, etc.
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optionally print periodic statistics
}
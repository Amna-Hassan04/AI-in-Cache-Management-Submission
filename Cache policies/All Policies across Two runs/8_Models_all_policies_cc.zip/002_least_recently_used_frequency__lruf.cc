#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Initialize replacement state
void InitReplacementState() {
    // Initialize frequency counters
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            replacement_state[set][way].freq = 0;
        }
    }
    // Initialize access time for each cache line
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            replacement_state[set][way].access_time = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (current_set[way].valid) {
            if (current_set[way].freq < replacement_state[set][victim_way].freq ||
                (current_set[way].freq == replacement_state[set][victim_way].freq &&
                 current_set[way].access_time > replacement_state[set][victim_way].access_time)) {
                victim_way = way;
            }
        }
    }
    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        replacement_state[set][way].freq++;
        replacement_state[set][way].access_time = PC;
    } else {
        replacement_state[set][way].freq = 0;
        replacement_state[set][way].access_time = 0;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Print average frequency and hit rate
    double total_freq = 0;
    double total_hits = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            if (replacement_state[set][way].freq > 0) {
                total_freq += replacement_state[set][way].freq;
                total_hits++;
            }
        }
    }
    std::cout << "Average Frequency: " << total_freq / (double)total_hits << std::endl;
    std::cout << "Hit Rate: " << total_hits / (double)(LLC_SETS * LLC_WAYS) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Print current average frequency and hit rate
    double total_freq = 0;
    double total_hits = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            if (replacement_state[set][way].freq > 0) {
                total_freq += replacement_state[set][way].freq;
                total_hits++;
            }
        }
    }
    std::cout << "Current Average Frequency: " << total_freq / (double)total_hits << std::endl;
    std::cout << "Current Hit Rate: " << total_hits / (double)(LLC_SETS * LLC_WAYS) << std::endl;
}
#include <vector>
#include <cstdint>
#include <algorithm>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
constexpr uint32_t QUANTUM_INTERVAL = 65536;   // cycles between heat-death events
static uint32_t last_quantum_cycle = 0;

// per-line 4-bit temperature (0=cold, 15=hot)
static std::vector<std::vector<uint8_t>> temp(LLC_SETS,
                              std::vector<uint8_t>(LLC_WAYS, 0));

// cheap popcount of trailing ones in physical page
static unsigned page_hotness(uint64_t pa) {
    return __builtin_ctzll(~(pa >> 6));
}

// Initialize replacement state
void InitReplacementState() {
    for (auto &vv : temp) std::fill(vv.begin(), vv.end(), 0);
    last_quantum_cycle = 0;
}

// Choose victim line in the set
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type) {
    uint32_t victim = 0;
    uint8_t  min_temp = temp[set][0];
    unsigned min_pg_hot = page_hotness(current_set[0].address);

    for (uint32_t w = 1; w < LLC_WAYS; ++w) {
        uint8_t t = temp[set][w];
        unsigned ph = page_hotness(current_set[w].address);
        if (t < min_temp || (t == min_temp && ph < min_pg_hot)) {
            min_temp = t;
            min_pg_hot = ph;
            victim = w;
        }
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                        uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                        uint32_t type, uint8_t hit) {
    // global heat-death epoch
    uint32_t now = get_current_cycle(cpu);   // ChampSim helper
    if (now - last_quantum_cycle >= QUANTUM_INTERVAL) {
        for (auto &vv : temp)
            for (auto &t : vv)
                if (t) --t;
        last_quantum_cycle = now;
    }

    // raise temperature of accessed line
    uint8_t &t = temp[set][way];
    if (t < 15) t += 2;
}

// Print end-of-simulation statistics
void PrintStats() {
    // no extra stats kept in this lightweight design
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // optional heartbeat left empty
}
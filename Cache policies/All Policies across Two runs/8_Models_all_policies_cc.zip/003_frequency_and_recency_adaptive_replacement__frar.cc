#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct BLOCK {
    uint64_t address;
    uint32_t access_count;
    uint64_t last_access_PC;
    // ... other necessary fields ...
};

// Initialize replacement state
void InitReplacementState() {
    // Assuming BLOCKs are initialized elsewhere with access_count = 0 and last_access_PC = 0
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;
    uint64_t min_score = UINT64_MAX;
    
    for (int i = 0; i < LLC_WAYS; i++) {
        const BLOCK *line = &current_set[i];
        if (line->valid) { // Assuming 'valid' field exists and is managed elsewhere
            uint64_t delta = PC - line->last_access_PC;
            // Calculate score as access_count divided by (delta + 1) to avoid division by zero
            uint64_t score = line->access_count * (0xFFFFFFFFFFFFFFFF / (delta + 1));
            
            if (score < min_score) {
                min_score = score;
                victim = i;
            }
        }
    }
    
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    BLOCK *current_line = &current_set[way];
    if (hit) {
        current_line->access_count++;
        current_line->last_access_PC = PC;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Optional: print total accesses, hit rates, etc.
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Optional: print periodic stats
}
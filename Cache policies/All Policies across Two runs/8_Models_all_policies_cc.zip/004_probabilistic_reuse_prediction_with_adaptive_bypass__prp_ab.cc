#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ------------------------------------------------------------------
   Configuration parameters (tune as needed)
   ------------------------------------------------------------------ */
constexpr uint32_t RPC_MAX            = 255;          // 8‑bit counter max
constexpr uint32_t RPC_INIT_HIT       = 64;           // initial value for “likely reuse”
constexpr uint32_t RPC_INIT_MISS      = 0;            // initial value for “unlikely reuse”
constexpr uint32_t PC_PRED_TABLE_SIZE = 1 << 12;      // 4K entries, 2‑bit each
constexpr uint32_t BYPASS_WINDOW      = 4096;         // accesses for miss‑rate window
constexpr double   BYPASS_MISS_THRESH = 0.30;         // 30 % miss‑rate threshold
constexpr uint64_t AGE_INTERVAL       = 1ULL << 20;   // age RPCs every 1M accesses

/* ------------------------------------------------------------------
   Global state
   ------------------------------------------------------------------ */
static uint8_t  rpc[LLC_SETS][LLC_WAYS];       // Reuse‑Probability Counter per line
static uint64_t last_used[LLC_SETS][LLC_WAYS]; // LRU timestamp per line

// Tiny PC predictor: 2‑bit saturating counters packed into a byte array
static uint8_t pc_predictor[PC_PRED_TABLE_SIZE];

// Statistics for adaptive bypass
static uint64_t global_tick      = 0;          // total accesses (including hits)
static uint64_t miss_window_ptr  = 0;          // index into circular miss window
static uint8_t  miss_window[BYPASS_WINDOW];  // 1 = miss, 0 = hit
static uint32_t window_miss_cnt  = 0;          // #misses in current window

/* ------------------------------------------------------------------
   Helper functions
   ------------------------------------------------------------------ */
inline uint32_t pc_hash(uint64_t pc) {
    // Simple XOR‑folded hash into table size
    return (pc ^ (pc >> 12)) & (PC_PRED_TABLE_SIZE - 1);
}

// Update the global miss‑rate window and return current miss‑rate
static double update_miss_window(bool miss) {
    // Remove oldest entry
    if (miss_window[miss_window_ptr])
        window_miss_cnt--;

    // Insert new outcome
    miss_window[miss_window_ptr] = miss ? 1 : 0;
    if (miss) window_miss_cnt++;

    // Advance pointer
    miss_window_ptr = (miss_window_ptr + 1) % BYPASS_WINDOW;

    return static_cast<double>(window_miss_cnt) / BYPASS_WINDOW;
}

/* ------------------------------------------------------------------
   Replacement policy entry points
   ------------------------------------------------------------------ */
void InitReplacementState() {
    // Zero‑initialize all structures
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            rpc[s][w]        = RPC_INIT_MISS;
            last_used[s][w]  = 0;
        }
    }

    for (uint32_t i = 0; i < PC_PRED_TABLE_SIZE; ++i)
        pc_predictor[i] = 0;   // start neutral (weakly “not reused”)

    // Initialise bypass window to all hits (optimistic start)
    for (uint32_t i = 0; i < BYPASS_WINDOW; ++i)
        miss_window[i] = 0;
    miss_window_ptr = 0;
    window_miss_cnt = 0;
    global_tick = 0;
}

/* Choose a victim line in the set */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type)
{
    // 1) Age RPCs periodically (global aging)
    if (global_tick % AGE_INTERVAL == 0 && global_tick != 0) {
        for (uint32_t s = 0; s < LLC_SETS; ++s) {
            for (uint32_t w = 0; w < LLC_WAYS; ++w) {
                rpc[s][w] >>= 1;   // halve probability (right‑shift)
            }
        }
    }

    // 2) Scan the set for the line with the smallest RPC
    uint32_t victim_way = 0;
    uint8_t  min_rpc    = rpc[set][0];
    uint64_t oldest_ts  = last_used[set][0];

    for (uint32_t w = 1; w < LLC_WAYS; ++w) {
        if (rpc[set][w] < min_rpc) {
            min_rpc    = rpc[set][w];
            victim_way = w;
            oldest_ts  = last_used[set][w];
        } else if (rpc[set][w] == min_rpc) {
            // Tie‑break with LRU (older timestamp wins)
            if (last_used[set][w] < oldest_ts) {
                victim_way = w;
                oldest_ts  = last_used[set][w];
            }
        }
    }
    return victim_way;
}

/* Update replacement state after every access */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit)
{
    ++global_tick;

    // ----------------------------------------------------------------
    // 1) Adaptive bypass decision (executed only on misses)
    // ----------------------------------------------------------------
    bool will_bypass = false;
    if (!hit) {
        double cur_miss_rate = update_miss_window(true);
        if (cur_miss_rate > BYPASS_MISS_THRESH)
            will_bypass = true;
    } else {
        // hit → update window with 0 (hit)
        update_miss_window(false);
    }

    // ----------------------------------------------------------------
    // 2) If bypassed, we do NOT allocate a line → nothing to update.
    // ----------------------------------------------------------------
    if (!hit && will_bypass) {
        // No insertion, no RPC update for the would‑be line.
        return;
    }

    // ----------------------------------------------------------------
    // 3) On a hit → boost the line's RPC and refresh LRU timestamp.
    // ----------------------------------------------------------------
    if (hit) {
        // Saturating increment
        if (rpc[set][way] < RPC_MAX)
            rpc[set][way] += 8;   // step size can be tuned

        last_used[set][way] = global_tick;
        return;
    }

    // ----------------------------------------------------------------
    // 4) On a miss (and not bypassed) → we are inserting a new line.
    //    a) Determine initial RPC from PC predictor.
    //    b) Insert at MRU or LRU depending on predictor confidence.
    // ----------------------------------------------------------------
    uint32_t pc_idx = pc_hash(PC);
    uint8_t pred = pc_predictor[pc_idx] & 0x3; // 2‑bit counter

    // Translate 2‑bit predictor to an initial RPC value
    uint8_t init_rpc;
    if (pred == 0)        init_rpc = RPC_INIT_MISS;      // “never reuse”
    else if (pred == 1)   init_rpc = RPC_INIT_MISS + 16; // weak reuse
    else if (pred == 2)   init_rpc = RPC_INIT_HIT;       // likely reuse
    else                  init_rpc = RPC_MAX;           // very likely

    rpc[set][way] = init_rpc;
    last_used[set][way] = global_tick;

    // ----------------------------------------------------------------
    // 5) Update the PC predictor based on the outcome we just observed.
    //    If the inserted line is later hit before eviction → we’ll
    //    increment the predictor; otherwise decrement on eviction.
    // ----------------------------------------------------------------
    // For simplicity we update on insertion (optimistic) and on
    // eviction (handled in GetVictimInSet via the victim_addr argument).
    // Here we only record that we inserted; the actual increment/decrement
    // will be performed when the line is evicted (see below).
    // We'll store the PC tag in the BLOCK's tag field for later use.
    // Note: ChampSim's BLOCK already contains `address` and `cpu`, but we
    // reuse its `address` as a place to stash the PC hash for later lookup.
    // This is a lightweight hack – in a full implementation a side table
    // would be cleaner.
    ((BLOCK *)victim_addr)->address = pc_idx; // store predictor index
}

/* ---------------------------------------------------------------
   Optional: hook called when a line is actually evicted.
   ChampSim calls UpdateReplacementState with the *victim* address
   after GetVictimInSet has been selected. We use that opportunity to
   decay the PC predictor.
   --------------------------------------------------------------- */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit); // forward declaration to avoid duplicate definition

/* Real eviction hook – called after the victim line has been chosen
   and before it is overwritten. */
void EvictLineHook(uint32_t set, uint32_t way) {
    // Retrieve the stored PC predictor index
    uint32_t stored_idx = static_cast<uint32_t>(((BLOCK *)victim_addr)->address);
    if (stored_idx >= PC_PRED_TABLE_SIZE) return; // safety

    // The line was evicted without a hit ⇒ penalize the predictor
    uint8_t &cnt = pc_predictor[stored_idx];
    if (cnt > 0) cnt--;   // saturating decrement
}

/* ---------------------------------------------------------------
   Print final statistics (optional)
   --------------------------------------------------------------- */
void PrintStats() {
    std::cout << "PRP-AB statistics:\n";
    std::cout << "  Total accesses          : " << global_tick << "\n";
    std::cout << "  Final miss‑rate window  : "
              << static_cast<double>(window_miss_cnt) / BYPASS_WINDOW << "\n";
}

/* ---------------------------------------------------------------
   Periodic heartbeat (optional)
   --------------------------------------------------------------- */
void PrintStats_Heartbeat() {
    // Example: every 10M accesses (ChampSim calls this periodically)
    std::cout << "[PRP-AB] Tick=" << global_tick
              << " miss_rate=" << static_cast<double>(window_miss_cnt) / BYPASS_WINDOW
              << "\n";
}
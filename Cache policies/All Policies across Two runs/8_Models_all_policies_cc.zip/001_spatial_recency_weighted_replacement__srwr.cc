#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ------------------------------------------------------------------
 *  Metadata
 * ------------------------------------------------------------------ */
// Frequency counter (8‑bit, saturates at 255)
static uint8_t  freq[LLC_SETS][LLC_WAYS];
// Recency stack (4‑bit LRU counter, 0 = MRU, 15 = LRU)
static uint8_t  rec[LLC_SETS][LLC_WAYS];
// Last physical address accessed by each line
static uint32_t last_addr[LLC_SETS][LLC_WAYS];

// Tunable parameters
static constexpr uint8_t  FREQ_W = 1;          // frequency weight
static constexpr uint8_t  REC_W  = 1;          // recency weight
static constexpr uint8_t  DIST_W = 1;          // distance weight
static constexpr uint8_t  DIST_SHIFT = 12;     // shift to reduce distance magnitude

/* ------------------------------------------------------------------
 *  Initialisation
 * ------------------------------------------------------------------ */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            freq[s][w]     = 0;
            rec[s][w]      = 0;
            last_addr[s][w] = 0;
        }
    }
}

/* ------------------------------------------------------------------
 *  Victim selection
 * ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    (void)cpu; (void)PC; (void)type;  // unused in this policy

    uint32_t victim = 0;
    uint64_t max_value = 0;

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        // absolute spatial distance between current access and last access
        uint32_t distance = (paddr > last_addr[set][w]) ?
                            (paddr - last_addr[set][w]) :
                            (last_addr[set][w] - paddr);

        // shift distance to keep numbers reasonable
        uint32_t dist_score = distance >> DIST_SHIFT;

        // compute the "value" – higher means less desirable to keep
        uint64_t value =
            (uint64_t)FREQ_W * freq[set][w] +
            (uint64_t)REC_W  * rec[set][w]  +
            (uint64_t)DIST_W * dist_score;

        if (value > max_value) {
            max_value = value;
            victim = w;
        }
    }
    return victim;
}

/* ------------------------------------------------------------------
 *  Replacement state update
 * ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    (void)cpu; (void)PC; (void)type; (void)victim_addr;  // unused

    // 1) Update frequency counter (saturating)
    if (freq[set][way] < 255) freq[set][way]++;

    // 2) Update recency stack
    //   The accessed way becomes MRU (rec=0); all others get rec+1
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (w == way) {
            rec[set][w] = 0;
        } else if (rec[set][w] < 15) {
            rec[set][w]++;      // older lines move toward LRU
        }
    }

    // 3) Update last address
    last_addr[set][way] = static_cast<uint32_t>(paddr);
}

/* ------------------------------------------------------------------
 *  Statistics
 * ------------------------------------------------------------------ */
void PrintStats() {
    // Optional: report average frequency or other metrics
    double total_freq = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            total_freq += freq[s][w];
    std::cout << "[SRWR] Avg line frequency: "
              << total_freq / (LLC_SETS * LLC_WAYS) << std::endl;
}

void PrintStats_Heartbeat() {
    // Optional periodic stats can be added here
}
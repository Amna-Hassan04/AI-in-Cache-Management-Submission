#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ------------------------------------------------------------------
   Per‑line metadata
   ------------------------------------------------------------------ */
struct CWLRUInfo {
    uint8_t  confidence;          // 0 … 255  (higher = more trusted)
    uint64_t last_access_ts;      // monotonically increasing timestamp
};

static CWLRUInfo replacement_state[LLC_SETS][LLC_WAYS];
static uint64_t global_timestamp = 0;

/* ------------------------------------------------------------------
   Initialise the replacement structures
   ------------------------------------------------------------------ */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            replacement_state[s][w].confidence   = 0;
            replacement_state[s][w].last_access_ts = 0;
        }
}

/* ------------------------------------------------------------------
   Choose a victim line in a set
   ------------------------------------------------------------------ */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type)
{
    // Scan the ways looking for the smallest confidence.
    // If several have the same confidence, pick the oldest (largest ts).
    uint32_t victim_way = 0;
    uint8_t  min_conf   = 255;
    uint64_t oldest_ts  = 0;   // larger = older (because timestamp always grows)

    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        uint8_t  conf = replacement_state[set][w].confidence;
        uint64_t ts   = replacement_state[set][w].last_access_ts;

        if (conf < min_conf) {
            min_conf   = conf;
            oldest_ts  = ts;
            victim_way = w;
        } else if (conf == min_conf && ts > oldest_ts) {
            // same confidence → pick the older line
            oldest_ts  = ts;
            victim_way = w;
        }
    }
    return victim_way;
}

/* ------------------------------------------------------------------
   Update replacement state after every access (hit or miss)
   ------------------------------------------------------------------ */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit)
{
    // Global time advances on *every* LLC access
    ++global_timestamp;

    // Decay confidence of *all* lines in the set (simple leaky bucket)
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        // Multiply by 7/8 ≈ 0.875, keep integer arithmetic
        replacement_state[set][w].confidence =
            (replacement_state[set][w].confidence * 7) >> 3;
    }

    if (hit) {
        // On a hit we boost confidence (saturating at 255)
        uint8_t &c = replacement_state[set][way].confidence;
        if (c < 255) ++c;
        replacement_state[set][way].last_access_ts = global_timestamp;
    } else {
        // Miss → we just inserted a new line in 'way'
        replacement_state[set][way].confidence   = 0;            // start with no confidence
        replacement_state[set][way].last_access_ts = global_timestamp;
    }
}

/* ------------------------------------------------------------------
   Optional: print final statistics
   ------------------------------------------------------------------ */
void PrintStats() {
    // Example: average confidence over the whole LLC
    uint64_t sum_conf = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w)
            sum_conf += replacement_state[s][w].confidence;

    double avg_conf = double(sum_conf) /
                      double(LLC_SETS * LLC_WAYS);
    std::cout << "CW-LRU: average confidence = " << avg_conf << "\n";
}

/* ------------------------------------------------------------------
   Optional: periodic heartbeat statistics
   ------------------------------------------------------------------ */
void PrintStats_Heartbeat() {
    // No periodic stats required for this simple policy
}
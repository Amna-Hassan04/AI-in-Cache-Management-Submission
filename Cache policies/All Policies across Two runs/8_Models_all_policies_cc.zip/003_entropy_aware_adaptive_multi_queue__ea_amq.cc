#include <vector>
#include <cstdint>
#include <iostream>
#include <cstring>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/* ---------- Configuration ---------- */
constexpr uint32_t NUM_QUEUES      = 4;          // maximum logical queues
constexpr uint32_t ENTROPY_WINDOW = 32;         // number of recent PCs per set
constexpr uint32_t PC_MASK        = 0xFFF;      // low bits of PC to hash into histogram

/* ---------- Per‑line metadata ---------- */
struct LineInfo {
    uint8_t  queue_id;          // which logical queue (0 … NUM_QUEUES‑1)
    uint16_t age_counter;      // hits accumulated while resident
    uint64_t last_access_time; // for LRU ordering inside a queue
};

/* ---------- Per‑set metadata ---------- */
struct SetInfo {
    // LRU order per queue: we keep a simple linked list via way indices.
    // head[ q ] = most‑recently used way in queue q
    // tail[ q ] = least‑recently used way in queue q (candidate for victim)
    int8_t   head[NUM_QUEUES];
    int8_t   tail[NUM_QUEUES];

    // Entropy tracking
    uint32_t pc_hist[ENTROPY_WINDOW]; // circular buffer of recent PC hashes
    uint32_t pc_hist_idx;
    uint32_t pc_hist_cnt[1 << 12];    // histogram for low‑12‑bit PC values

    // Adaptive thresholds
    uint16_t promote_thresh;  // hits needed to promote one level
    uint16_t demote_thresh;   // accesses without hit to demote one level

    // Active queue count (1 … NUM_QUEUES). Determined from entropy.
    uint8_t  active_queues;
};

/* ---------- Global state ---------- */
static LineInfo  line_info[LLC_SETS][LLC_WAYS];
static SetInfo   set_info[LLC_SETS];

/* ---------- Helper functions ---------- */
static inline double compute_shannon_entropy(const SetInfo &s) {
    double ent = 0.0;
    uint32_t total = 0;
    for (uint32_t i = 0; i < (1 << 12); ++i) total += s.pc_hist_cnt[i];
    if (total == 0) return 0.0;
    for (uint32_t i = 0; i < (1 << 12); ++i) {
        if (s.pc_hist_cnt[i] == 0) continue;
        double p = (double)s.pc_hist_cnt[i] / (double)total;
        ent -= p * log2(p);
    }
    return ent;
}

/* Adjust active queue count and thresholds based on entropy */
static void adapt_set_parameters(uint32_t set) {
    SetInfo &s = set_info[set];
    double ent = compute_shannon_entropy(s);
    // Entropy is in [0, 12] bits for 12‑bit PC histogram.
    // Map it to a small integer: low entropy -> 4 active queues, high -> 2.
    if (ent < 3.0) {
        s.active_queues = 4;
        s.promote_thresh = 2;   // aggressive promotion
        s.demote_thresh  = 8;   // reluctant demotion
    } else if (ent < 6.0) {
        s.active_queues = 3;
        s.promote_thresh = 4;
        s.demote_thresh  = 6;
    } else {
        s.active_queues = 2;    // behave more like LRU
        s.promote_thresh = 6;
        s.demote_thresh  = 4;
    }
}

/* Move a way to the head of its queue (MRU) */
static void touch_way(uint32_t set, uint32_t way) {
    SetInfo &s = set_info[set];
    uint8_t q = line_info[set][way].queue_id;

    // If already MRU, nothing to do
    if (s.head[q] == (int8_t)way) return;

    // Unlink from current position
    int8_t prev = -1, next = -1;
    // Find predecessor
    for (int8_t w = s.head[q]; w != -1; w = line_info[set][w].last_access_time) {
        if (line_info[set][w].last_access_time == way) { prev = w; break; }
    }
    // Actually we store only head/tail, so we need a simple linear scan:
    // (LLC_WAYS is tiny, acceptable)
    int8_t pred = -1;
    for (int8_t w = s.head[q]; w != -1; w = line_info[set][w].last_access_time) {
        if (line_info[set][w].last_access_time == way) { pred = w; break; }
    }
    // Remove `way` from its current spot
    int8_t cur = s.head[q];
    int8_t prev_way = -1;
    while (cur != -1 && cur != (int8_t)way) {
        prev_way = cur;
        cur = (int8_t)line_info[set][cur].last_access_time;
    }
    if (cur == -1) return; // should not happen
    int8_t next_way = (int8_t)line_info[set][cur].last_access_time;
    if (prev_way != -1)
        line_info[set][prev_way].last_access_time = (uint64_t)next_way;
    else
        s.head[q] = next_way; // removed head
    if (next_way == -1)
        s.tail[q] = prev_way; // removed tail

    // Insert at head
    line_info[set][way].last_access_time = (uint64_t)s.head[q];
    s.head[q] = (int8_t)way;
    if (s.tail[q] == -1) s.tail[q] = (int8_t)way;
}

/* Insert a new line into the coldest active queue */
static void insert_new_line(uint32_t set, uint32_t way) {
    SetInfo &s = set_info[set];
    uint8_t cold_q = 0;                     // Q0 is always active
    line_info[set][way].queue_id = cold_q;
    line_info[set][way].age_counter = 0;
    line_info[set][way].last_access_time = (uint64_t)s.head[cold_q];
    s.head[cold_q] = (int8_t)way;
    if (s.tail[cold_q] == -1) s.tail[cold_q] = (int8_t)way;
}

/* ---------- Required entry points ---------- */
void InitReplacementState() {
    // Clear all metadata
    for (uint32_t set = 0; set < LLC_SETS; ++set) {
        for (uint32_t way = 0; way < LLC_WAYS; ++way) {
            line_info[set][way].queue_id = 0;
            line_info[set][way].age_counter = 0;
            line_info[set][way].last_access_time = 0;
        }
        SetInfo &s = set_info[set];
        std::memset(s.head, -1, sizeof(s.head));
        std::memset(s.tail, -1, sizeof(s.tail));
        std::memset(s.pc_hist, 0, sizeof(s.pc_hist));
        s.pc_hist_idx = 0;
        std::memset(s.pc_hist_cnt, 0, sizeof(s.pc_hist_cnt));
        s.promote_thresh = 4;
        s.demote_thresh  = 6;
        s.active_queues  = NUM_QUEUES;
    }
}

/* Choose victim line in the set */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // First, adapt the set based on entropy (periodic, cheap)
    adapt_set_parameters(set);
    SetInfo &s = set_info[set];

    // Scan queues from coldest to hottest, but only up to active_queues
    for (int q = 0; q < s.active_queues; ++q) {
        int8_t victim = s.tail[q];
        if (victim != -1) {
            // If the line is invalid we can take it immediately
            if (current_set[victim].valid == 0) return victim;
            // Otherwise we still prefer it (LRU within that queue)
            return victim;
        }
    }
    // Fallback: all queues empty? Should not happen, return way 0.
    return 0;
}

/* Update replacement state after an access */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    SetInfo &s = set_info[set];
    LineInfo &line = line_info[set][way];

    // ---------- Update PC histogram (entropy tracking) ----------
    uint32_t pc_hash = (uint32_t)(PC) & PC_MASK;
    uint32_t old_pc = s.pc_hist[s.pc_hist_idx];
    // Decrement old entry
    s.pc_hist_cnt[old_pc]--;
    // Insert new PC
    s.pc_hist[s.pc_hist_idx] = pc_hash;
    s.pc_hist_cnt[pc_hash]++;

    s.pc_hist_idx = (s.pc_hist_idx + 1) % ENTROPY_WINDOW;

    // ---------- Replacement logic ----------
    if (hit) {
        // Increment age and possibly promote
        line.age_counter++;

        // Promotion test
        if (line.age_counter >= s.promote_thresh) {
            uint8_t cur_q = line.queue_id;
            uint8_t max_q = s.active_queues - 1; // hottest active queue index
            if (cur_q < max_q) {
                // Remove from current queue list
                // (same unlink logic as in touch_way – simplified by re‑using touch)
                // First, unlink
                int8_t prev = -1, cur = s.head[cur_q];
                while (cur != -1 && cur != (int8_t)way) {
                    prev = cur;
                    cur = (int8_t)line_info[set][cur].last_access_time;
                }
                if (cur != -1) {
                    int8_t nxt = (int8_t)line_info[set][cur].last_access_time;
                    if (prev != -1)
                        line_info[set][prev].last_access_time = (uint64_t)nxt;
                    else
                        s.head[cur_q] = nxt;          // removed head
                    if (nxt == -1) s.tail[cur_q] = prev; // removed tail
                }

                // Promote
                line.queue_id = cur_q + 1;
                line.age_counter = 0; // reset counter in new queue

                // Insert at head of hotter queue
                line.last_access_time = (uint64_t)s.head[line.queue_id];
                s.head[line.queue_id] = (int8_t)way;
                if (s.tail[line.queue_id] == -1) s.tail[line.queue_id] = (int8_t)way;
            }
        }

        // Refresh LRU position inside its queue
        touch_way(set, way);
    } else {
        // Miss – the line that just filled the cache is a brand‑new entry.
        // The simulator already called GetVictimInSet and possibly evicted a line.
        // We now initialise the metadata for the *new* line that occupies `way`.
        insert_new_line(set, way);
    }
}

/* Print end‑of‑simulation statistics */
void PrintStats() {
    // Example: average entropy per set
    double total_ent = 0.0;
    for (uint32_t set = 0; set < LLC_SETS; ++set)
        total_ent += compute_shannon_entropy(set_info[set]);
    double avg_ent = total_ent / LLC_SETS;
    std::cout << "EA‑AMQ: average per‑set entropy = " << avg_ent << " bits\n";
}

/* Periodic heartbeat (optional) */
void PrintStats_Heartbeat() {
    // No periodic stats needed for this policy
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

uint32_t hit_counts[LLC_SETS][LLC_WAYS];  // Tracks frequency of hits for each line
uint64_t last_access_times[LLC_SETS][LLC_WAYS];  // Tracks last access time for each line

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            hit_counts[set][way] = 0;
            last_access_times[set][way] = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;
    uint32_t min_count = UINT32_MAX;
    uint64_t oldest_time = 0;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint32_t current_count = hit_counts[set][way];
        uint64_t current_time = last_access_times[set][way];

        if (current_count < min_count || (current_count == min_count && current_time < oldest_time)) {
            min_count = current_count;
            oldest_time = current_time;
            victim = way;
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        hit_counts[set][way]++;
        last_access_times[set][way] = PC;
    } else {
        // On a miss, if this is a new line being inserted
        hit_counts[set][way] = 1;
        last_access_times[set][way] = PC;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example: Print total hits and average access time
    uint64_t total_hits = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            total_hits += hit_counts[set][way];
        }
    }
    std::cout << "Total cache hits: " << total_hits << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: Print periodic hit count statistics
    std::cout << "Current hit counts: ";
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            std::cout << hit_counts[set][way] << " ";
        }
    }
    std::cout << std::endl;
}
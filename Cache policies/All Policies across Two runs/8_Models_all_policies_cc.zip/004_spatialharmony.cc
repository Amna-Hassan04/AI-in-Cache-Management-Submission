#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define CLUSTER_SIZE 256  // Adjust based on memory address space

// Structure to track metadata for each cache line
struct CacheLineMetadata {
    uint64_t cluster;      // Cluster number based on address
    uint64_t last_access;  // Timestamp of last access
};

// Initialize replacement state
void InitReplacementState() {
    // Allocate metadata for each cache line
    metadata.resize(LLC_SETS * LLC_WAYS);
    cluster_sizes.resize(CLUSTER_SIZE, 0);
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim = 0;
    uint32_t min_cluster_size = UINT32_MAX;
    uint64_t oldest_access = 0;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t cluster = metadata[set * LLC_WAYS + way].cluster;
        uint32_t current_cluster_size = cluster_sizes[cluster];
        uint64_t last_access = metadata[set * LLC_WAYS + way].last_access;

        if (current_cluster_size < min_cluster_size || 
            (current_cluster_size == min_cluster_size && last_access < oldest_access)) {
            min_cluster_size = current_cluster_size;
            oldest_access = last_access;
            victim = way;
        }
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    uint64_t cluster = paddr % CLUSTER_SIZE;
    metadata[set * LLC_WAYS + way].cluster = cluster;
    metadata[set * LLC_WAYS + way].last_access = __builtin_ia32_rdtsc();
    cluster_sizes[cluster]++;
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistic: print cluster sizes
    for (uint32_t i = 0; i < CLUSTER_SIZE; i++) {
        std::cout << "Cluster " << i << " size: " << cluster_sizes[i] << std::endl;
    }
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: print the current cluster distribution every heartbeat
    std::cout << "Cluster sizes: ";
    for (uint32_t i = 0; i < CLUSTER_SIZE; i++) {
        std::cout << cluster_sizes[i] << " ";
    }
    std::cout << std::endl;
}

// Global metadata storage
std::vector<CacheLineMetadata> metadata;
std::vector<uint32_t> cluster_sizes;
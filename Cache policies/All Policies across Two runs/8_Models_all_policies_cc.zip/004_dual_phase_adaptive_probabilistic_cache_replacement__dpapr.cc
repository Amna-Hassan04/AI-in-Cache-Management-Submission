#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to store per-set metadata
struct DPAPRMetadata {
  std::vector<double> probabilityTable; // probability table for each line
  uint32_t phaseCounter; // counter for phase detection
  double phaseMissRate; // cache miss rate during current phase
};

// Initialize replacement state
void InitReplacementState() {
  for (uint32_t set = 0; set < LLC_SETS; set++) {
    DPAPRMetadata& metadata = *(DPAPRMetadata*)malloc(sizeof(DPAPRMetadata));
    metadata.probabilityTable.resize(LLC_WAYS, 0.0);
    metadata.phaseCounter = 0;
    metadata.phaseMissRate = 0.0;
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
  uint32_t cpu,
  uint32_t set,
  const BLOCK *current_set,
  uint64_t PC,
  uint64_t paddr,
  uint32_t type
) {
  DPAPRMetadata& metadata = *(DPAPRMetadata*)get_metadata(set);
  uint32_t victim = 0;
  double minProbability = 1.0;

  // Find the line with the lowest probability
  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    if (metadata.probabilityTable[way] < minProbability) {
      minProbability = metadata.probabilityTable[way];
      victim = way;
    }
  }

  return victim;
}

// Update replacement state
void UpdateReplacementState(
  uint32_t cpu,
  uint32_t set,
  uint32_t way,
  uint64_t paddr,
  uint64_t PC,
  uint64_t victim_addr,
  uint32_t type,
  uint8_t hit
) {
  DPAPRMetadata& metadata = *(DPAPRMetadata*)get_metadata(set);

  // Update probability table
  if (hit) {
    metadata.probabilityTable[way] = std::min(1.0, metadata.probabilityTable[way] + 0.1);
  } else {
    metadata.probabilityTable[way] = std::max(0.0, metadata.probabilityTable[way] - 0.1);
  }

  // Phase detection
  metadata.phaseCounter++;
  if (metadata.phaseCounter >= 1000) { // adjust phase detection interval
    metadata.phaseMissRate = get_miss_rate(set);
    if (metadata.phaseMissRate > 0.1) { // adjust phase detection threshold
      // Phase transition detected, reset probability table
      for (uint32_t i = 0; i < LLC_WAYS; i++) {
        metadata.probabilityTable[i] = 0.0;
      }
    }
    metadata.phaseCounter = 0;
  }
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print overall cache hit rate
  std::cout << "Cache Hit Rate: " << get_hit_rate() << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print current cache miss rate
  std::cout << "Cache Miss Rate: " << get_miss_rate() << std::endl;
}
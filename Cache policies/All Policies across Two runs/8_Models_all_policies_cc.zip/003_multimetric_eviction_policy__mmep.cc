#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to store metadata for each cache line
struct CacheMetadata {
    uint64_t last_access;   // Timestamp of last access
    uint64_t access_count; // Number of times the block has been accessed
    uint64_t lifetime;     // Time spent in the cache
};

// Initialize metadata for all cache lines
void InitReplacementState() {
    // Allocate metadata for all sets and ways
    metadata.resize(LLC_SETS);
    for (auto& set : metadata) {
        set.resize(LLC_WAYS);
        for (auto& way : set) {
            way.last_access = 0;
            way.access_count = 0;
            way.lifetime = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;

    // Weighing factors for the metrics (adjust as needed)
    const double recency_weight = 0.5;
    const double frequency_weight = 0.3;
    const double lifetime_weight = 0.2;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        const CacheMetadata& meta = metadata[set][way];
        
        // Calculate the composite score
        uint64_t score = static_cast<uint64_t>(recency_weight * meta.last_access +
                                                 frequency_weight * meta.access_count +
                                                 lifetime_weight * meta.lifetime);

        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Update metadata for the accessed block
        metadata[set][way].last_access = PC;
        metadata[set][way].access_count++;
    } else {
        // Initialize metadata for the new block
        metadata[set][way].last_access = PC;
        metadata[set][way].access_count = 1;
        metadata[set][way].lifetime = PC;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    uint64_t total_access = 0;
    uint64_t total_lifetime = 0;

    for (const auto& set : metadata) {
        for (const auto& way : set) {
            total_access += way.access_count;
            total_lifetime += way.lifetime;
        }
    }

    std::cout << "Total accesses: " << total_access << std::endl;
    std::cout << "Average lifetime: " << total_lifetime / (LLC_SETS * LLC_WAYS) << std::endl;
}

// Optional: Print periodic statistics
void PrintStats_Heartbeat() {
    // Example: Print average access count per block
    uint64_t avg_access = 0;
    for (const auto& set : metadata) {
        for (const auto& way : set) {
            avg_access += way.access_count;
        }
    }
    avg_access /= (LLC_SETS * LLC_WAYS);
    std::cout << "Average accesses per block: " << avg_access << std::endl;
}

// Metadata storage for all cache lines
std::vector<std::vector<CacheMetadata>> metadata;
#include <vector>
#include <cstdint>
#include <iostream>
#include <tuple>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

struct t_falru_metadata {
    uint64_t last_access_time;  // Timestamp of last access
    uint64_t access_frequency; // Total number of accesses
    uint64_t last_temporal_distance;  // Time since previous access
    uint8_t is_recently_used : 1;   // Hysteresis flag for stabilization
};

std::vector<std::vector<t_falru_metadata>> metadata;
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    metadata.resize(NUM_CORE);
    for (auto& core : metadata) {
        core.resize(LLC_SETS, std::vector<t_falru_metadata>(LLC_WAYS));
    }
    global_timestamp = 0;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    const auto& candidates = metadata[cpu][set];
    uint32_t victim = 0;
    uint64_t min_score = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (current_set[way].valid) {
            // Calculate victim score based on:
            // - Temporal distance (lower is better)
            // - Access frequency (lower is better)
            // - Recency of last access (higher recency penalty)
            uint64_t current_temporal_distance = global_timestamp - candidates[way].last_access_time;
            uint64_t score = (current_temporal_distance << 32) | 
                            (candidates[way].access_frequency << 16) | 
                            (global_timestamp - candidates[way].last_access_time);

            if (score < min_score) {
                min_score = score;
                victim = way;
            }
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        auto& meta = metadata[cpu][set][way];
        meta.access_frequency++;
        
        uint64_t current_temporal_distance = global_timestamp - meta.last_access_time;
        meta.last_temporal_distance = current_temporal_distance;
        
        meta.last_access_time = global_timestamp;
        
        // Update hysteresis flag
        if (current_temporal_distance < (global_timestamp / 1000)) { // Arbitrary threshold
            meta.is_recently_used = 1;
        } else {
            meta.is_recently_used = 0;
        }
    }
    global_timestamp++;
}

// Print end-of-simulation statistics
void PrintStats() {
    uint64_t total_access_frequency = 0;
    uint64_t total_temporal_distance = 0;
    uint64_t count = 0;
    
    for (const auto& core : metadata) {
        for (const auto& set : core) {
            for (const auto& meta : set) {
                if (meta.access_frequency > 0) {
                    total_access_frequency += meta.access_frequency;
                    total_temporal_distance += meta.last_temporal_distance;
                    count++;
                }
            }
        }
    }

    std::cout << "T-FALRU Statistics:" << std::endl;
    std::cout << "Average Access Frequency: " << (total_access_frequency / count) << std::endl;
    std::cout << "Average Temporal Distance: " << (total_temporal_distance / count) << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    uint64_t current_timestamp = global_timestamp;
    std::cout << "Heartbeat @ timestamp " << current_timestamp << std::endl;
}
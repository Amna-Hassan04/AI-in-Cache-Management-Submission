#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to hold Temporal Locality Tracker (TLT) metadata
struct TLTEntry {
  uint32_t last_access_time;
  uint32_t access_count;
};

// Structure to hold Spatial Locality Profiler (SLP) metadata
struct SLPEntry {
  uint32_t spatial_pattern;
};

// Structure to hold Reuse Propensity Score (RPS) metadata
struct RPSEntry {
  float score;
};

// Initialize replacement state
void InitReplacementState() {
  // Initialize TLT metadata
  static std::vector<TLTEntry> tlt_metadata(LLC_SETS * LLC_WAYS);
  for (auto& entry : tlt_metadata) {
    entry.last_access_time = 0;
    entry.access_count = 0;
  }

  // Initialize SLP metadata
  static std::vector<SLPEntry> slp_metadata(LLC_SETS * LLC_WAYS);
  for (auto& entry : slp_metadata) {
    entry.spatial_pattern = 0;
  }

  // Initialize RPS metadata
  static std::vector<RPSEntry> rps_metadata(LLC_SETS * LLC_WAYS);
  for (auto& entry : rps_metadata) {
    entry.score = 0.0f;
  }
}

// Choose victim line in the set
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set, uint64_t PC, uint64_t paddr, uint32_t type) {
  static std::vector<TLTEntry> tlt_metadata(LLC_SETS * LLC_WAYS);
  static std::vector<SLPEntry> slp_metadata(LLC_SETS * LLC_WAYS);
  static std::vector<RPSEntry> rps_metadata(LLC_SETS * LLC_WAYS);

  uint32_t victim_way = 0;
  float min_rps = 1.0f; // Initialize with a value greater than any possible RPS

  for (uint32_t way = 0; way < LLC_WAYS; way++) {
    uint32_t index = set * LLC_WAYS + way;
    TLTEntry& tlt_entry = tlt_metadata[index];
    SLPEntry& slp_entry = slp_metadata[index];
    RPSEntry& rps_entry = rps_metadata[index];

    // Compute Reuse Propensity Score (RPS)
    rps_entry.score = (tlt_entry.access_count * 0.3f) + (slp_entry.spatial_pattern * 0.7f);

    if (rps_entry.score < min_rps) {
      min_rps = rps_entry.score;
      victim_way = way;
    }
  }

  return victim_way;
}

// Update replacement state
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way, uint64_t paddr, uint64_t PC, uint64_t victim_addr, uint32_t type, uint8_t hit) {
  static std::vector<TLTEntry> tlt_metadata(LLC_SETS * LLC_WAYS);
  static std::vector<SLPEntry> slp_metadata(LLC_SETS * LLC_WAYS);

  uint32_t index = set * LLC_WAYS + way;
  TLTEntry& tlt_entry = tlt_metadata[index];
  SLPEntry& slp_entry = slp_metadata[index];

  // Update TLT metadata
  tlt_entry.last_access_time++;
  tlt_entry.access_count += hit;

  // Update SLP metadata
  slp_entry.spatial_pattern = (slp_entry.spatial_pattern << 1) | (paddr & 1);
}

// Print end-of-simulation statistics
void PrintStats() {
  // Print final statistics for TLT, SLP, and RPS metadata
  std::cout << "NeuCache Statistics:" << std::endl;
  // Add code to print relevant statistics
}

// Print periodic statistics
void PrintStats_Heartbeat() {
  // Print progress statistics for TLT, SLP, and RPS metadata
  std::cout << "NeuCache Heartbeat Statistics:" << std::endl;
  // Add code to print relevant statistics
}
#include <vector>
#include <cstdint>
#include <iostream>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Per-line metadata for temporal analysis
struct LineState {
    uint64_t access_count;    // Total number of accesses
    uint64_t total_interval; // Cumulative time between accesses
    uint64_t last_access;     // Timestamp of most recent access
};

// Global tracking variables
static LineState llc_states[LLC_SETS][LLC_WAYS];
static uint64_t global_access_count = 0;

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            llc_states[s][w].access_count = 0;
            llc_states[s][w].total_interval = 0;
            llc_states[s][w].last_access = 0;
        }
    }
    global_access_count = 0; // Reset global counter
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    double min_score = std::numeric_limits<double>::max();
    uint32_t victim = 0;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        const LineState &state = llc_states[set][way];
        
        // Skip invalidated lines (should never happen)
        if (state.access_count == 0) continue;

        double score = 0.0;
        if (state.access_count > 1) {
            // Calculate average access interval
            double interval = state.total_interval / (state.access_count - 1);
            if (interval > 0) {
                score = (state.access_count / interval); // Frequency/regularity metric
            }
        }
        
        // Update victim candidate
        if (score < min_score) {
            min_score = score;
            victim = way;
        }
    }
    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    global_access_count++; // Increment global access counter
    
    LineState &state = llc_states[set][way];
    
    if (hit) {
        // Recalculate interval for hit
        if (state.access_count > 0) {
            uint64_t interval = global_access_count - state.last_access;
            state.total_interval += interval;
        }
        state.access_count++;
        state.last_access = global_access_count;
    } else {
        // Initialize new cache line
        state.access_count = 1;
        state.total_interval = 0;
        state.last_access = global_access_count;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // No per-policy statistics to print
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // No heartbeats required for this policy
}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 4
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Structure to represent a cache line's metadata
struct LineMeta {
    uint32_t temporal_age; // Temporal age in the stack
    uint32_t frequency_region; // Frequency region ID
};

// Per-set metadata
std::vector<std::vector<LineMeta>> meta_data(LLC_SETS, std::vector<LineMeta>(LLC_WAYS));

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            meta_data[set][way].temporal_age = 0;
            meta_data[set][way].frequency_region = 0;
        }
    }
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Find the line with the oldest temporal age in the lowest frequency region
    uint32_t victim_way = 0;
    uint32_t oldest_temporal_age = UINT32_MAX;
    uint32_t lowest_frequency_region = UINT32_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        if (meta_data[set][way].temporal_age < oldest_temporal_age ||
            (meta_data[set][way].temporal_age == oldest_temporal_age &&
             meta_data[set][way].frequency_region < lowest_frequency_region)) {
            oldest_temporal_age = meta_data[set][way].temporal_age;
            lowest_frequency_region = meta_data[set][way].frequency_region;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update temporal age stack
    for (uint32_t i = 0; i < LLC_WAYS; i++) {
        if (i != way) {
            meta_data[set][i].temporal_age++;
        }
    }
    meta_data[set][way].temporal_age = 0;

    // Update frequency region
    if (hit) {
        meta_data[set][way].frequency_region = (meta_data[set][way].frequency_region + 1) % 4; // Assuming 4 frequency regions
    } else {
        meta_data[set][way].frequency_region = 0;
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    // --- OPTIONAL: print final stats ---
    std::cout << "HTMS Statistics:" << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    // --- OPTIONAL: print progress stats ---
    std::cout << "HTMS Heartbeat:" << std::endl;
}
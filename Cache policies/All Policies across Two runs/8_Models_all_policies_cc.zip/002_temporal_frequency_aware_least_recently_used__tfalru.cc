#include <vector>
#include <cstdint>
#include <iostream>
#include <unordered_map>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16
#define TIME_WINDOW 1000 // Time window for frequency tracking

struct CacheLineMetadata {
    uint64_t timestamp; // Timestamp of last access
    uint64_t frequency; // Frequency count within time window
};

// Initialize replacement state
void InitReplacementState() {
    // Initialize metadata structures
    std::vector<std::vector<CacheLineMetadata>> metadata(LLC_SETS, std::vector<CacheLineMetadata>(LLC_WAYS));
    std::unordered_map<uint64_t, uint64_t> frequency_map; // Frequency map for global frequency tracking

    // Initialize time window tracking
    uint64_t current_time = 0;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    // Find the line with the lowest frequency and longest time since last access
    uint32_t victim = 0;
    uint64_t min_frequency = UINT64_MAX;
    uint64_t max_timestamp = 0;

    for (uint32_t i = 0; i < LLC_WAYS; i++) {
        if (metadata[set][i].frequency < min_frequency || (metadata[set][i].frequency == min_frequency && metadata[set][i].timestamp > max_timestamp)) {
            victim = i;
            min_frequency = metadata[set][i].frequency;
            max_timestamp = metadata[set][i].timestamp;
        }
    }

    return victim;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    // Update metadata
    if (hit) {
        metadata[set][way].timestamp = current_time;
        metadata[set][way].frequency++;
    } else {
        // Update frequency map
        frequency_map[paddr] = 0;
    }

    // Increment time
    current_time++;

    // Periodically reset frequency counts and timestamps
    if (current_time % TIME_WINDOW == 0) {
        for (uint32_t i = 0; i < LLC_SETS; i++) {
            for (uint32_t j = 0; j < LLC_WAYS; j++) {
                metadata[i][j].frequency = 0;
                metadata[i][j].timestamp = 0;
            }
        }
    }
}

// Print end-of-simulation statistics
void PrintStats() {
    std::cout << "TFALRU policy statistics:" << std::endl;
    std::cout << "Frequency map size: " << frequency_map.size() << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    std::cout << "TFALRU policy heartbeat statistics:" << std::endl;
    std::cout << "Current time: " << current_time << std::endl;
    std::cout << "Frequency map size: " << frequency_map.size() << std::endl;
}
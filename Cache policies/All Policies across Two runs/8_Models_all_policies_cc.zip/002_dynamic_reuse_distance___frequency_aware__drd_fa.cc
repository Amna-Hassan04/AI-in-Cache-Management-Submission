//===================================================================
//  DRD-FA : Dynamic Reuse‑Distance & Frequency Aware replacement
//===================================================================

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

/*------------------------------------------------------------------*/
/*  Tunable parameters – feel free to experiment                     */
constexpr double ALPHA = 4.0;   // weight for reuse‑distance term
constexpr double BETA  = 2.0;   // weight for frequency term
constexpr uint32_t PRD_MAX = 255;   // saturating max for PRD estimate
constexpr uint32_t AF_MAX  = 255;   // saturating max for frequency counter
constexpr uint32_t DECAY_EPOCH = 100000; // cycles between global decays
/*------------------------------------------------------------------*/

/* Per‑line metadata */
struct drdfa_meta_t {
    uint8_t  last_access_cycle;   // low‑resolution age (wrap‑around ok)
    uint8_t  freq_counter;        // Access Frequency (AF)
    uint8_t  prd_estimate;        // Predicted Reuse Distance (PRD) – average gap
    uint64_t last_access_time;    // full‑precision timestamp for PRD calculation
    uint64_t last_hit_time;       // timestamp of previous hit (used to compute gap)
};

/* One meta‑array per set */
static drdfa_meta_t replacement_state[LLC_SETS][LLC_WAYS];

/* Global epoch for periodic decay */
static uint64_t global_cycle = 0;
static uint64_t next_decay_cycle = DECAY_EPOCH;

/*===================================================================*/
/*  Initialise metadata structures                                    */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            replacement_state[s][w].last_access_cycle = 0;
            replacement_state[s][w].freq_counter      = 0;
            replacement_state[s][w].prd_estimate      = PRD_MAX; // start pessimistic
            replacement_state[s][w].last_access_time  = 0;
            replacement_state[s][w].last_hit_time     = 0;
        }
    }
    global_cycle       = 0;
    next_decay_cycle   = DECAY_EPOCH;
}

/*-------------------------------------------------------------------*/
/*  Helper: compute the eviction score for a line                     */
static inline double compute_score(const drdfa_meta_t &m, uint8_t age) {
    // (A) * (1 + α/(PRD+1)) / (1 + β*AF)
    double age_factor   = static_cast<double>(age);
    double prd_factor   = 1.0 + ALPHA / (static_cast<double>(m.prd_estimate) + 1.0);
    double freq_factor  = 1.0 + BETA * (static_cast<double>(m.freq_counter) / static_cast<double>(AF_MAX));
    return age_factor * prd_factor / freq_factor;
}

/*-------------------------------------------------------------------*/
/*  Choose a victim line in the set                                    */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type)
{
    // Increment global cycle counter (simulation‑wide)
    ++global_cycle;
    if (global_cycle >= next_decay_cycle) {
        // Global decay of frequency counters
        for (uint32_t s = 0; s < LLC_SETS; ++s)
            for (uint32_t w = 0; w < LLC_WAYS; ++w)
                replacement_state[s][w].freq_counter >>= 1; // simple halving
        next_decay_cycle += DECAY_EPOCH;
    }

    // Scan ways, compute score, pick the largest (least valuable)
    uint32_t victim_way = 0;
    double   worst_score = -1.0;

    for (uint32_t way = 0; way < LLC_WAYS; ++way) {
        const drdfa_meta_t &meta = replacement_state[set][way];
        // Age is the difference between current cycle and last_access_cycle (8‑bit wrap)
        uint8_t age = static_cast<uint8_t>(global_cycle - meta.last_access_cycle);
        double score = compute_score(meta, age);

        if (score > worst_score) {
            worst_score = score;
            victim_way  = way;
        }
    }

    return victim_way;
}

/*-------------------------------------------------------------------*/
/*  Update replacement state after every access (hit or miss)        */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit)
{
    drdfa_meta_t &meta = replacement_state[set][way];

    // Update age (low‑resolution stamp)
    meta.last_access_cycle = static_cast<uint8_t>(global_cycle & 0xFF);

    // Frequency counter: saturating increment on hit, modest bump on insertion
    if (hit) {
        if (meta.freq_counter < AF_MAX) meta.freq_counter++;
    } else {
        // On insertion we give the new line a modest starting frequency
        meta.freq_counter = 1;
    }

    // ---------- Reuse‑Distance estimation ----------
    // Only meaningful on a hit (we have a previous hit timestamp)
    if (hit && meta.last_hit_time != 0) {
        uint64_t gap = global_cycle - meta.last_hit_time; // raw gap in cycles
        // Convert gap to a small bucket (log2) to keep PRD small
        uint8_t gap_bucket = static_cast<uint8_t>(__builtin_clzll(~gap));
        // Exponential moving average: new = (old * 7 + bucket) / 8
        meta.prd_estimate = static_cast<uint8_t>(
                ((static_cast<uint16_t>(meta.prd_estimate) * 7) + gap_bucket) >> 3 );
        if (meta.prd_estimate > PRD_MAX) meta.prd_estimate = PRD_MAX;
    } else {
        // First time we see this line – start with a neutral PRD
        meta.prd_estimate = PRD_MAX / 2;
    }

    // Store timestamps for next reuse‑distance computation
    meta.last_hit_time    = global_cycle;
    meta.last_access_time = global_cycle;
}

/*-------------------------------------------------------------------*/
/*  Optional: print final statistics                                    */
void PrintStats() {
    uint64_t total_freq = 0, total_prd = 0;
    for (uint32_t s = 0; s < LLC_SETS; ++s)
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            total_freq += replacement_state[s][w].freq_counter;
            total_prd  += replacement_state[s][w].prd_estimate;
        }
    std::cout << "DRD-FA stats: total_freq = " << total_freq
              << " , total_prd = " << total_prd << std::endl;
}

/* Periodic heartbeat – can be left empty */
void PrintStats_Heartbeat() {}
#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

// Metadata structures to track frequency and recency
uint64_t freq[LLC_SETS][LLC_WAYS];
uint64_t rec[LLC_SETS][LLC_WAYS];
uint64_t global_timestamp = 0;

// Initialize replacement state
void InitReplacementState() {
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            freq[set][way] = 0;
            rec[set][way] = 0;
        }
    }
    global_timestamp = 0;
}

// Choose victim line in the set
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type
) {
    uint32_t victim_way = 0;
    uint64_t min_score = UINT64_MAX;

    for (uint32_t way = 0; way < LLC_WAYS; way++) {
        uint64_t score = (freq[set][way] + 1) * (global_timestamp - rec[set][way]);
        if (score < min_score) {
            min_score = score;
            victim_way = way;
        }
    }

    return victim_way;
}

// Update replacement state
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit
) {
    if (hit) {
        // Update frequency and recency for the hit line
        freq[set][way]++;
        rec[set][way] = global_timestamp;
    }
    global_timestamp++;
}

// Print end-of-simulation statistics
void PrintStats() {
    // Example statistics: Average frequency and recency across all lines
    uint64_t total_freq = 0, total_rec = 0;
    for (uint32_t set = 0; set < LLC_SETS; set++) {
        for (uint32_t way = 0; way < LLC_WAYS; way++) {
            total_freq += freq[set][way];
            total_rec += rec[set][way];
        }
    }
    double avg_freq = (double)total_freq / (LLC_SETS * LLC_WAYS);
    double avg_rec = (double)total_rec / (LLC_SETS * LLC_WAYS);
    std::cout << "Average Frequency: " << avg_freq << std::endl;
    std::cout << "Average Recency: " << avg_rec << std::endl;
}

// Print periodic statistics
void PrintStats_Heartbeat() {
    PrintStats();
}
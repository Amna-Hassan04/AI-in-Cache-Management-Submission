#include <vector>
#include <cstdint>
#include <cmath>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)
#define LLC_WAYS 16

static uint8_t  line_phase[LLC_SETS][LLC_WAYS];   // 0-255 last P(retain)
static uint8_t  line_omega[LLC_SETS][LLC_WAYS];      // recency
static uint8_t  line_psi[LLC_SETS][LLC_WAYS];      // access count
static uint16_t line_Omega[LLC_SETS][LLC_WAYS];     // folded PC
static int8_t   line_nu[LLC_SETS][LLC_WAYS];        // stride
static uint64_t line_lastaddr[LLC_SETS][LLC_WAYS];  // previous paddr

static double   energy_chi = 1.0, energy_phi = 1.0, energy_psi = 1.0;

// ------------------------------------------------------------------
void InitReplacementState(){
    for(uint32_t s=0;s<LLC_SETS;s++)
        for(uint32_t w=0;w<LLC_WAYS;w++){
            line_phase[s][w]=128;
            line_omega[s][w]=0;
            line_psi[s][w]=0;
            line_Omega[s][w]=0;
            line_nu[s][w]=0;
            line_lastaddr[s][w]=0;
        }
}
// ------------------------------------------------------------------
static double sigmoid(double x){
    if(x> 8.0) return 1.0;
    if(x<-8.0) return 0.0;
    return 1.0/(1.0+std::exp(-x));
}
// ------------------------------------------------------------------
uint32_t GetVictimInSet(uint32_t cpu, uint32_t set, const BLOCK *current_set,
                        uint64_t PC, uint64_t paddr, uint32_t type){
    uint32_t victim_way=0;
    uint32_t min_phase=line_phase[set][0];
    for(uint32_t w=1;w<LLC_WAYS;w++){
        if(line_phase[set][w]<min_phase){
            min_phase=line_phase[set][w];
            victim_way=w;
        }
    }
    return victim_way;
}
// ------------------------------------------------------------------
void UpdateReplacementState(uint32_t cpu, uint32_t set, uint32_t way,
                            uint64_t paddr, uint64_t PC, uint64_t victim_addr,
                            uint32_t type, uint8_t hit){
    // --- update moving-average energies -----------------------------
    uint32_t occ=0;                     // set occupancy
    for(uint32_t w=0;w<LLC_WAYS;w++)
        if(current_set[w].valid) occ++;
    double chi = double(occ)/LLC_WAYS;
    energy_chi = 0.2*(1.0/(chi+0.01)) + 0.8*energy_chi;

    static uint32_t total_blocks=0;    // global occupancy
    if(!hit && type==WRITEBACK) total_blocks++;
    double phi = double(total_blocks)/double(LLC_SETS*LLC_WAYS);
    energy_phi = 0.2*(1.0/(phi+0.01)) + 0.8*energy_phi;

    double psi_avg = 0;
    for(uint32_t w=0;w<LLC_WAYS;w++)
        psi_avg += line_psi[set][w];
    psi_avg = psi_avg/std::max(uint32_t(1),occ);
    energy_psi = 0.2*(1.0/(psi_avg+0.01)) + 0.8*energy_psi;

    // --- line metadata update ---------------------------------------
    uint8_t &omega = line_omega[set][way];
    uint8_t &psi  = line_psi[set][way];
    uint16_t &Omega= line_Omega[set][way];
    int8_t  &nu    = line_nu[set][way];
    uint64_t &prev = line_lastaddr[set][way];

    if(hit){
        omega=0; psi=std::min(uint8_t(255),uint8_t(psi+1));
    }else{
        omega=0; psi=1;
    }
    // stride
    int64_t delta = int64_t(paddr>>6) - int64_t(prev>>6);
    nu = int8_t(delta);      // fits in 8-bit for typical strides
    prev = paddr;
    Omega = uint16_t(PC^((PC>>16)&0xFFFF));

    // --- collapse quantum phase -------------------------------------
    double w  = double(omega)/64.0;
    double echi=energy_chi, ephi=energy_phi, epsi=energy_psi;
    double arg = -w*echi - double(std::abs(nu))*ephi + double(psi)*epsi + double(Omega&0x1F)/32.0;
    double p = sigmoid(arg);
    line_phase[set][way] = uint8_t(p*255.0);

    // aging everyone else in the set
    for(uint32_t w=0;w<LLC_WAYS;w++)
        if(w!=way){
            line_omega[set][w]=std::min(uint8_t(255),uint8_t(line_omega[set][w]+1));
        }
}
// ------------------------------------------------------------------
void PrintStats(){}
void PrintStats_Heartbeat(){}
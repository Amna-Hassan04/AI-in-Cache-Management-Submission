/********************************************************************
 *  Statistical Reuse Score (SRS) Replacement Policy
 *  -------------------------------------------------
 *  - Tracks per‑line last access timestamp and a reuse score.
 *  - Victim = line with the smallest reuse score in the set.
 *  - Score updated with exponential moving average of 1/(reuse distance).
 *
 *  This file follows the Champsim replacement‑policy skeleton.
 ********************************************************************/

#include <vector>
#include <cstdint>
#include <iostream>
#include "../inc/champsim_crc2.h"

#define NUM_CORE 1
#define LLC_SETS (NUM_CORE * 2048)   // total number of sets
#define LLC_WAYS 16                  // associativity

/*------------------------------------------------------------------*/
/*  Policy parameters – feel free to tune them via command line later */
static constexpr float ALPHA = 0.80f;          // EMA smoothing factor
static constexpr float INIT_SCORE = 0.5f;     // score for newly inserted lines
/*------------------------------------------------------------------*/

/* Global timestamp – increments on every cache access */
static uint64_t global_timestamp = 0;

/* Per‑line metadata */
static uint64_t line_timestamp[LLC_SETS][LLC_WAYS];   // last access time
static float    line_score[LLC_SETS][LLC_WAYS];      // reuse score

/* Optional statistics */
static uint64_t accesses = 0;
static uint64_t hits     = 0;

/*---------------------------------------------------------------*/
/*  Initialise metadata structures                                 */
void InitReplacementState() {
    for (uint32_t s = 0; s < LLC_SETS; ++s) {
        for (uint32_t w = 0; w < LLC_WAYS; ++w) {
            line_timestamp[s][w] = 0;
            line_score[s][w]     = 0.0f;   // 0 = empty / never used
        }
    }
    global_timestamp = 0;
    accesses = hits = 0;
}

/*---------------------------------------------------------------*/
/*  Choose victim in a set                                          */
uint32_t GetVictimInSet(
    uint32_t cpu,
    uint32_t set,
    const BLOCK *current_set,
    uint64_t PC,
    uint64_t paddr,
    uint32_t type)
{
    ++global_timestamp;        // advance global time for this request
    ++accesses;

    // Look for an empty way first (score == 0 && valid == false)
    for (uint32_t w = 0; w < LLC_WAYS; ++w) {
        if (!current_set[w].valid) {
            return w;          // free slot – no eviction needed
        }
    }

    // All ways occupied → pick the line with the smallest reuse score
    uint32_t victim_way = 0;
    float   min_score   = line_score[set][0];

    for (uint32_t w = 1; w < LLC_WAYS; ++w) {
        if (line_score[set][w] < min_score) {
            min_score   = line_score[set][w];
            victim_way  = w;
        }
    }
    return victim_way;
}

/*---------------------------------------------------------------*/
/*  Update metadata after an access                                 */
void UpdateReplacementState(
    uint32_t cpu,
    uint32_t set,
    uint32_t way,
    uint64_t paddr,
    uint64_t PC,
    uint64_t victim_addr,
    uint32_t type,
    uint8_t hit)
{
    if (hit) {
        ++hits;

        /* -------------------- HIT UPDATE -------------------- */
        uint64_t last_ts = line_timestamp[set][way];
        uint64_t reuse_distance = (global_timestamp > last_ts) ?
                                   (global_timestamp - last_ts) : 1ULL;

        // Inverse reuse distance (add 1 to avoid division by zero)
        float inv_dist = 1.0f / static_cast<float>(reuse_distance + 1ULL);

        // EMA update of the reuse score
        line_score[set][way] = ALPHA * line_score[set][way] + (1.0f - ALPHA) * inv_dist;

        // Record new timestamp
        line_timestamp[set][way] = global_timestamp;
    } else {
        /* -------------------- MISS / INSERT -------------------- */
        // The caller has already chosen the victim way (could be empty).
        // Initialise the new line's metadata.
        line_timestamp[set][way] = global_timestamp;
        line_score[set][way]     = INIT_SCORE;   // moderate initial confidence
    }
}

/*---------------------------------------------------------------*/
/*  Print final statistics                                          */
void PrintStats() {
    std::cout << "=== SRS Replacement Policy Statistics ===\n";
    std::cout << "  Total accesses : " << accesses << "\n";
    std::cout << "  Hits           : " << hits << "\n";
    if (accesses > 0) {
        double hit_rate = static_cast<double>(hits) / static_cast<double>(accesses);
        std::cout << "  Hit rate       : " << hit_rate * 100.0 << " %\n";
    }
}

/*---------------------------------------------------------------*/
/*  Periodic heartbeat (optional)                                   */
void PrintStats_Heartbeat() {
    // Example: print every 10 million accesses (user can hook this up)
    if (accesses % 10000000ULL == 0) {
        std::cout << "[SRS] accesses=" << accesses
                  << " hits=" << hits
                  << " hit_rate=" << (static_cast<double>(hits)/accesses)*100.0
                  << " %\n";
    }
}